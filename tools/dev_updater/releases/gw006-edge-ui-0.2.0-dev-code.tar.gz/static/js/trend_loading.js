/*
 * Trend Viewer loading state.
 *
 * Opening a trend group, switching time range, or submitting custom hours is a
 * full page navigation whose cost is dominated by reading and downsampling the
 * gateway's local SQLite samples.  Seven days over a group with a dozen points
 * takes a few seconds, and the wait has two halves: the server preparing the
 * response, and this browser parsing it and drawing the chart.
 *
 * An overlay owned by the outgoing page only covers the first half — it dies
 * with that document, leaving a bare chart area until the graph appears.  So
 * the overlay is rendered by the server into the incoming page too, visible in
 * the markup, and this file only takes it down once the chart is actually on
 * screen.  One continuous indeterminate spinner across both halves.
 *
 * It veils the chart frame and nothing else, so the rest of the viewer stays
 * readable while it is up, and on the outgoing page the graph being replaced
 * shows through it.  Trend Groups has no graph and so carries no overlay; the
 * duplicate-click guard here still has to work on that page.
 *
 * There is no real progress figure to report, so none is invented.  Nothing
 * here changes where the data comes from, which group is open, which range is
 * selected, or the saved Graph Controls.
 */
(function () {
  'use strict';

  // Long enough that a slow seven-day render never trips it, short enough that
  // a failed navigation does not strand the operator behind the overlay.
  var FAILSAFE_MS = 45000;

  var overlay = document.getElementById('trend-loading-overlay');
  var failsafeTimer = null;
  var active = false;

  function arm() {
    window.clearTimeout(failsafeTimer);
    failsafeTimer = window.setTimeout(hide, FAILSAFE_MS);
  }

  // Busy state first, veil second: a page with no graph to veil still has to
  // refuse a second click and still has to arm its way back out.
  function show() {
    active = true;
    document.documentElement.setAttribute('aria-busy', 'true');
    if (overlay) { overlay.hidden = false; }
    arm();
  }

  /*
   * Every way out of the overlay funnels through here.  A navigation that
   * fails, is blocked, or is cancelled leaves this document on screen, so the
   * overlay has to be recoverable without a reload.
   */
  function hide() {
    window.clearTimeout(failsafeTimer);
    active = false;
    document.documentElement.removeAttribute('aria-busy');
    if (overlay) { overlay.hidden = true; }
  }

  /*
   * Called by the viewer once it has drawn.  Two frames, not one: the first
   * lands after the canvas work is queued, the second after the browser has
   * actually painted it, so the overlay never lifts onto a blank chart.
   */
  function hideWhenPainted() {
    if (!window.requestAnimationFrame) { hide(); return; }
    window.requestAnimationFrame(function () {
      window.requestAnimationFrame(hide);
    });
  }

  function isPlainClick(event) {
    return !event.defaultPrevented && event.button === 0 &&
      !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey;
  }

  function bind(root) {
    var nodes = (root || document).querySelectorAll('[data-trend-loading]');
    Array.prototype.forEach.call(nodes, function (node) {
      if (node.getAttribute('data-trend-loading-bound') === 'yes') { return; }
      node.setAttribute('data-trend-loading-bound', 'yes');

      if (node.tagName === 'FORM') {
        node.addEventListener('submit', function (event) {
          // A second submit while the first is in flight would queue a
          // duplicate render of the same range.
          if (active) { event.preventDefault(); return; }
          show();
        });
        return;
      }

      node.addEventListener('click', function (event) {
        if (!isPlainClick(event)) { return; }
        // Opening in a new tab leaves this document where it is, so it gets no
        // overlay; a same-tab repeat click while loading is dropped.
        if (node.target && node.target !== '_self') { return; }
        if (active) { event.preventDefault(); return; }
        show();
      });
    });
  }

  // Back-navigation restores this document from the bfcache with whatever DOM
  // it had when it was left, overlay included.  Only that case: an ordinary
  // load also fires pageshow, and hiding there would undo the overlay the
  // server just rendered before the chart has drawn.
  window.addEventListener('pageshow', function (event) {
    if (event.persisted) { hide(); }
  });
  // A last manual escape hatch, so the overlay is never a trap.
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && active) { hide(); }
  });

  // The server may have rendered the overlay already visible, in which case
  // this page is loading right now and the failsafe has to be running.
  if (overlay && !overlay.hidden) {
    active = true;
    document.documentElement.setAttribute('aria-busy', 'true');
    arm();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(document); });
  } else {
    bind(document);
  }

  window.trendLoading = {
    show: show,
    hide: hide,
    hideWhenPainted: hideWhenPainted,
    bind: bind,
    isActive: function () { return active; }
  };
}());
