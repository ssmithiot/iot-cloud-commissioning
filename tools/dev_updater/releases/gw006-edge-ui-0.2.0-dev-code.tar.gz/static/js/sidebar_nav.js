(function () {
  var root = document.documentElement;
  var sidebar = document.querySelector('[data-sidebar]');
  if (!sidebar) return;

  var storageKey = 'edge_bacnet_sidebar_collapsed';
  var toggle = document.querySelector('[data-sidebar-toggle]');
  var rail = document.querySelector('[data-sidebar-rail]');
  var openButtons = document.querySelectorAll('[data-sidebar-open]');
  var closeButtons = document.querySelectorAll('[data-sidebar-close]');
  var scrim = document.querySelector('.sidebar-scrim');
  var groups = Array.prototype.slice.call(sidebar.querySelectorAll('[data-sidebar-group]'));

  function storageGet() {
    try {
      return window.localStorage.getItem(storageKey);
    } catch (error) {
      return null;
    }
  }

  function storageSet(value) {
    try {
      window.localStorage.setItem(storageKey, value ? 'true' : 'false');
    } catch (error) {}
  }

  function setCollapsed(collapsed, persist) {
    root.classList.toggle('sidebar-collapsed', collapsed);
    root.classList.toggle('sidebar-pref-collapsed', collapsed);
    if (toggle) {
      toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
      toggle.setAttribute('aria-label', collapsed ? 'Expand navigation' : 'Collapse navigation');
      toggle.setAttribute('title', collapsed ? 'Expand navigation' : 'Collapse navigation');
    }
    if (persist) storageSet(collapsed);
  }

  function openMobile() {
    root.classList.add('sidebar-mobile-open');
    if (scrim) scrim.hidden = false;
  }

  function closeMobile() {
    root.classList.remove('sidebar-mobile-open');
    if (scrim) scrim.hidden = true;
  }

  function setGroupOpen(group, open) {
    var button = group.querySelector('[data-sidebar-group-button]');
    group.classList.toggle('is-open', open);
    if (button) button.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  function closeOtherGroups(activeGroup) {
    groups.forEach(function (group) {
      if (group !== activeGroup) setGroupOpen(group, false);
    });
  }

  setCollapsed(storageGet() === 'true', false);

  if (toggle) {
    toggle.addEventListener('click', function (event) {
      event.stopPropagation();
      setCollapsed(!root.classList.contains('sidebar-collapsed'), true);
    });
  }

  if (rail) {
    rail.addEventListener('click', function (event) {
      if (!root.classList.contains('sidebar-collapsed')) return;
      if (event.target.closest('a, button, input, select, textarea, summary, form')) return;
      setCollapsed(false, true);
    });
  }

  openButtons.forEach(function (button) {
    button.addEventListener('click', openMobile);
  });

  closeButtons.forEach(function (button) {
    button.addEventListener('click', closeMobile);
  });

  groups.forEach(function (group) {
    var button = group.querySelector('[data-sidebar-group-button]');
    if (!button) return;
    button.addEventListener('click', function () {
      var willOpen = !group.classList.contains('is-open');
      if (willOpen) closeOtherGroups(group);
      setGroupOpen(group, willOpen);
    });
  });

  sidebar.addEventListener('click', function (event) {
    if (event.target.closest('a')) closeMobile();
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') closeMobile();
  });
})();
