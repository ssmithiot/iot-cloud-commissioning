from __future__ import annotations

import csv
import hmac
import ipaddress
import io
import json
import math
import os
import re
import signal
import shlex
import shutil
import secrets
import subprocess
import socket
import tempfile
import time
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit
from uuid import uuid4

from flask import Flask, Response, flash, jsonify, redirect, render_template, request, send_file, session, url_for
from edge_program_engine import POINT_TYPES, Point, ProgramError, ProgramStore, WriteSuppressor, dry_run, execute_program
from edge_trend_store import (
    GRAPH_TARGET_VALUES,
    RECENT_SAMPLE_ROWS,
    EdgeTrendStore,
    numeric_sample_value,
)
from timed_override_store import ACTIONABLE_STATUSES, ACTIVE_STATUSES, TimedOverrideStore, utc_now_iso
import router_config as routercfg

# --- Local configuration ----------------------------------------------------
BACNET_BIN = os.environ.get("BACNET_BIN", "/home/swadmin/bacnet-stack/bin")
BACNET_PRIMARY_PORT = os.environ.get("BACNET_IP_PORT", "47809").strip() or "47809"


def _parse_bacnet_ports(raw_ports: str) -> list[str]:
    ports: list[str] = []
    for raw_port in re.split(r"[\s,;]+", raw_ports or ""):
        port = raw_port.strip()
        if not port or not port.isdigit():
            continue
        if 1 <= int(port) <= 65535 and port not in ports:
            ports.append(port)
    return ports


BACNET_PORTS = _parse_bacnet_ports(os.environ.get("BACNET_IP_PORTS", f"{BACNET_PRIMARY_PORT},47809,47814"))
if BACNET_PRIMARY_PORT not in BACNET_PORTS:
    BACNET_PORTS.insert(0, BACNET_PRIMARY_PORT)
BACNET_STARTUP_PORTS = list(BACNET_PORTS)
BACNET_DEFAULT_MODE = os.environ.get("BACNET_PORT_MODE", "dual-47809-first").strip() or "dual-47809-first"
BACNET_EDGE_PROGRAM_PORTS = _parse_bacnet_ports(os.environ.get("BACNET_EDGE_PROGRAM_PORTS", "47816"))
BACNET_EDGE_PROGRAM_SCHEDULER_PORTS = _parse_bacnet_ports(os.environ.get("BACNET_EDGE_PROGRAM_SCHEDULER_PORTS", "47817"))
BACNET_IP_DISCOVERY_PORTS = _parse_bacnet_ports(os.environ.get("BACNET_IP_DISCOVERY_PORTS", "47808"))
BACNET_AGENT_FDR_PORTS = _parse_bacnet_ports(os.environ.get("BACNET_AGENT_FDR_PORTS", "47814"))
BACNET_EXTERNAL_NAT_REACHABILITY = os.environ.get(
    "BACNET_EXTERNAL_NAT_REACHABILITY",
    "validated",
).strip() or "validated"
MAX_OBJECTS = int(os.environ.get("MAX_OBJECTS", "1500"))
DEFAULT_SCAN_LIMIT = int(os.environ.get("DEFAULT_SCAN_LIMIT", "10"))
RPM_BLOCK_SIZE = int(os.environ.get("RPM_BLOCK_SIZE", "40"))
RPM_NAME_BLOCK_SIZE = int(os.environ.get("RPM_NAME_BLOCK_SIZE", "40"))
RPM_VIEW_BLOCK_SIZE = int(os.environ.get("RPM_VIEW_BLOCK_SIZE", "4"))
NATIVE_BIP_RPM_VIEW_BLOCK_SIZE = int(os.environ.get("NATIVE_BIP_RPM_VIEW_BLOCK_SIZE", "20"))

AUTH_ENABLED = os.environ.get("AUTH_ENABLED", "1") == "1"
AUTH_USERNAME = os.environ.get("EDGE_UI_USERNAME", "admin")
AUTH_PASSWORD = os.environ.get("EDGE_UI_PASSWORD", "")
SESSION_TIMEOUT_SECONDS = int(os.environ.get("SESSION_TIMEOUT_SECONDS", "1800"))
EDGE_AGENT_WRITE_TOKEN = os.environ.get("EDGE_AGENT_WRITE_TOKEN", "")
EDGE_AGENT_RESTART_HELPER = os.environ.get("EDGE_AGENT_RESTART_HELPER", "/usr/local/sbin/iot-cx-restart-agent")
BASE_DIR = Path(__file__).resolve().parent
EDGE_UI_VERSION = "0.2.0"
EDGE_UI_SAFE_MODE = os.environ.get("EDGE_UI_SAFE_MODE", "0").strip().lower() in {"1", "true", "yes", "on"}
EDGE_UI_LOCAL_ONLY = EDGE_UI_SAFE_MODE or os.environ.get("EDGE_UI_LOCAL_ONLY", "0").strip().lower() in {"1", "true", "yes", "on"}
# Edge Trends ship enabled in 0.2.0.  The gate is retained so a site can turn the
# local trend interface off without a rollback; the agent-side
# `local_edge_trends_enabled` gate must be set to match (both gates live in
# different repositories and only the pair produces working trends).
EDGE_TRENDS_UI_ENABLED = os.environ.get("EDGE_TRENDS_UI_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
EDGE_UI_RUNTIME_ROOT = Path(os.environ.get("EDGE_UI_RUNTIME_ROOT", str(BASE_DIR / "data")))
EDGE_UI_HOST = os.environ.get("EDGE_UI_HOST", "127.0.0.1" if EDGE_UI_LOCAL_ONLY else "0.0.0.0").strip() or "127.0.0.1"
EDGE_UI_PORT = int(os.environ.get("EDGE_UI_PORT", "5001" if EDGE_UI_LOCAL_ONLY else "5000"))

DATA_DIR = EDGE_UI_RUNTIME_ROOT
TEMPLATE_DIR = DATA_DIR / "templates"
EXPORT_DIR = DATA_DIR / "exports"
CACHE_DIR = DATA_DIR / "cache"
SCHEDULE_DIR = DATA_DIR / "schedules"
SAVED_DEVICE_DIR = DATA_DIR / "devices"
CAPTURE_DIR = DATA_DIR / "captures"
EDGE_UI_AUDIT_FILE = DATA_DIR / "edge-ui-audit.jsonl"
EDGE_PROGRAM_DB = Path(os.environ.get("EDGE_PROGRAM_DB", str(DATA_DIR / "edge-programs.db")))
EDGE_TRENDS_DB = Path(os.environ.get("EDGE_TRENDS_DB", str(DATA_DIR / "edge-trends.db")))
TIMED_OVERRIDES_DB = Path(os.environ.get("TIMED_OVERRIDES_DB", str(DATA_DIR / "timed-overrides.db")))
KEPT_DEVICE_FILE = DATA_DIR / "kept_devices.json"
SCHEDULE_WRITE_HELPER = os.environ.get("SCHEDULE_WRITE_HELPER", "").strip()
# Schedule writes are enabled by default now that bacnet-stack weekly-schedule
# read/write was proven against the Viconics VT8650. Set ENABLE_SCHEDULE_WRITES=0
# to force stage-only mode.
ENABLE_SCHEDULE_WRITES = os.environ.get("ENABLE_SCHEDULE_WRITES", "1").strip().lower() in {"1", "true", "yes", "on"}
EDGE_PROGRAMS: ProgramStore | None = None
EDGE_TRENDS: EdgeTrendStore | None = None
TIMED_OVERRIDES: TimedOverrideStore | None = None
EDGE_PROGRAM_SCHEDULER: EdgeProgramScheduler | None = None
TIMED_OVERRIDE_SCHEDULER: TimedOverrideScheduler | None = None
RUNTIME_INITIALIZED = False

if EDGE_UI_SAFE_MODE:
    AUTH_USERNAME = os.environ.get("EDGE_UI_USERNAME", "localdev")
    AUTH_PASSWORD = os.environ.get("EDGE_UI_PASSWORD", "localdev")
    EDGE_AGENT_WRITE_TOKEN = os.environ.get("EDGE_AGENT_WRITE_TOKEN", "local-edge-agent-token")


class SafeModeBlocked(RuntimeError):
    """Raised when a live operational action is attempted in safe local mode."""


def in_safe_mode() -> bool:
    return EDGE_UI_SAFE_MODE


def runtime_directories() -> tuple[Path, ...]:
    return (TEMPLATE_DIR, EXPORT_DIR, CACHE_DIR, SCHEDULE_DIR, SAVED_DEVICE_DIR, CAPTURE_DIR)


def ensure_runtime_initialized() -> None:
    global EDGE_PROGRAMS, EDGE_TRENDS, TIMED_OVERRIDES, EDGE_PROGRAM_SCHEDULER, TIMED_OVERRIDE_SCHEDULER, RUNTIME_INITIALIZED
    if RUNTIME_INITIALIZED:
        return
    for folder in runtime_directories():
        folder.mkdir(parents=True, exist_ok=True)
    EDGE_PROGRAMS = ProgramStore(EDGE_PROGRAM_DB)
    EDGE_TRENDS = EdgeTrendStore(EDGE_TRENDS_DB)
    TIMED_OVERRIDES = TimedOverrideStore(TIMED_OVERRIDES_DB)
    EDGE_PROGRAM_SCHEDULER = EdgeProgramScheduler(EDGE_PROGRAMS)
    TIMED_OVERRIDE_SCHEDULER = TimedOverrideScheduler(TIMED_OVERRIDES)
    RUNTIME_INITIALIZED = True


def program_store() -> ProgramStore:
    ensure_runtime_initialized()
    assert EDGE_PROGRAMS is not None
    return EDGE_PROGRAMS


def trend_store() -> EdgeTrendStore:
    ensure_runtime_initialized()
    assert EDGE_TRENDS is not None
    return EDGE_TRENDS


def timed_override_store() -> TimedOverrideStore:
    ensure_runtime_initialized()
    assert TIMED_OVERRIDES is not None
    return TIMED_OVERRIDES


def block_live_operation(action: str) -> None:
    if in_safe_mode():
        raise SafeModeBlocked(f"{action} is disabled while EDGE_UI_SAFE_MODE=1.")


def _router_header_summary(config: dict[str, Any]) -> dict[str, str]:
    bip_interfaces = [item for item in config.get("bip_interfaces") or [] if item.get("enabled")]
    first_bip = bip_interfaces[0] if bip_interfaces else ((config.get("bip_interfaces") or [{}])[0])
    first_trunk = (config.get("mstp_trunks") or [{}])[0]
    bind_address = str(first_bip.get("bind_address") or "192.168.1.200")
    udp_port = str(first_bip.get("udp_port") or "47809")
    router_local_bind = f"{bind_address}:{udp_port}"
    advertised_ip = str(first_bip.get("advertised_ip") or "")
    advertised_port = str(first_bip.get("advertised_port") or udp_port)
    router_advertised_nat = f"{advertised_ip}:{advertised_port}" if first_bip.get("nat_enabled") and advertised_ip else ""
    cradlepoint_nat_path = (
        f"{router_advertised_nat}/UDP -> {router_local_bind}/UDP"
        if router_advertised_nat
        else "not configured"
    )
    legacy_external_path = os.environ.get(
        "BACNET_LEGACY_EXTERNAL_PATH",
        "10.2.0.15:47814/UDP -> 192.168.1.102:47814/UDP",
    )
    return {
        "endpoint": ", ".join(
            f"{item.get('linux_interface') or '?'}:{item.get('udp_port')}" for item in config.get("bip_interfaces") or []
        ),
        "router_local_bind": router_local_bind,
        "router_advertised_nat": router_advertised_nat,
        "cradlepoint_nat_path": cradlepoint_nat_path,
        "external_nat_reachability": BACNET_EXTERNAL_NAT_REACHABILITY,
        "legacy_external_path": legacy_external_path,
        "agent_fdr_socket": f"{bind_address}:{','.join(BACNET_AGENT_FDR_PORTS or ['47814'])}",
        "ui_client_socket": f"{bind_address}:{','.join(get_edge_program_bacnet_ports())}",
        "ip_discovery_socket": f"{bind_address}:{','.join(BACNET_IP_DISCOVERY_PORTS or ['47808'])}",
        "mstp_network": str(first_trunk.get("network_number") or ""),
        "serial_device": str(first_trunk.get("serial_device") or ""),
    }


def _router_service_health_display(health: str) -> str:
    return "healthy" if health == "ok" else (health or "unknown")


def _legacy_router_service_display(status: str) -> str:
    return "installed and inactive" if status == "inactive" else (status or "unknown")


def safe_router_state() -> dict[str, Any]:
    config = routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS)
    return {
        "config": config,
        "runtime": routercfg.runtime_snapshot_from_helper(
            {
                "service_status": "safe-mode-blocked",
                "legacy_service_status": "preserved",
                "health": "safe-mode",
                "recent_errors": ["Live router access is blocked while EDGE_UI_SAFE_MODE=1."],
            }
        ),
        "mstp_status": {"updated_at": "", "trunks": {}},
        "serial_candidates": [],
        "linux_interfaces": [],
        "edge_bacnet_router_enabled": False,
        "saved_standard_bacnet_route": "inactive",
        "edge_bacnet_router_configuration": _router_header_summary(config),
    }


def record_local_audit(action: str, outcome: str, detail: str = "") -> None:
    """Append a local operator audit event without recording credentials."""
    ensure_runtime_initialized()
    event = {
        "at": datetime.now(timezone.utc).isoformat(),
        "actor": str(session.get("username") or "unknown"),
        "action": action,
        "outcome": outcome,
        "detail": detail[:400],
    }
    with EDGE_UI_AUDIT_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, sort_keys=True) + "\n")


class LocalEdgeProgramBacnetAdapter:
    def read_many(self, points: list[Point]) -> dict[str, float]:
        values: dict[str, float] = {point.key: float("nan") for point in points}
        ports = get_edge_program_scheduler_bacnet_ports()
        grouped: dict[int, list[Point]] = {}
        for point in points:
            grouped.setdefault(int(point.device), []).append(point)

        for device, device_points in grouped.items():
            args = ["./bacrpm", str(device)]
            requested: list[tuple[Point, tuple[str, int]]] = []
            for point in device_points:
                obj_type = POINT_TYPES[point.kind]
                args.extend([obj_type, str(point.instance), "85"])
                requested.append((point, (obj_type, int(point.instance))))
            try:
                parsed = parse_rpm_property_values(run_bacnet(args, timeout=10, ports=ports, preserve_ports=True))
                for point, key in requested:
                    raw_value = parsed.get(key, {}).get("present-value", "")
                    if raw_value != "":
                        values[point.key] = float(clean(raw_value))
            # A remote controller may be offline or time out.  An unavailable
            # input is data for the program to handle via ISNAN(), not a
            # scheduler failure that stops the entire program scan.
            except Exception:
                continue
        return values

    def write(self, point: Point, value: float, priority: int) -> None:
        obj_type = POINT_TYPES[point.kind]
        if _native_bip_write_binding(str(point.device)):
            result = write_present_value(
                str(point.device),
                obj_type,
                point.instance,
                priority,
                default_pv_tag(obj_type),
                str(value),
            )
            if not result.get("ok"):
                raise RuntimeError(str(result.get("message") or "BACnet write was not acknowledged"))
            return
        out = run_bacnet([
            "./bacwp",
            str(point.device),
            obj_type,
            str(point.instance),
            "present-value",
            str(max(1, min(16, int(priority or 16)))),
            "-1",
            default_pv_tag(obj_type),
            str(value),
        ], timeout=10, ports=get_edge_program_scheduler_bacnet_ports(), preserve_ports=True)
        if "WriteProperty Acknowledged" not in out:
            raise RuntimeError(out or "BACnet write was not acknowledged")

    def relinquish(self, point: Point, priority: int) -> None:
        if _native_bip_write_binding(str(point.device)):
            result = write_present_value(
                str(point.device),
                POINT_TYPES[point.kind],
                point.instance,
                priority,
                "0",
                "",
                relinquish=True,
            )
            if not result.get("ok"):
                raise RuntimeError(str(result.get("message") or "BACnet relinquish was not acknowledged"))
            return
        out = run_bacnet([
            "./bacwp",
            str(point.device),
            POINT_TYPES[point.kind],
            str(point.instance),
            "present-value",
            str(max(1, min(16, int(priority or 16)))),
            "-1",
            "0",
            "0",
        ], timeout=10, ports=get_edge_program_scheduler_bacnet_ports(), preserve_ports=True)
        if "WriteProperty Acknowledged" not in out:
            raise RuntimeError(out or "BACnet relinquish was not acknowledged")


class EdgeProgramScheduler:
    """Gateway-local scan loop. BACnet access remains behind LocalEdgeProgramBacnetAdapter."""
    def __init__(self, store: ProgramStore, scan_seconds: float = 1.0):
        self.store = store
        self.scan_seconds = scan_seconds
        self._intervals: dict[int, dict[str, float]] = {}
        self._suppressors: dict[int, WriteSuppressor] = {}
        self._variables: dict[int, dict[str, float]] = {}
        self._edges: dict[int, dict[str, bool]] = {}
        self._timers: dict[int, dict[str, dict[str, Any]]] = {}
        self._last_scan: dict[int, float] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, name="edge-program-scheduler", daemon=True)
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.wait(self.scan_seconds):
            for program in self.store.enabled_compiled():
                program_id = int(program["id"])
                try:
                    compiled = json.loads(program["compiled_json"])
                    interval_values = re.findall(r"INTERVAL\((\d+(?:\.\d+)?)\)", json.dumps(compiled))
                    minimum_interval = min((float(value) for value in interval_values), default=self.scan_seconds)
                    now = time.monotonic()
                    if now - self._last_scan.get(program_id, -minimum_interval) < minimum_interval:
                        continue
                    self._last_scan[program_id] = now
                    snapshot = execute_program(
                        compiled, LocalEdgeProgramBacnetAdapter(), dry=False,
                        interval_state=self._intervals.setdefault(program_id, {}),
                        suppressor=self._suppressors.setdefault(program_id, WriteSuppressor()),
                        variable_state=self._variables.setdefault(program_id, {}),
                        edge_state=self._edges.setdefault(program_id, {}),
                        timer_state=self._timers.setdefault(program_id, {}),
                    )
                    self.store.record_execution(program_id, snapshot, "ok")
                except Exception as exc:
                    snapshot = type("Snapshot", (), {"reads": {}, "variables": {}, "writes": [], "duration_ms": 0})()
                    self.store.record_execution(program_id, snapshot, "error", str(exc))


class TimedOverrideScheduler:
    """Durable timed-override expiration loop.

    The loop only wakes to claim due database rows. BACnet locks are acquired
    inside the existing read/write helpers during each individual operation.
    """

    def __init__(self, store: TimedOverrideStore, scan_seconds: float = 5.0):
        self.store = store
        self.scan_seconds = scan_seconds
        self.worker_id = f"{socket.gethostname()}:{os.getpid()}:{uuid4().hex[:8]}"
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, name="timed-override-scheduler", daemon=True)
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.wait(self.scan_seconds):
            if in_safe_mode():
                continue
            for row in self.store.due_rows(limit=5):
                lock_until = (datetime.now(timezone.utc) + timedelta(seconds=45)).replace(microsecond=0).isoformat()
                claimed = self.store.claim(str(row["id"]), self.worker_id, lock_until)
                if not claimed:
                    continue
                try:
                    expire_timed_override(str(claimed["id"]), operator="scheduler")
                except Exception as exc:
                    self.store.retry_later(str(claimed["id"]), str(exc), delay_seconds=timed_override_retry_delay(int(claimed.get("attempt_count") or 0)), operator="scheduler")


BACNET_MODE_FILE = DATA_DIR / "bacnet_runtime_mode.txt"
BACNET_MODE_OPTIONS = [
    {"mode": "bac-rtr", "label": "BAC-RTR / 47809", "ports": ["47809"]},
    {"mode": "basrtb", "label": "BASRT-B / 47814", "ports": ["47814"]},
    {"mode": "dual-47809-first", "label": "Dual / 47809 then 47814", "ports": ["47809", "47814"]},
    {"mode": "dual-47814-first", "label": "Dual / 47814 then 47809", "ports": ["47814", "47809"]},
]
BACNET_MODE_BY_ID = {option["mode"]: option for option in BACNET_MODE_OPTIONS}


def get_bacnet_mode() -> str:
    try:
        mode = BACNET_MODE_FILE.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        mode = BACNET_DEFAULT_MODE
    except Exception:
        mode = BACNET_DEFAULT_MODE
    if mode not in BACNET_MODE_BY_ID:
        mode = "dual-47809-first" if "dual-47809-first" in BACNET_MODE_BY_ID else BACNET_MODE_OPTIONS[0]["mode"]
    return mode


def edge_router_enabled() -> bool:
    try:
        return routercfg.edge_router_enabled(routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS))
    except Exception:
        return False

def get_bacnet_ports() -> list[str]:
    if edge_router_enabled():
        try:
            return routercfg.active_bip_ports(routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS))
        except Exception:
            return list(BACNET_STARTUP_PORTS) or ["47809"]
    mode = get_bacnet_mode()
    ports = list(BACNET_MODE_BY_ID[mode]["ports"])
    return ports or list(BACNET_STARTUP_PORTS)


def get_edge_program_bacnet_ports() -> list[str]:
    """Use the UI/programming BACnet client port for routed local commands."""
    if edge_router_enabled():
        return list(BACNET_EDGE_PROGRAM_PORTS) or ["47816"]
    return get_bacnet_ports()


def get_edge_program_scheduler_bacnet_ports() -> list[str]:
    """Use a separate BACnet client port for background Edge Program scans."""
    if edge_router_enabled():
        return list(BACNET_EDGE_PROGRAM_SCHEDULER_PORTS) or ["47817"]
    return get_bacnet_ports()


def get_bacnet_port_label() -> str:
    return "/".join(get_bacnet_ports())


def set_bacnet_mode(mode: str) -> None:
    ensure_runtime_initialized()
    if mode not in BACNET_MODE_BY_ID:
        raise ValueError("Unsupported BACnet runtime mode.")
    BACNET_MODE_FILE.write_text(mode + "\n", encoding="utf-8")

TARGET_TYPES = {
    "analog-input",
    "analog-output",
    "analog-value",
    "binary-input",
    "binary-output",
    "binary-value",
    "multi-state-input",
    "multi-state-output",
    "multi-state-value",
    "schedule",
}

DAYS_OF_WEEK = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
]

# Friendly labels for the UI. bacrp still uses the canonical BACnet names above.
TYPE_LABELS = {
    "analog-input": "AI",
    "analog-output": "AO",
    "analog-value": "AV",
    "binary-input": "BI",
    "binary-output": "BO",
    "binary-value": "BV",
    "multi-state-input": "MSI",
    "multi-state-output": "MSO",
    "multi-state-value": "MSV",
    "schedule": "SCH",
}
TYPE_BY_LABEL = {label.lower(): obj_type for obj_type, label in TYPE_LABELS.items()}
TYPE_BY_LABEL["sched"] = "schedule"

app = Flask(__name__)


def load_flask_secret_key() -> str:
    configured = os.environ.get("FLASK_SECRET_KEY", "").strip()
    if configured:
        return configured
    if EDGE_UI_SAFE_MODE:
        return "local-safe-dev-secret"
    key_path = DATA_DIR / ".flask-secret-key"
    try:
        if key_path.exists():
            existing = key_path.read_text(encoding="utf-8").strip()
            if existing:
                return existing
        key_path.parent.mkdir(parents=True, exist_ok=True)
        generated = secrets.token_urlsafe(48)
        key_path.write_text(generated + "\n", encoding="utf-8")
        key_path.chmod(0o600)
        return generated
    except Exception:
        return secrets.token_urlsafe(48)


app.secret_key = load_flask_secret_key()
app.permanent_session_lifetime = timedelta(seconds=SESSION_TIMEOUT_SECONDS)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)

# In-memory progress tracking for template metadata scans.
# This keeps the UI responsive while BACnet object-list/name reads are running.
SCAN_JOBS: dict[str, dict[str, Any]] = {}
SCAN_LOCK = threading.Lock()
SCAN_JOB_RETENTION_SECONDS = int(os.environ.get("SCAN_JOB_RETENTION_SECONDS", "3600"))

# In-memory progress tracking for device discovery and template view reads.
DISCOVERY_JOBS: dict[str, dict[str, Any]] = {}
DISCOVERY_LOCK = threading.Lock()
VIEW_JOBS: dict[str, dict[str, Any]] = {}
VIEW_LOCK = threading.Lock()
CAPTURE_JOBS: dict[str, dict[str, Any]] = {}
CAPTURE_LOCK = threading.Lock()
DEVICE_PING_JOBS: dict[str, dict[str, Any]] = {}
DEVICE_PING_LOCK = threading.Lock()


# --- Global UI / gateway identity helpers ----------------------------------
def _run_ip_command(args: list[str]) -> str:
    if in_safe_mode():
        return ""
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=2,
        )
        return (result.stdout or "").strip()
    except Exception:
        return ""


def get_iface_mac(iface: str) -> str:
    """Return the MAC address for the requested interface."""
    try:
        mac_path = Path(f"/sys/class/net/{iface}/address")
        if mac_path.exists():
            mac = mac_path.read_text().strip()
            if mac and mac != "00:00:00:00:00:00":
                return mac.upper()
    except Exception:
        pass
    return "UNKNOWN"


def get_iface_ip(iface: str) -> str:
    """Return the IPv4 address for the requested interface when available."""
    output = _run_ip_command(["ip", "-4", "addr", "show", "dev", iface])
    match = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)", output)
    return match.group(1) if match else "UNKNOWN"


def get_iface_operstate(iface: str) -> str:
    try:
        state_path = Path(f"/sys/class/net/{iface}/operstate")
        if state_path.exists():
            return state_path.read_text().strip().upper()
    except Exception:
        pass
    return "UNKNOWN"


def get_request_interface() -> str:
    """Detect the NIC used for the current browser connection."""
    try:
        remote_addr = request.headers.get("X-Forwarded-For", request.remote_addr or "")
        remote_addr = remote_addr.split(",")[0].strip()
        if remote_addr:
            output = _run_ip_command(["ip", "-o", "route", "get", remote_addr])
            match = re.search(r"\bdev\s+(\S+)", output)
            if match:
                return match.group(1)
    except Exception:
        pass
    return ""


def get_configured_interface() -> str:
    """Allow a fixed NIC, such as enp1s0, to be set from the environment."""
    iface = os.environ.get("GATEWAY_IFACE", "").strip()
    if iface and Path(f"/sys/class/net/{iface}").exists():
        return iface
    return ""


def get_default_route_interface() -> str:
    output = _run_ip_command(["ip", "-o", "route", "show", "default"])
    match = re.search(r"\bdev\s+(\S+)", output)
    if match:
        return match.group(1)
    return ""


def get_first_active_interface() -> str:
    """Fallback for gateways without a default route."""
    candidates: list[str] = []
    try:
        for iface_path in Path("/sys/class/net").iterdir():
            iface = iface_path.name
            if iface == "lo" or iface.startswith(("docker", "veth", "br-")):
                continue
            ip_addr = get_iface_ip(iface)
            if ip_addr == "UNKNOWN":
                continue
            candidates.append(iface)
    except Exception:
        pass

    # Prefer common wired/internal gateway NIC names before Wi-Fi.
    preferred_prefixes = ("eth", "enp", "eno", "ens")
    for prefix in preferred_prefixes:
        for iface in candidates:
            if iface.startswith(prefix):
                return iface
    return candidates[0] if candidates else "UNKNOWN"


def get_gateway_identity() -> dict[str, str]:
    iface = (
        get_request_interface()
        or get_configured_interface()
        or get_default_route_interface()
        or get_first_active_interface()
    )

    if not iface:
        iface = "UNKNOWN"

    return {
        "interface": iface,
        "mac": get_iface_mac(iface) if iface != "UNKNOWN" else "UNKNOWN",
        "ip": get_iface_ip(iface) if iface != "UNKNOWN" else "UNKNOWN",
        "state": get_iface_operstate(iface) if iface != "UNKNOWN" else "UNKNOWN",
    }


@app.context_processor
def inject_global_template_values() -> dict[str, Any]:
    gateway = get_gateway_identity()
    return {
        "gateway_hostname": socket.gethostname(),
        "gateway_interface": gateway["interface"],
        "gateway_mac": gateway["mac"],
        "gateway_ip": gateway["ip"],
        "gateway_state": gateway["state"],
        "bacnet_port": get_bacnet_port_label(),
        "bacnet_mode": get_bacnet_mode(),
        "bacnet_mode_options": BACNET_MODE_OPTIONS,
        "copyright_date": "06/10/2026",
        "company_name": "The Internet of Team, LLC",
        "brand_logo_url": "" if in_safe_mode() else "https://iofteam.com/logo.png",
        "safe_mode_enabled": in_safe_mode(),
        "edge_ui_version": EDGE_UI_VERSION,
        "edge_trends_ui_enabled": EDGE_TRENDS_UI_ENABLED,
    }


# --- BACnet-stack helpers ---------------------------------------------------
BACNET_LOCK_DIR = Path(os.environ.get("BACNET_LOCK_DIR", "/tmp"))


def _bacnet_lock_path(port: str) -> Path:
    explicit = os.environ.get("BACNET_LOCK_PATH", "").strip()
    if explicit:
        return Path(explicit)
    if edge_router_enabled() and port == "47814":
        return BACNET_LOCK_DIR / "iot-cloud-commissioning-bacnet-47814.lock"
    return BACNET_LOCK_DIR / f"iot-edge-bacnet-{port}.lock"


def _lock_is_stale(lock_path: Path) -> bool:
    try:
        payload = json.loads(lock_path.read_text(encoding="utf-8") or "{}")
        pid = int(payload.get("pid", 0))
    except Exception:
        return True
    if pid <= 0:
        return True
    if payload.get("owner") == "edge-bacnet-ui":
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return True
        except PermissionError:
            pass
        except OSError:
            return True
        try:
            return (time.time() - lock_path.stat().st_mtime) > 30
        except OSError:
            return True
    try:
        os.kill(pid, 0)
        return False
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    except OSError:
        return True


def _take_bacnet_lock(owner: str, port: str, wait_seconds: float = 0) -> Path:
    """Claim the local commissioning BACnet runtime lock.

    The cloud edge agent uses the same lock path and must yield while this file exists.
    """
    lock_path = _bacnet_lock_path(port)
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + max(0, wait_seconds)
    while True:
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            break
        except FileExistsError:
            if _lock_is_stale(lock_path):
                lock_path.unlink(missing_ok=True)
                continue
            if time.monotonic() >= deadline:
                raise
            time.sleep(0.1)
    with os.fdopen(fd, "w", encoding="utf-8") as lock_file:
        lock_file.write(
            json.dumps(
                {
                    "owner": owner,
                    "pid": os.getpid(),
                    "port": port,
                    "message": f"Local commissioning UI owns BACnet port {port}.",
                }
            )
        )
    return lock_path


def _release_bacnet_lock(lock_path: Path) -> None:
    try:
        lock_path.unlink()
    except FileNotFoundError:
        pass


def _bacnet_output_failed(output: str) -> bool:
    bad_markers = ("BACnet Error", "BACnet Abort", "Error:", "APDU Timeout", "BACnet runtime is busy")
    return any(marker in output for marker in bad_markers)


def _bacnet_output_busy(output: str) -> bool:
    return "BACnet runtime is busy" in str(output or "")


def bacnet_runtime_busy_message() -> str:
    busy_ports: list[str] = []
    for port in get_bacnet_ports():
        lock_path = _bacnet_lock_path(port)
        if lock_path.exists() and not _lock_is_stale(lock_path):
            busy_ports.append(port)
    if not busy_ports:
        return ""
    ports = ", ".join(busy_ports)
    return f"BACnet runtime is busy. Another local BACnet command is already using UDP {ports}."


def get_cached_bacnet_port(device_id: str) -> str:
    authoritative = get_router_authoritative_bacnet_request_route(str(device_id))
    if authoritative:
        _route_args, ports = authoritative
        if ports:
            return ports[0]
    saved_native = get_saved_native_bip_request_route(str(device_id))
    if saved_native:
        _route_args, ports = saved_native
        if ports:
            return ports[0]
    try:
        cache_file = CACHE_DIR / "last_discovery.json"
        data = json.loads(cache_file.read_text())
        for device in data.get("devices", []):
            if str(device.get("device")) == str(device_id):
                port = str(device.get("bacnet_port", "")).strip()
                if port:
                    return port
    except Exception:
        pass
    return ""


def _active_edge_router_bip(config: dict[str, Any]) -> dict[str, Any]:
    return next((item for item in config.get("bip_interfaces") or [] if item.get("enabled")), {})


def _router_authoritative_route_from_status(device_id: str, config: dict[str, Any]) -> tuple[list[str], list[str]] | None:
    """Return the authoritative local-router path for routed MS/TP devices.

    Discovery caches may contain legacy BASRT-B routes. While the persistent Edge
    router is enabled, the live router status is the source of truth for MS/TP
    devices: local client 47816 -> router 192.168.1.200:47809 -> DNET/SADR.
    """
    target = str(device_id).strip()
    if not target:
        return None
    bip = _active_edge_router_bip(config)
    if not bip:
        return None
    router_mac = f"{bip.get('bind_address') or '127.0.0.1'}:{int(bip.get('udp_port') or 47809)}"
    status = routercfg.load_mstp_status(DATA_DIR)

    for line in status.get("route_table") or []:
        match = re.search(r"device\s+(\d+)\s+via\s+network\s+(\d+)\s+address\s+([0-9A-Fa-f]+)", str(line))
        if match and match.group(1) == target:
            return (
                ["--mac", router_mac, "--dnet", match.group(2), "--dadr", match.group(3).upper()],
                get_edge_program_bacnet_ports(),
            )

    for trunk in config.get("mstp_trunks") or []:
        if not trunk.get("enabled"):
            continue
        dnet = str(trunk.get("network_number") or "").strip()
        trunk_status = (status.get("trunks") or {}).get(trunk.get("id")) or {}
        for mac, entry in (trunk_status.get("macs") or {}).items():
            if str(entry.get("device_instance") or "").strip() == target:
                try:
                    dadr = f"{int(str(mac), 0):02X}"
                except Exception:
                    dadr = str(mac).strip().upper()
                return (
                    ["--mac", router_mac, "--dnet", dnet, "--dadr", dadr],
                    get_edge_program_bacnet_ports(),
                )
    return None


def get_router_authoritative_bacnet_request_route(device_id: str) -> tuple[list[str], list[str]] | None:
    if not edge_router_enabled():
        return None
    try:
        config = routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS)
    except Exception:
        return None
    if not routercfg.edge_router_enabled(config):
        return None
    return _router_authoritative_route_from_status(str(device_id), config)


def _route_args_from_cached_route(route: dict[str, str]) -> list[str]:
    mac = route.get("native_bip_endpoint") or route.get("mac", "")
    snet = route.get("snet", "")
    sadr = route.get("sadr", "")
    args: list[str] = []
    if mac:
        args.extend(["--mac", mac])
    # A six-octet SADR is a native BACnet/IP endpoint, not an MS/TP DADR.
    if route.get("native_bip_endpoint"):
        return args
    # Include DNET/DADR only for routed devices. Local devices usually report SNET 0.
    if snet and snet != "0" and sadr and sadr not in {"00", "0"}:
        args.extend(["--dnet", snet, "--dadr", sadr])
    return args


def get_saved_native_bip_route(device_id: str) -> dict[str, str]:
    """Return direct native BACnet/IP route data from a saved device profile.

    Legacy BASRT-B kept-device records can encode the actual native BACnet/IP
    endpoint in SADR while MAC points at the legacy router. When SADR decodes as
    six BACnet/IP octets, prefer that endpoint directly and do not carry DNET/DADR.
    """
    try:
        saved_device = find_saved_device_for_device_id(str(device_id))
    except Exception:
        saved_device = None
    if not saved_device:
        return {}
    meta = saved_device.get("meta") if isinstance(saved_device.get("meta"), dict) else {}
    sadr = str(meta.get("sadr", "")).strip()
    native_endpoint = _bacnet_ip_mac_to_ip_port(sadr)
    if not native_endpoint:
        return {}
    return {
        "mac": _bacnet_ip_mac_to_ip_port(str(meta.get("mac", "")).strip()) or str(meta.get("mac", "")).strip(),
        "native_bip_endpoint": native_endpoint,
        "snet": str(meta.get("snet", "")).strip(),
        "sadr": sadr,
        "apdu": str(meta.get("apdu", "")).strip(),
        "bacnet_port": str(meta.get("bacnet_port", "")).strip(),
        "source": "saved-device-native-bip",
    }


def get_saved_native_bip_request_route(device_id: str) -> tuple[list[str], list[str]] | None:
    route = get_saved_native_bip_route(str(device_id))
    if not route:
        return None
    return _route_args_from_cached_route(route), get_edge_program_bacnet_ports()


def _native_bip_write_binding(device_id: str) -> dict[str, str]:
    """Return a direct native BACnet/IP binding for bacwp address_cache use."""
    route = get_cached_bacnet_route(str(device_id))
    endpoint = str(route.get("native_bip_endpoint") or "").strip()
    if not endpoint:
        snet = str(route.get("snet", "")).strip()
        sadr = str(route.get("sadr", "")).strip()
        mac = str(route.get("mac", "")).strip()
        if snet in {"", "0"} and sadr in {"", "00", "0"}:
            endpoint = mac
    if not endpoint:
        return {}
    host, sep, port = endpoint.rpartition(":")
    if not sep or not host or not port.isdigit():
        return {}
    try:
        ipaddress.ip_address(host)
    except ValueError:
        return {}
    port_int = int(port)
    if not 1 <= port_int <= 65535:
        return {}
    apdu = str(route.get("apdu") or "").strip()
    if not apdu.isdigit():
        apdu = "1476"
    return {
        "device_id": str(device_id),
        "endpoint": endpoint,
        "snet": "0",
        "sadr": "0",
        "apdu": apdu,
    }


def get_cached_bacnet_request_route(device_id: str) -> tuple[list[str], list[str] | None]:
    """Return directed route args and preferred local port from discovery cache."""
    target = str(device_id).strip()
    authoritative = get_router_authoritative_bacnet_request_route(target)
    if authoritative:
        return authoritative
    saved_native = get_saved_native_bip_request_route(target)
    if saved_native:
        return saved_native
    try:
        cache_file = CACHE_DIR / "last_discovery.json"
        data = json.loads(cache_file.read_text())
        for device in data.get("devices", []):
            if str(device.get("device")) != target:
                continue
            port = str(device.get("bacnet_port", "")).strip()
            ports = [port] if port.isdigit() else None
            snet = str(device.get("snet", "")).strip()
            sadr = str(device.get("sadr", "")).strip()
            router = str(device.get("router", "")).strip() or _bacnet_ip_mac_to_ip_port(str(device.get("mac", "")))
            native_endpoint = _bacnet_ip_mac_to_ip_port(sadr)
            route = {
                "mac": router,
                "native_bip_endpoint": native_endpoint,
                "snet": snet,
                "sadr": sadr,
            }
            args = _route_args_from_cached_route(route)
            if args and native_endpoint and edge_router_enabled():
                return args, get_edge_program_bacnet_ports()
            return args, ports
    except Exception:
        pass
    return [], None


def _strip_bacnet_route_args(args: list[str]) -> list[str]:
    cleaned: list[str] = []
    skip_next = False
    route_flags = {"--mac", "--dnet", "--dadr"}
    for item in args:
        if skip_next:
            skip_next = False
            continue
        if item in route_flags:
            skip_next = True
            continue
        cleaned.append(item)
    return cleaned


def _authoritative_command_route(args: list[str]) -> tuple[list[str], list[str] | None] | None:
    command_name = Path(str(args[0])).name if args else ""
    if command_name not in {"bacrp", "bacrpm", "bacwp"}:
        return None
    if len(args) < 2 or not str(args[1]).isdigit():
        return None
    route_args, ports = get_cached_bacnet_request_route(str(args[1]))
    if route_args or ports is not None:
        return route_args, ports
    return None


def _prepare_bacnet_command(
    args: list[str],
    ports: list[str] | None = None,
    *,
    preserve_ports: bool = False,
) -> tuple[list[str], list[str] | None]:
    authoritative = _authoritative_command_route(args)
    if not authoritative:
        return args, ports
    route_args, route_ports = authoritative
    prepared = _strip_bacnet_route_args(list(args))
    if Path(str(prepared[0])).name == "bacwp" and route_args:
        prepared = [prepared[0], *route_args, *prepared[1:]]
    else:
        prepared.extend(route_args)
    if preserve_ports and ports:
        return prepared, list(ports)
    return prepared, list(route_ports) if route_ports else ports


def _command_ports(args: list[str], ports: list[str] | None = None, *, preserve_ports: bool = False) -> list[str]:
    ports = list(ports) if ports else get_bacnet_ports()
    if preserve_ports and ports:
        return list(ports)
    authoritative = _authoritative_command_route(args)
    if authoritative and authoritative[1]:
        return list(authoritative[1])
    if len(args) > 1 and str(args[1]).isdigit():
        cached_port = get_cached_bacnet_port(str(args[1]))
        if cached_port and cached_port not in ports and edge_router_enabled():
            ports = [cached_port] + ports
        elif cached_port and cached_port in ports:
            ports = [cached_port] + [port for port in ports if port != cached_port]
    return ports


def _run_bacnet_once(args: list[str], timeout: int, port: str) -> str:
    block_live_operation("BACnet command execution")
    env = os.environ.copy()
    env["BACNET_IP_PORT"] = port
    if edge_router_enabled() and port not in (BACNET_IP_DISCOVERY_PORTS or []):
        env["BACNET_BBMD_ADDRESS"] = "192.168.1.200"
        env["BACNET_BBMD_PORT"] = "47809"

    try:
        lock_path = _take_bacnet_lock("edge-bacnet-ui", port, wait_seconds=min(max(timeout, 1), 30))
    except FileExistsError:
        return f"BACnet runtime is busy. Another local BACnet command is already using UDP {port}."

    try:
        process = subprocess.Popen(
            args,
            cwd=BACNET_BIN,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,
        )
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                stdout, stderr = process.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                stdout, stderr = process.communicate()
            return ((stdout or "") + (stderr or "") + f"\nBACnet command timed out after {timeout} seconds.").strip()
        return ((stdout or "") + (stderr or "")).strip()
    finally:
        _release_bacnet_lock(lock_path)


def run_bacnet(
    args: list[str],
    timeout: int = 8,
    ports: list[str] | None = None,
    *,
    preserve_ports: bool = False,
) -> str:
    """Run a bacnet-stack command, trying configured BACnet/IP ports as needed."""
    args, ports = _prepare_bacnet_command(list(args), ports=ports, preserve_ports=preserve_ports)
    if args and args[0] == "./bacwi":
        outputs = []
        for port in (list(ports) if ports else get_bacnet_ports()):
            out = _run_bacnet_once(args, timeout=timeout, port=port)
            outputs.append(f"; BACNET_PORT {port}\n{out}")
        return "\n".join(outputs).strip()

    last_output = ""
    for port in _command_ports(args, ports=ports, preserve_ports=preserve_ports):
        out = _run_bacnet_once(args, timeout=timeout, port=port)
        last_output = out
        if not _bacnet_output_failed(out):
            return out
    return last_output


def run_bacnet_detailed(
    args: list[str],
    timeout: int = 8,
    ports: list[str] | None = None,
    *,
    preserve_ports: bool = False,
    prepare_route: bool = True,
    cwd: str | Path | None = None,
) -> dict[str, Any]:
    """Run a bacnet-stack command and retain command/stdout/stderr/return-code diagnostics."""
    block_live_operation("BACnet command execution")
    if prepare_route:
        prepared, prepared_ports = _prepare_bacnet_command(list(args), ports=ports, preserve_ports=preserve_ports)
    else:
        prepared, prepared_ports = list(args), ports
    port_list = _command_ports(prepared, ports=prepared_ports, preserve_ports=preserve_ports)
    command_cwd = str(cwd or BACNET_BIN)
    last: dict[str, Any] = {}
    for port in port_list:
        started = time.monotonic()
        env = os.environ.copy()
        env["BACNET_IP_PORT"] = port
        if edge_router_enabled() and port not in (BACNET_IP_DISCOVERY_PORTS or []):
            env["BACNET_BBMD_ADDRESS"] = "192.168.1.200"
            env["BACNET_BBMD_PORT"] = "47809"
        try:
            lock_path = _take_bacnet_lock("edge-bacnet-ui", port, wait_seconds=min(max(timeout, 1), 30))
        except FileExistsError:
            last = {
                "args": prepared,
                "port": port,
                "returncode": None,
                "stdout": "",
                "stderr": f"BACnet runtime is busy. Another local BACnet command is already using UDP {port}.",
                "elapsed_sec": round(time.monotonic() - started, 3),
            }
            continue
        try:
            process = subprocess.Popen(
                prepared,
                cwd=command_cwd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                start_new_session=True,
            )
            timed_out = False
            try:
                stdout, stderr = process.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    stdout, stderr = process.communicate(timeout=2)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    stdout, stderr = process.communicate()
                stderr = (stderr or "") + f"\nBACnet command timed out after {timeout} seconds."
            output = ((stdout or "") + (stderr or "")).strip()
            last = {
                "args": prepared,
                "port": port,
                "returncode": process.returncode,
                "stdout": stdout or "",
                "stderr": stderr or "",
                "elapsed_sec": round(time.monotonic() - started, 3),
                "timed_out": timed_out,
                "output": output,
            }
            if not _bacnet_output_failed(output):
                return last
        finally:
            _release_bacnet_lock(lock_path)
    return last


def _run_native_bip_command_with_address_cache(
    command: list[str],
    binding: dict[str, str],
    *,
    timeout: int = 20,
    ports: list[str] | None = None,
) -> dict[str, Any]:
    """Run a native BACnet/IP command with a per-command static address binding."""
    temp_dir = Path(tempfile.mkdtemp(prefix="edge-native-bacwp-"))
    address_cache = temp_dir / "address_cache"
    cache_line = (
        f"{binding['device_id']} {binding['endpoint']} "
        f"{binding.get('snet') or '0'} {binding.get('sadr') or '0'} {binding.get('apdu') or '1476'}"
    )
    try:
        address_cache.write_text(cache_line + "\n", encoding="utf-8")
        absolute_command = list(command)
        if absolute_command and Path(str(absolute_command[0])).name == "bacwp":
            absolute_command[0] = str(Path(BACNET_BIN) / "bacwp")
        detail = run_bacnet_detailed(
            absolute_command,
            timeout=timeout,
            ports=ports or get_edge_program_bacnet_ports(),
            preserve_ports=True,
            prepare_route=False,
            cwd=temp_dir,
        )
        detail["native_bip_address_cache"] = cache_line
        detail["native_bip_address_cache_cwd"] = str(temp_dir)
        return detail
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def _run_native_bip_bacwp_with_address_cache(
    command: list[str],
    binding: dict[str, str],
    *,
    timeout: int = 20,
    ports: list[str] | None = None,
) -> dict[str, Any]:
    return _run_native_bip_command_with_address_cache(command, binding, timeout=timeout, ports=ports)


def _native_bip_read_property_for_write_snapshot(
    binding: dict[str, str],
    obj_type: str,
    instance: str | int,
    prop: str,
    *,
    timeout: int = 8,
) -> str:
    command = [
        str(Path(BACNET_BIN) / "bacrp"),
        str(binding["device_id"]),
        obj_type,
        str(instance),
        prop,
    ]
    detail = _run_native_bip_command_with_address_cache(
        command,
        binding,
        timeout=timeout,
        ports=get_edge_program_bacnet_ports(),
    )
    return str(detail.get("output") or "")


def read_priority_snapshot_native_bip(
    binding: dict[str, str],
    obj_type: str,
    instance: str | int,
) -> dict[str, str]:
    obj_type = normalize_pv_write_type(obj_type)
    object_name = _native_bip_read_property_for_write_snapshot(binding, obj_type, instance, "object-name")
    raw_pv = (
        _native_bip_read_property_for_write_snapshot(binding, obj_type, instance, "present-value")
        or _native_bip_read_property_for_write_snapshot(binding, obj_type, instance, "85")
    )
    priority_array = _native_bip_read_property_for_write_snapshot(binding, obj_type, instance, "priority-array")
    active_priority = active_priority_from_array(priority_array)
    display_pv = raw_pv
    states: list[str] = []
    if obj_type in MULTI_STATE_TYPES:
        raw_states = _native_bip_read_property_for_write_snapshot(binding, obj_type, instance, "state-text")
        states = parse_state_text(raw_states) if not _bacnet_output_failed(raw_states) else []
        display_pv = format_present_value_cached(raw_pv, obj_type, states)
    relinquish_default = (
        _native_bip_read_property_for_write_snapshot(binding, obj_type, instance, "relinquish-default")
        or _native_bip_read_property_for_write_snapshot(binding, obj_type, instance, "104")
    )
    return {
        "object_name": object_name,
        "present_value": pv_with_priority(display_pv, active_priority),
        "display_present_value": display_pv,
        "raw_present_value": raw_pv,
        "active_priority": active_priority,
        "state_text": ", ".join([f"{idx + 1}={name}" for idx, name in enumerate(states)]),
        "state_options": states,
        "selected_state": str(parse_numeric_present_value(raw_pv) or ""),
        "priority_array": priority_array,
        "relinquish_default": relinquish_default,
    }


def clean(value: str | None) -> str:
    if not value:
        return ""
    value = value.strip()
    # bacrp commonly returns strings wrapped in quotes.
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        value = value[1:-1]
    return value.strip()




def safe_int(value: str | None, default: int, minimum: int = 1, maximum: int | None = None) -> int:
    """Parse a positive integer from the UI/environment and clamp it safely."""
    try:
        parsed = int(value) if value not in (None, "") else int(default)
    except (TypeError, ValueError):
        parsed = int(default)

    parsed = max(minimum, parsed)
    if maximum is not None:
        parsed = min(parsed, maximum)
    return parsed

def safe_read(args: list[str], timeout: int = 6, ports: list[str] | None = None) -> str:
    try:
        out = run_bacnet(args, timeout=timeout, ports=ports)
        if _bacnet_output_failed(out):
            return ""
        return clean(out)
    except Exception:
        return ""


def read_property(
    device_id: str,
    obj_type: str,
    instance: str | int,
    prop: str,
    timeout: int = 6,
    ports: list[str] | None = None,
    route_args: list[str] | None = None,
    array_index: int | str | None = None,
) -> str:
    if route_args is None and ports is None:
        route_args, ports = get_cached_bacnet_request_route(str(device_id))
    args = ["./bacrp", str(device_id), obj_type, str(instance), prop]
    if array_index is not None:
        args.append(str(array_index))
    if route_args:
        args.extend(route_args)
    return safe_read(args, timeout=timeout, ports=ports)


def read_device_metadata(
    device_id: str,
    *,
    route_args: list[str] | None = None,
    ports: list[str] | None = None,
) -> dict[str, str]:
    return {
        "device": str(device_id),
        "name": read_property(str(device_id), "device", str(device_id), "object-name", route_args=route_args, ports=ports),
        "vendor": read_property(str(device_id), "device", str(device_id), "vendor-name", route_args=route_args, ports=ports),
        "model": read_property(str(device_id), "device", str(device_id), "model-name", route_args=route_args, ports=ports),
    }


def cached_device_metadata(device_id: str) -> dict[str, str]:
    """Return last-known discovery metadata without issuing BACnet reads."""
    target = str(device_id).strip()
    for device in load_kept_devices():
        if str(device.get("device", "")).strip() == target:
            return {
                "device": target,
                "name": str(device.get("name") or ""),
                "vendor": str(device.get("vendor") or ""),
                "model": str(device.get("model") or ""),
            }
    try:
        cache_file = CACHE_DIR / "last_discovery.json"
        data = json.loads(cache_file.read_text())
        for device in data.get("devices", []) or []:
            if str(device.get("device", "")).strip() == target:
                return {
                    "device": target,
                    "name": str(device.get("name") or ""),
                    "vendor": str(device.get("vendor") or ""),
                    "model": str(device.get("model") or ""),
                }
    except Exception:
        pass
    return {"device": target, "name": "", "vendor": "", "model": ""}


def saved_live_device_metadata(device_id: str, saved_device: dict[str, Any] | None) -> dict[str, str]:
    """Return saved/cache metadata for a Live Device refresh without BACnet I/O."""
    target = str(device_id).strip()
    meta = cached_device_metadata(target)
    if isinstance(saved_device, dict):
        saved_meta = saved_device.get("meta") if isinstance(saved_device.get("meta"), dict) else {}
        meta.update({
            "device": target,
            "name": str(saved_meta.get("name") or saved_device.get("device_name") or meta.get("name") or ""),
            "vendor": str(saved_meta.get("vendor") or saved_device.get("vendor") or meta.get("vendor") or ""),
            "model": str(saved_meta.get("model") or saved_device.get("model") or meta.get("model") or ""),
        })
    else:
        meta["device"] = target
    return meta


# --- Packet capture helpers -------------------------------------------------
def tcpdump_path() -> str:
    return shutil.which("tcpdump") or "/usr/bin/tcpdump"


def tcpdump_available() -> bool:
    path = tcpdump_path()
    return bool(path and Path(path).exists())


def get_capture_interfaces() -> list[str]:
    interfaces: list[str] = []
    try:
        result = subprocess.run(
            ["ip", "-4", "-o", "addr", "show", "up"],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
        for line in (result.stdout or "").splitlines():
            match = re.match(r"\d+:\s+([^ ]+)\s+inet\s+", line)
            if not match:
                continue
            iface = match.group(1)
            if iface == "lo" or iface.startswith(("docker", "veth", "br-")):
                continue
            if iface not in interfaces:
                interfaces.append(iface)
    except Exception:
        pass

    preferred = get_configured_interface() or get_default_route_interface() or get_first_active_interface()
    if preferred in interfaces:
        interfaces.remove(preferred)
        interfaces.insert(0, preferred)
    if "any" not in interfaces:
        interfaces.append("any")
    return interfaces


def capture_filter_expression(filter_mode: str, custom_filter: str = "") -> str:
    mode = (filter_mode or "both").strip().lower()
    if mode == "47808":
        return "udp port 47808"
    if mode == "47809":
        return "udp port 47809"
    if mode == "47814":
        return "udp port 47814"
    if mode == "47816":
        return "udp port 47816"
    if mode == "udp":
        return "udp"
    if mode == "custom":
        custom = (custom_filter or "").strip()
        if not custom:
            raise ValueError("Custom capture filter is blank.")
        if len(custom) > 240:
            raise ValueError("Custom capture filter is too long.")
        return custom
    ports = list(dict.fromkeys(get_bacnet_ports()))
    return " or ".join(f"udp port {port}" for port in ports)


def list_capture_files() -> list[dict[str, Any]]:
    files: list[dict[str, Any]] = []
    for path in sorted(CAPTURE_DIR.glob("*.pcap"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True):
        try:
            stat = path.stat()
            files.append({
                "filename": path.name,
                "size": stat.st_size,
                "size_label": format_bytes(stat.st_size),
                "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            })
        except Exception:
            continue
    return files


def format_bytes(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{size} B"


def active_capture_jobs() -> list[dict[str, Any]]:
    jobs: list[dict[str, Any]] = []
    now = time.time()
    with CAPTURE_LOCK:
        for job_id, job in list(CAPTURE_JOBS.items()):
            proc = job.get("process")
            running = bool(proc and proc.poll() is None)
            if not running and job.get("status") == "running":
                job["status"] = "completed" if proc and proc.returncode == 0 else f"stopped ({getattr(proc, 'returncode', '')})"
                job["ended_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            elapsed = max(0, int(now - float(job.get("started_epoch", now))))
            jobs.append({
                "job_id": job_id,
                "filename": job.get("filename", ""),
                "interface": job.get("interface", ""),
                "filter": job.get("filter", ""),
                "duration": job.get("duration", 0),
                "status": job.get("status", "unknown"),
                "started_at": job.get("started_at", ""),
                "ended_at": job.get("ended_at", ""),
                "elapsed": elapsed,
                "running": running,
            })
    return sorted(jobs, key=lambda j: j.get("started_at", ""), reverse=True)


def stop_capture_process(job_id: str) -> bool:
    with CAPTURE_LOCK:
        job = CAPTURE_JOBS.get(job_id)
        proc = job.get("process") if job else None
    if not job or not proc:
        return False
    if proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=3)
    with CAPTURE_LOCK:
        job["status"] = "stopped"
        job["ended_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return True


def _auto_stop_capture(job_id: str, duration: int) -> None:
    if duration <= 0:
        return
    time.sleep(duration)
    with CAPTURE_LOCK:
        job = CAPTURE_JOBS.get(job_id)
        proc = job.get("process") if job else None
    if job and proc and proc.poll() is None:
        stop_capture_process(job_id)
        with CAPTURE_LOCK:
            if job_id in CAPTURE_JOBS:
                CAPTURE_JOBS[job_id]["status"] = "completed"


def start_capture_job(interface: str, filter_expression: str, duration: int) -> dict[str, Any]:
    block_live_operation("Packet capture")
    if not tcpdump_available():
        raise FileNotFoundError("tcpdump is not installed. Run: sudo apt install -y tcpdump")

    allowed_interfaces = set(get_capture_interfaces())
    if interface not in allowed_interfaces:
        raise ValueError(f"Invalid capture interface: {interface}")

    duration = safe_int(str(duration), 60, minimum=0, maximum=3600)
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"bacnet-capture-{timestamp}-{uuid4().hex[:8]}.pcap"
    output_path = CAPTURE_DIR / filename

    cmd = [
        tcpdump_path(),
        "-i", interface,
        "-nn",
        "-s", "0",
        "-U",
        "-w", str(output_path),
    ] + shlex.split(filter_expression)

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        cwd=str(CAPTURE_DIR),
    )
    time.sleep(0.25)
    if proc.poll() is not None:
        stderr = proc.stderr.read() if proc.stderr else ""
        raise RuntimeError(stderr.strip() or "tcpdump exited immediately.")

    job_id = uuid4().hex
    job = {
        "job_id": job_id,
        "filename": filename,
        "interface": interface,
        "filter": filter_expression,
        "duration": duration,
        "status": "running",
        "started_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "started_epoch": time.time(),
        "process": proc,
        "cmd": cmd,
    }
    with CAPTURE_LOCK:
        CAPTURE_JOBS[job_id] = job

    if duration > 0:
        threading.Thread(target=_auto_stop_capture, args=(job_id, duration), daemon=True).start()
    return {k: v for k, v in job.items() if k not in {"process", "cmd"}}


# --- Kept device helpers ----------------------------------------------------
def _normalize_device_record(device: dict[str, Any]) -> dict[str, Any]:
    """Return a stable device record shape for discovered/kept device rows."""
    return {
        "device": str(device.get("device", "")).strip(),
        "mac": str(device.get("mac", "")).strip(),
        "snet": str(device.get("snet", "")).strip(),
        "sadr": str(device.get("sadr", "")).strip(),
        "apdu": str(device.get("apdu", "")).strip(),
        "bacnet_port": str(device.get("bacnet_port", "")).strip() or get_bacnet_ports()[0],
        "name": str(device.get("name", "")).strip(),
        "vendor": str(device.get("vendor", "")).strip(),
        "model": str(device.get("model", "")).strip(),
        "kept": bool(device.get("kept", False)),
        "source": str(device.get("source", "")).strip() or "discovered",
        "last_seen": str(device.get("last_seen", "")).strip(),
    }


def load_kept_devices() -> list[dict[str, Any]]:
    try:
        data = json.loads(KEPT_DEVICE_FILE.read_text())
        devices = data.get("devices", []) if isinstance(data, dict) else data
    except Exception:
        devices = []

    normalized: dict[str, dict[str, Any]] = {}
    for device in devices:
        if not isinstance(device, dict):
            continue
        row = _normalize_device_record(device)
        device_id = row.get("device", "")
        if device_id:
            row["kept"] = True
            row["source"] = row.get("source") or "kept"
            normalized[device_id] = row
    return sorted(normalized.values(), key=lambda d: int(d["device"]) if str(d.get("device", "")).isdigit() else 999999999)


def save_kept_devices(devices: list[dict[str, Any]]) -> None:
    ensure_runtime_initialized()
    normalized: dict[str, dict[str, Any]] = {}
    for device in devices:
        row = _normalize_device_record(device)
        device_id = row.get("device", "")
        if not device_id:
            continue
        row["kept"] = True
        row["source"] = "kept"
        normalized[device_id] = row
    payload = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "devices": sorted(normalized.values(), key=lambda d: int(d["device"]) if str(d.get("device", "")).isdigit() else 999999999),
    }
    KEPT_DEVICE_FILE.write_text(json.dumps(payload, indent=2))


def upsert_kept_devices(devices: list[dict[str, Any]]) -> list[dict[str, Any]]:
    kept = {d["device"]: d for d in load_kept_devices() if d.get("device")}
    now = datetime.now().isoformat(timespec="seconds")
    for device in devices:
        row = _normalize_device_record(device)
        device_id = row.get("device", "")
        if not device_id:
            continue
        previous = kept.get(device_id, {})
        merged = {**previous, **{k: v for k, v in row.items() if v not in ("", None)}}
        merged["device"] = device_id
        merged["kept"] = True
        merged["source"] = "kept"
        merged["last_seen"] = now
        kept[device_id] = _normalize_device_record(merged)
    save_kept_devices(list(kept.values()))
    return load_kept_devices()


def parse_filter_values(value: str) -> set[str]:
    values: set[str] = set()
    for part in re.split(r"[\s,;]+", value or ""):
        part = part.strip()
        if part:
            values.add(part)
    return values


def filter_discovery_candidates(
    candidates: list[dict[str, str]],
    device_filter: set[str] | None = None,
    network_filter: set[str] | None = None,
    include_kept: bool = False,
) -> list[dict[str, str]]:
    kept_ids = {str(d.get("device", "")) for d in load_kept_devices()}
    filtered: list[dict[str, str]] = []
    for item in candidates:
        device_id = str(item.get("device", ""))
        snet = str(item.get("snet", ""))
        if device_filter and device_id not in device_filter:
            continue
        if network_filter and snet not in network_filter:
            continue
        if not include_kept and device_id in kept_ids:
            continue
        filtered.append(item)
    return filtered


def _bacnet_ip_mac_to_ip_port(mac_hex: str) -> str:
    """Convert BACnet/IP hex MAC from bacwi into ip:port for directed requests.

    bacwi prints BACnet/IP MAC as six hex octets. The first four are the IPv4
    address and the last two are the UDP port. Example:
    C0:A8:01:66:BA:C0 -> 192.168.1.102:47808.
    """
    parts = [p for p in re.split(r"[:\-\s]+", (mac_hex or "").strip()) if p]
    if len(parts) != 6:
        return ""
    try:
        values = [int(part, 16) for part in parts]
        ip = ".".join(str(v) for v in values[:4])
        port = values[4] * 256 + values[5]
        return f"{ip}:{port}"
    except ValueError:
        return ""


def _decode_bacnet_route_fields(mac_hex: str, snet: str, sadr_hex: str) -> dict[str, str]:
    """Decode bacwi MAC/SNET/SADR into operator-friendly route text."""
    router = _bacnet_ip_mac_to_ip_port(mac_hex) or (mac_hex or "").strip()
    sadr = (sadr_hex or "").strip()
    snet_text = str(snet or "").strip()
    decoded_sadr = _bacnet_ip_mac_to_ip_port(sadr)

    if decoded_sadr:
        decoded_address = decoded_sadr
        media = "BACnet/IP"
    elif sadr:
        parts = [p for p in re.split(r"[:\-\s]+", sadr) if p]
        if len(parts) == 1:
            try:
                decoded_address = f"MS/TP MAC {int(parts[0], 16)}"
            except ValueError:
                decoded_address = f"MS/TP MAC {sadr}"
        else:
            decoded_address = sadr
        media = "MS/TP / routed"
    else:
        decoded_address = "Local / direct"
        media = "Local"

    if snet_text and decoded_address.startswith("MS/TP MAC"):
        decoded_address = f"{decoded_address} on network {snet_text}"

    return {
        "router": router,
        "network": snet_text,
        "sadr_decoded": decoded_address,
        "media": media,
    }


def _parse_bacwi_candidates(raw: str) -> list[dict[str, str]]:
    """Parse bacwi I-Am table without reading extra device metadata."""
    candidates: list[dict[str, str]] = []
    current_port = get_bacnet_ports()[0]
    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("; BACNET_PORT"):
            parts = line.split()
            if len(parts) >= 3:
                current_port = parts[2]
            continue
        if not line or line.startswith(";"):
            continue
        parts = line.split()
        if len(parts) < 5 or not parts[0].isdigit():
            continue
        item = {
            "device": parts[0],
            "mac": parts[1],
            "snet": parts[2],
            "sadr": parts[3],
            "apdu": parts[4],
            "bacnet_port": current_port,
        }
        item.update(_decode_bacnet_route_fields(item["mac"], item["snet"], item["sadr"]))
        candidates.append(item)
    return candidates


def _summarize_bacwi_raw(raw: str, candidates: list[dict[str, str]] | None = None) -> dict[str, Any]:
    """Summarize bacwi transport outcome separately from device filters."""
    ports: list[str] = []
    busy_ports: list[str] = []
    current_port = ""
    for line in (raw or "").splitlines():
        text = line.strip()
        if text.startswith("; BACNET_PORT"):
            parts = text.split()
            current_port = parts[2] if len(parts) >= 3 else ""
            if current_port and current_port not in ports:
                ports.append(current_port)
            continue
        if "BACnet runtime is busy" in text:
            match = re.search(r"UDP\s+(\d+)", text)
            busy_port = match.group(1) if match else current_port
            if busy_port and busy_port not in busy_ports:
                busy_ports.append(busy_port)
    candidate_rows = candidates if candidates is not None else _parse_bacwi_candidates(raw)
    summary: dict[str, Any] = {
        "queried_ports": ports,
        "busy_ports": busy_ports,
        "candidate_count": len(candidate_rows),
        "advice": "",
    }
    if busy_ports and not candidate_rows:
        summary["advice"] = (
            "One or more BACnet ports were busy, and the non-busy port did not return any I-Am responses."
        )
    elif busy_ports:
        summary["advice"] = "One or more BACnet ports were busy, but I-Am responses were still decoded from another port."
    elif not candidate_rows:
        summary["advice"] = "Who-Is completed, but no I-Am responses were returned."
    return summary


def _router_directed_bacwi_commands(network_filter: str = "") -> list[tuple[list[str], list[str]]]:
    """Return bacwi commands that query routed MS/TP networks through the router.

    The router owns its BACnet/IP service port, so local discovery must bind a
    client port (47816 by default) and unicast the Who-Is to the router's B/IP
    MAC with --dnet for the MS/TP network.
    """
    try:
        config = routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS)
    except Exception:
        return []
    if not routercfg.edge_router_enabled(config):
        return []
    bip = next((item for item in config.get("bip_interfaces") or [] if item.get("enabled")), None)
    if not bip:
        return []
    requested_networks = parse_filter_values(network_filter)
    router_mac = f"{bip.get('bind_address') or '127.0.0.1'}:{int(bip.get('udp_port') or 47809)}"
    commands: list[tuple[list[str], list[str]]] = []
    for trunk in config.get("mstp_trunks") or []:
        if not trunk.get("enabled"):
            continue
        dnet = str(trunk.get("network_number") or "").strip()
        if requested_networks and dnet not in requested_networks:
            continue
        commands.append(
            (
                [
                    "./bacwi",
                    "--mac",
                    router_mac,
                    "--dnet",
                    dnet,
                    "--retry",
                    "1",
                    "--timeout",
                    "3000",
                    "--delay",
                    "1000",
                ],
                get_edge_program_bacnet_ports(),
            )
        )
    return commands


def run_route_discovery_bacwi(network_filter: str = "") -> str:
    outputs: list[str] = []
    if not parse_filter_values(network_filter) or "0" in parse_filter_values(network_filter) or "1" in parse_filter_values(network_filter):
        outputs.append(
            run_bacnet(
                ["./bacwi", "--retry", "1", "--timeout", "3000", "--delay", "1000"],
                timeout=12,
                ports=BACNET_IP_DISCOVERY_PORTS or ["47808"],
            )
        )
    routed_commands = _router_directed_bacwi_commands(network_filter)
    if not routed_commands:
        if outputs:
            return "\n".join(output for output in outputs if output).strip()
        return run_bacnet(["./bacwi"], timeout=25)
    for args, ports in routed_commands:
        outputs.append(run_bacnet(args, timeout=12, ports=ports))
    return "\n".join(output for output in outputs if output).strip()


def _bacnet_route_from_row(row: dict[str, str]) -> tuple[list[str], list[str] | None]:
    router = str(row.get("router") or "").strip()
    snet = str(row.get("snet") or "").strip()
    sadr = str(row.get("sadr") or "").strip()
    route_args: list[str] = []
    if router and snet and sadr and sadr != "00":
        route_args = ["--mac", router, "--dnet", snet, "--dadr", sadr]
    port = str(row.get("bacnet_port") or "").strip()
    ports = [port] if port.isdigit() else None
    return route_args, ports


def _row_matches_network_filter(row: dict[str, str], networks: set[str]) -> bool:
    if not networks:
        return True
    snet = str(row.get("snet", "")).strip()
    if snet in networks:
        return True
    if snet == "0":
        try:
            config = routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS)
            active_bip_networks = {
                str(item.get("network_number"))
                for item in config.get("bip_interfaces") or []
                if item.get("enabled")
            }
            return bool(active_bip_networks & networks)
        except Exception:
            return "1" in networks
    return False


def run_device_ping(device_filter: str = "", network_filter: str = "", read_metadata: bool = True) -> dict[str, Any]:
    """Run bacwi and return route/ping details for all or filtered Device IDs."""
    started = time.time()
    raw = run_route_discovery_bacwi(network_filter)
    rows = _parse_bacwi_candidates(raw)
    summary = _summarize_bacwi_raw(raw, rows)
    device_ids = parse_filter_values(device_filter)
    networks = parse_filter_values(network_filter)

    if device_ids:
        rows = [row for row in rows if str(row.get("device", "")) in device_ids]
    if networks:
        rows = [row for row in rows if _row_matches_network_filter(row, networks)]

    for row in rows:
        row["status"] = "Online"
        row["response_ms"] = ""
        if read_metadata:
            row_start = time.time()
            route_args, ports = _bacnet_route_from_row(row)
            meta = read_device_metadata(row["device"], route_args=route_args, ports=ports)
            row["response_ms"] = str(int((time.time() - row_start) * 1000))
            row["name"] = meta.get("name", "")
            row["vendor"] = meta.get("vendor", "")
            row["model"] = meta.get("model", "")
        else:
            row.setdefault("name", "")
            row.setdefault("vendor", "")
            row.setdefault("model", "")

    # Keep the route cache fresh so directed reads can use the same data.
    try:
        cache_file = CACHE_DIR / "last_discovery.json"
        normalized = [_normalize_device_record({**row, "kept": False, "source": "device-ping"}) for row in _parse_bacwi_candidates(raw)]
        cache_file.write_text(json.dumps({"timestamp": datetime.now().isoformat(timespec="seconds"), "devices": normalized}, indent=2))
    except Exception:
        pass

    return {
        "raw": raw,
        "rows": sorted(rows, key=lambda d: int(d["device"]) if str(d.get("device", "")).isdigit() else 999999999),
        "elapsed_ms": int((time.time() - started) * 1000),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "device_filter": device_filter,
        "network_filter": network_filter,
        "read_metadata": read_metadata,
        "summary": summary,
    }



def _device_ping_worker(job_id: str, device_filter: str = "", network_filter: str = "", read_metadata: bool = True) -> None:
    """Background Device Ping / route check with browser-polled progress."""
    started = time.time()
    _set_job(
        DEVICE_PING_JOBS,
        DEVICE_PING_LOCK,
        job_id,
        status="running",
        done=False,
        error="",
        percent=5,
        scanned=0,
        total=0,
        found_count=0,
        current_device="",
        raw="",
        result=None,
        message="Sending BACnet Who-Is for ping / route check...",
        started_at=datetime.now().isoformat(timespec="seconds"),
    )
    try:
        raw = run_route_discovery_bacwi(network_filter)
        rows = _parse_bacwi_candidates(raw)
        summary = _summarize_bacwi_raw(raw, rows)
        all_rows_for_cache = list(rows)
        device_ids = parse_filter_values(device_filter)
        networks = parse_filter_values(network_filter)

        if device_ids:
            rows = [row for row in rows if str(row.get("device", "")) in device_ids]
        if networks:
            rows = [row for row in rows if _row_matches_network_filter(row, networks)]

        rows = sorted(rows, key=lambda d: int(d["device"]) if str(d.get("device", "")).isdigit() else 999999999)
        total = len(rows)
        _set_job(
            DEVICE_PING_JOBS,
            DEVICE_PING_LOCK,
            job_id,
            raw=raw,
            percent=20 if total else 90,
            scanned=0,
            total=total,
            found_count=total,
            message=f"Who-Is complete. Matched {total} device(s)." if total else "Who-Is complete. No matching devices found.",
        )

        for idx, row in enumerate(rows, start=1):
            device_id = row.get("device", "")
            row["status"] = "Online"
            row["response_ms"] = ""
            row.setdefault("name", "")
            row.setdefault("vendor", "")
            row.setdefault("model", "")

            if read_metadata:
                _set_job(
                    DEVICE_PING_JOBS,
                    DEVICE_PING_LOCK,
                    job_id,
                    scanned=idx - 1,
                    current_device=device_id,
                    percent=20 + int(((idx - 1) * 75 / total)) if total else 95,
                    message=f"Reading object-name/vendor/model for device {device_id} ({idx} of {total})...",
                    rows=rows,
                )
                row_start = time.time()
                route_args, ports = _bacnet_route_from_row(row)
                meta = read_device_metadata(str(device_id), route_args=route_args, ports=ports)
                row["response_ms"] = str(int((time.time() - row_start) * 1000))
                row["name"] = meta.get("name", "")
                row["vendor"] = meta.get("vendor", "")
                row["model"] = meta.get("model", "")
            else:
                _set_job(
                    DEVICE_PING_JOBS,
                    DEVICE_PING_LOCK,
                    job_id,
                    current_device=device_id,
                    percent=20 + int((idx * 75 / total)) if total else 95,
                    message=f"Route decoded for device {device_id} ({idx} of {total})...",
                    rows=rows,
                )

            _set_job(
                DEVICE_PING_JOBS,
                DEVICE_PING_LOCK,
                job_id,
                scanned=idx,
                current_device=device_id,
                percent=20 + int((idx * 75 / total)) if total else 95,
                message=f"Device {device_id} complete ({idx} of {total}).",
                rows=rows,
            )

        # Keep the route cache fresh so directed reads can use the same data.
        try:
            cache_file = CACHE_DIR / "last_discovery.json"
            normalized = [_normalize_device_record({**row, "kept": False, "source": "device-ping"}) for row in all_rows_for_cache]
            cache_file.write_text(json.dumps({"timestamp": datetime.now().isoformat(timespec="seconds"), "devices": normalized}, indent=2))
        except Exception:
            pass

        result = {
            "raw": raw,
            "rows": rows,
            "elapsed_ms": int((time.time() - started) * 1000),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "device_filter": device_filter,
            "network_filter": network_filter,
            "read_metadata": read_metadata,
            "summary": summary,
        }
        _set_job(
            DEVICE_PING_JOBS,
            DEVICE_PING_LOCK,
            job_id,
            status="complete",
            done=True,
            percent=100,
            scanned=total,
            total=total,
            found_count=total,
            current_device="",
            result=result,
            rows=rows,
            message=f"Ping / route check complete. Devices shown: {total}.",
        )
    except Exception as exc:
        _set_job(
            DEVICE_PING_JOBS,
            DEVICE_PING_LOCK,
            job_id,
            status="error",
            done=True,
            error=str(exc),
            percent=100,
            message=f"Ping / route check failed: {exc}",
        )

def get_cached_bacnet_route(device_id: str) -> dict[str, str]:
    """Return directed route data from the last discovery cache when available."""
    saved_native = get_saved_native_bip_route(str(device_id))
    if saved_native:
        return saved_native
    try:
        cache_file = CACHE_DIR / "last_discovery.json"
        data = json.loads(cache_file.read_text())
        for device in data.get("devices", []):
            if str(device.get("device")) == str(device_id):
                mac = str(device.get("mac", "")).strip()
                route = {
                    "mac": _bacnet_ip_mac_to_ip_port(mac) or mac,
                    "native_bip_endpoint": _bacnet_ip_mac_to_ip_port(str(device.get("sadr", "")).strip()),
                    "snet": str(device.get("snet", "")).strip(),
                    "sadr": str(device.get("sadr", "")).strip(),
                    "apdu": str(device.get("apdu", "")).strip(),
                    "bacnet_port": str(device.get("bacnet_port", "")).strip(),
                }
                return route
    except Exception:
        pass
    return {}


def build_route_args(device_id: str, use_directed: bool = True) -> list[str]:
    """Build optional bacnet-stack directed request arguments from discovery data."""
    if not use_directed:
        return []
    authoritative = get_router_authoritative_bacnet_request_route(str(device_id))
    if authoritative:
        return list(authoritative[0])
    route = get_cached_bacnet_route(device_id)
    return _route_args_from_cached_route(route)


def parse_object_identifier(output: str) -> tuple[str, str] | None:
    # Example bacrp output: (analog-input, 2)
    match = re.search(r"\(([^,]+),\s*([0-9]+)\)", output)
    if not match:
        return None
    return match.group(1).strip(), match.group(2).strip()


def read_indexed_object_list(device_id: str, start_index: int = 1, end_index: int | None = None, names_only: bool = True) -> list[dict[str, Any]]:
    """Read object-list by index range. This avoids full object-list reads and segmentation issues."""
    start_index = safe_int(str(start_index), 1, minimum=1, maximum=MAX_OBJECTS)
    if end_index is None:
        end_index = DEFAULT_SCAN_LIMIT
    end_index = safe_int(str(end_index), DEFAULT_SCAN_LIMIT, minimum=1, maximum=MAX_OBJECTS)
    if end_index < start_index:
        start_index, end_index = end_index, start_index

    found: list[dict[str, Any]] = []

    for index in range(start_index, end_index + 1):
        try:
            out = run_bacnet(["./bacrp", device_id, "device", device_id, "object-list", str(index)], timeout=6)
        except Exception:
            continue
        if _bacnet_output_busy(out):
            raise RuntimeError(out)

        parsed = parse_object_identifier(out)
        if not parsed:
            continue

        obj_type, instance = parsed
        if obj_type not in TARGET_TYPES:
            continue

        obj = {
            "index": index,
            "object_type": obj_type,
            "type_label": TYPE_LABELS.get(obj_type, obj_type),
            "instance": int(instance),
            "object_name": read_property(device_id, obj_type, instance, "object-name"),
        }

        # Template building should not read PV. This flag is only here for legacy/manual use.
        if not names_only and obj_type != "schedule":
            obj["present_value"] = read_present_value(device_id, obj_type, instance)

        found.append(obj)

    return found


def _rpm_property_list_for_indexes(start_index: int, end_index: int) -> str:
    return ",".join(f"76[{idx}]" for idx in range(start_index, end_index + 1))


def parse_rpm_object_list(output: str) -> list[dict[str, Any]]:
    """Parse bacrpm object-list[index] output into object metadata rows."""
    objects: list[dict[str, Any]] = []
    for match in re.finditer(r"object-list:\s*\[(\d+)\]\s*\(([^,]+),\s*(\d+)\)", output, flags=re.IGNORECASE):
        index = int(match.group(1))
        obj_type = match.group(2).strip()
        instance = int(match.group(3))
        if obj_type not in TARGET_TYPES:
            continue
        objects.append({
            "index": index,
            "object_type": obj_type,
            "type_label": TYPE_LABELS.get(obj_type, obj_type),
            "instance": instance,
            "object_name": "",
        })
    return objects


def parse_rpm_object_names(output: str) -> dict[tuple[str, int], str]:
    """Parse bacrpm object-name output for many objects.

    bacnet-stack versions vary slightly in their object headers. This parser
    accepts common forms such as:
      analog-input #1
      analog-input 1
      (analog-input, 1)
    followed by an object-name line.
    """
    names: dict[tuple[str, int], str] = {}
    current: tuple[str, int] | None = None
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line or line in {"{", "}"} or line.startswith("device #"):
            continue

        object_match = (
            re.match(r"^\(?([a-z]+(?:-[a-z]+)*)\s*,\s*(\d+)\)?$", line, flags=re.IGNORECASE)
            or re.match(r"^([a-z]+(?:-[a-z]+)*)\s+#?(\d+)\s*$", line, flags=re.IGNORECASE)
        )
        if object_match:
            current = (object_match.group(1).strip(), int(object_match.group(2)))
            continue

        name_match = re.match(r"^(?:object-name|77):\s*(.*)$", line, flags=re.IGNORECASE)
        if name_match and current:
            names[current] = clean(name_match.group(1))
            current = None
            continue

    return names


def read_rpm_object_list_blocks(device_id: str, start_index: int, end_index: int, use_directed: bool = True) -> list[dict[str, Any]]:
    """Read object-list indexes in bacrpm blocks. Fast path for KMC/segmented devices."""
    route_args = build_route_args(device_id, use_directed=use_directed)
    found: list[dict[str, Any]] = []
    block_size = max(1, min(RPM_BLOCK_SIZE, 42))
    for block_start in range(start_index, end_index + 1, block_size):
        block_end = min(end_index, block_start + block_size - 1)
        prop_list = _rpm_property_list_for_indexes(block_start, block_end)
        try:
            out = run_bacnet(["./bacrpm", device_id, "device", device_id, prop_list, *route_args], timeout=20)
        except Exception:
            continue
        if _bacnet_output_busy(out):
            raise RuntimeError(out)
        found.extend(parse_rpm_object_list(out))
    # De-dupe while preserving index order.
    seen: set[tuple[int, str, int]] = set()
    unique: list[dict[str, Any]] = []
    for obj in sorted(found, key=lambda item: int(item.get("index", 0))):
        key = (int(obj.get("index", 0)), str(obj.get("object_type", "")), int(obj.get("instance", 0)))
        if key in seen:
            continue
        seen.add(key)
        unique.append(obj)
    return unique


def enrich_names_with_rpm(device_id: str, objects: list[dict[str, Any]], use_directed: bool = True) -> list[dict[str, Any]]:
    """Batch-read object names with bacrpm and fall back to bacrp for missing names."""
    route_args = build_route_args(device_id, use_directed=use_directed)
    name_block = max(1, min(RPM_NAME_BLOCK_SIZE, 60))
    enriched = [dict(obj) for obj in objects]

    for block_start in range(0, len(enriched), name_block):
        block = enriched[block_start:block_start + name_block]
        args = ["./bacrpm", device_id]
        for obj in block:
            args.extend([str(obj["object_type"]), str(obj["instance"]), "77"])
        args.extend(route_args)
        try:
            out = run_bacnet(args, timeout=25)
            if _bacnet_output_busy(out):
                raise RuntimeError(out)
            names = parse_rpm_object_names(out)
        except RuntimeError:
            raise
        except Exception:
            names = {}

        for obj in block:
            key = (str(obj["object_type"]), int(obj["instance"]))
            if names.get(key):
                obj["object_name"] = names[key]

    # Fallback for any missing names. This keeps the UI useful even if a
    # controller returns a slightly different RPM formatting than expected.
    for obj in enriched:
        if not obj.get("object_name"):
            obj["object_name"] = read_property(device_id, str(obj["object_type"]), str(obj["instance"]), "object-name")

    return enriched


def _cleanup_scan_jobs() -> None:
    """Remove old completed scan jobs so the dev server does not collect stale results forever."""
    cutoff = time.time() - SCAN_JOB_RETENTION_SECONDS
    with SCAN_LOCK:
        stale = [
            job_id for job_id, job in SCAN_JOBS.items()
            if job.get("done") and float(job.get("updated_at", 0)) < cutoff
        ]
        for job_id in stale:
            SCAN_JOBS.pop(job_id, None)


def _set_scan_job(job_id: str, **updates: Any) -> None:
    updates["updated_at"] = time.time()
    with SCAN_LOCK:
        job = SCAN_JOBS.setdefault(job_id, {})
        job.update(updates)


def _get_scan_job(job_id: str) -> dict[str, Any] | None:
    with SCAN_LOCK:
        job = SCAN_JOBS.get(job_id)
        if not job:
            return None
        # Return a JSON-safe copy so the polling route does not expose the live object.
        return json.loads(json.dumps(job))


def _set_job(store: dict[str, dict[str, Any]], lock: threading.Lock, job_id: str, **updates: Any) -> None:
    updates["updated_at"] = time.time()
    with lock:
        job = store.setdefault(job_id, {})
        job.update(updates)


def _get_job(store: dict[str, dict[str, Any]], lock: threading.Lock, job_id: str) -> dict[str, Any] | None:
    with lock:
        job = store.get(job_id)
        if not job:
            return None
        return json.loads(json.dumps(job))


def _cleanup_job_store(store: dict[str, dict[str, Any]], lock: threading.Lock) -> None:
    cutoff = time.time() - SCAN_JOB_RETENTION_SECONDS
    with lock:
        stale = [
            job_id for job_id, job in store.items()
            if job.get("done") and float(job.get("updated_at", 0)) < cutoff
        ]
        for job_id in stale:
            store.pop(job_id, None)


def _template_scan_worker(job_id: str, device_id: str, start_index: int, end_index: int, scan_method: str = "rpm") -> None:
    """Background object metadata scan used by the Build Template progress UI."""
    scan_method = (scan_method or "rpm").strip().lower()
    if scan_method not in {"indexed", "rpm"}:
        scan_method = "rpm"

    total = max(0, end_index - start_index + 1)
    objects: list[dict[str, Any]] = []
    started_at = datetime.now().isoformat(timespec="seconds")

    _set_scan_job(
        job_id,
        status="running",
        done=False,
        error="",
        device_id=device_id,
        start_index=start_index,
        end_index=end_index,
        scan_method=scan_method,
        total=total,
        scanned=0,
        percent=0,
        current_index=start_index,
        current_object="",
        found_count=0,
        objects=[],
        started_at=started_at,
        message="Starting metadata scan...",
    )

    try:
        if scan_method == "rpm":
            route = get_cached_bacnet_route(device_id)
            route_msg = ""
            if route.get("mac"):
                route_msg = f" using directed route {route.get('mac')}"
                if route.get("snet") and route.get("snet") != "0":
                    route_msg += f" / DNET {route.get('snet')} DADR {route.get('sadr')}"

            block_size = max(1, min(RPM_BLOCK_SIZE, 42))
            for block_start in range(start_index, end_index + 1, block_size):
                block_end = min(end_index, block_start + block_size - 1)
                scanned_so_far = max(0, block_start - start_index)
                percent = int(scanned_so_far * 100 / total) if total else 100
                _set_scan_job(
                    job_id,
                    scanned=scanned_so_far,
                    percent=percent,
                    current_index=block_start,
                    current_object="",
                    message=f"RPM reading object-list indexes {block_start}-{block_end}{route_msg}...",
                )

                block_objects = read_rpm_object_list_blocks(device_id, block_start, block_end, use_directed=True)
                if block_objects:
                    _set_scan_job(
                        job_id,
                        current_index=block_start,
                        current_object=f"{len(block_objects)} objects",
                        found_count=len(objects) + len(block_objects),
                        message=f"RPM reading object names for indexes {block_start}-{block_end}...",
                    )
                    block_objects = enrich_names_with_rpm(device_id, block_objects, use_directed=True)
                    objects.extend(block_objects)

                scanned_now = min(total, block_end - start_index + 1)
                _set_scan_job(
                    job_id,
                    scanned=scanned_now,
                    percent=int(scanned_now * 100 / total) if total else 100,
                    current_index=block_end,
                    current_object="",
                    found_count=len(objects),
                    objects=objects,
                    message=f"RPM block {block_start}-{block_end} complete. Found {len(objects)} selectable objects so far.",
                )

        else:
            for scanned, index in enumerate(range(start_index, end_index + 1), start=1):
                percent = int((scanned - 1) * 100 / total) if total else 100
                _set_scan_job(
                    job_id,
                    scanned=scanned - 1,
                    percent=percent,
                    current_index=index,
                    current_object="",
                    message=f"Reading object-list index {index}...",
                )

                try:
                    out = run_bacnet(["./bacrp", device_id, "device", device_id, "object-list", str(index)], timeout=6)
                except Exception as exc:
                    _set_scan_job(
                        job_id,
                        scanned=scanned,
                        percent=int(scanned * 100 / total) if total else 100,
                        current_index=index,
                        message=f"Index {index}: read failed ({exc})",
                    )
                    continue
                if _bacnet_output_busy(out):
                    raise RuntimeError(out)

                parsed = parse_object_identifier(out)
                if not parsed:
                    _set_scan_job(
                        job_id,
                        scanned=scanned,
                        percent=int(scanned * 100 / total) if total else 100,
                        current_index=index,
                        message=f"Index {index}: no object returned",
                    )
                    continue

                obj_type, instance = parsed
                current_object = f"{TYPE_LABELS.get(obj_type, obj_type)} {instance}"

                if obj_type not in TARGET_TYPES:
                    _set_scan_job(
                        job_id,
                        scanned=scanned,
                        percent=int(scanned * 100 / total) if total else 100,
                        current_index=index,
                        current_object=current_object,
                        message=f"Index {index}: skipped {obj_type} {instance}",
                    )
                    continue

                _set_scan_job(
                    job_id,
                    current_index=index,
                    current_object=current_object,
                    message=f"Reading object-name for {current_object}...",
                )

                object_name = read_property(device_id, obj_type, instance, "object-name")
                obj = {
                    "index": index,
                    "object_type": obj_type,
                    "type_label": TYPE_LABELS.get(obj_type, obj_type),
                    "instance": int(instance),
                    "object_name": object_name,
                }
                objects.append(obj)

                _set_scan_job(
                    job_id,
                    scanned=scanned,
                    percent=int(scanned * 100 / total) if total else 100,
                    current_index=index,
                    current_object=current_object,
                    found_count=len(objects),
                    objects=objects,
                    message=f"Found {current_object}: {object_name or '(no name)'}",
                )

        _set_scan_job(
            job_id,
            status="complete",
            done=True,
            scanned=total,
            percent=100,
            current_index=end_index,
            found_count=len(objects),
            objects=objects,
            completed_at=datetime.now().isoformat(timespec="seconds"),
            message=f"Scan complete. Found {len(objects)} selectable objects.",
        )
    except Exception as exc:
        _set_scan_job(
            job_id,
            status="error",
            done=True,
            error=str(exc),
            completed_at=datetime.now().isoformat(timespec="seconds"),
            message=f"Scan failed: {exc}",
        )


def read_present_value(device_id: str, obj_type: str, instance: str | int) -> str:
    if obj_type == "schedule":
        return ""
    pv = read_property(device_id, obj_type, instance, "present-value")
    if not pv:
        pv = read_property(device_id, obj_type, instance, "85")
    return pv


# --- Template/export helpers ------------------------------------------------
def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or f"template-{uuid4().hex[:8]}"


def template_path(template_id: str) -> Path:
    safe = slugify(template_id).replace("..", "")
    return TEMPLATE_DIR / f"{safe}.json"


def load_templates() -> list[dict[str, Any]]:
    templates: list[dict[str, Any]] = []
    for path in sorted(TEMPLATE_DIR.glob("*.json")):
        try:
            data = json.loads(path.read_text())
            data["template_id"] = path.stem
            data["filename"] = path.name
            data["point_count"] = len(data.get("points", []))
            templates.append(data)
        except Exception:
            continue
    return templates


def load_template(template_id: str) -> dict[str, Any]:
    path = template_path(template_id)
    if not path.exists():
        raise FileNotFoundError(f"Template not found: {template_id}")
    data = json.loads(path.read_text())
    data["template_id"] = path.stem
    return data


def save_template(data: dict[str, Any]) -> str:
    ensure_runtime_initialized()
    name = data.get("template_name") or "BACnet Template"
    tid = slugify(name)
    path = template_path(tid)
    data["updated_at"] = datetime.now().isoformat(timespec="seconds")
    path.write_text(json.dumps(data, indent=2))
    return tid


def normalize_template_points(points: Any) -> list[dict[str, Any]]:
    """Normalize JSON/CSV template rows into the internal point format."""
    normalized: list[dict[str, Any]] = []
    if not isinstance(points, list):
        return normalized

    for point in points:
        if not isinstance(point, dict):
            continue
        obj_type = str(point.get("object_type") or point.get("type") or "").strip()
        instance_raw = point.get("instance", "")
        object_name = str(point.get("object_name") or point.get("name") or "").strip()
        if not obj_type:
            continue
        try:
            instance = int(instance_raw)
        except Exception:
            continue
        normalized.append({
            "object_type": obj_type,
            "instance": instance,
            "object_name": object_name,
        })
    return normalized


def points_from_selected_form() -> list[dict[str, Any]]:
    points: list[dict[str, Any]] = []
    for item in request.form.getlist("selected_points"):
        try:
            point = json.loads(item)
            points.extend(normalize_template_points([point]))
        except Exception:
            continue
    return points


def template_to_csv_response(template: dict[str, Any], filename_base: str) -> Response:
    import io

    output = io.StringIO()
    fieldnames = ["object_type", "instance", "object_name"]
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    for point in normalize_template_points(template.get("points", [])):
        writer.writerow({key: point.get(key, "") for key in fieldnames})

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={slugify(filename_base)}.csv"},
    )


def load_template_upload(file_storage: Any) -> dict[str, Any]:
    """Load an uploaded .json or .csv template and return a normalized template dict."""
    filename = (file_storage.filename or "template").strip()
    suffix = Path(filename).suffix.lower()
    raw = file_storage.read().decode("utf-8-sig")
    stem = Path(filename).stem or "BACnet Template"

    if suffix == ".json":
        data = json.loads(raw)
        if isinstance(data, list):
            data = {"template_name": stem, "points": data}
        if not isinstance(data, dict):
            raise ValueError("JSON template must be an object with a points list, or a list of points.")
        data["points"] = normalize_template_points(data.get("points", []))
        data.setdefault("template_name", stem)
        return data

    if suffix == ".csv":
        import io

        reader = csv.DictReader(io.StringIO(raw))
        points = normalize_template_points(list(reader))
        return {
            "template_name": stem,
            "vendor": "",
            "model": "",
            "device_name_match": "",
            "points": points,
        }

    raise ValueError("Unsupported template file type. Upload .json or .csv.")


def object_identifier_for_point(point: dict[str, Any]) -> str:
    obj_type = str(point.get("object_type", "")).strip().lower()
    label = TYPE_LABELS.get(obj_type, obj_type).upper()
    if obj_type == "schedule":
        label = "SCHED"
    return f"{label}{point.get('instance', '')}"


def point_from_object_identifier(identifier: str, description: str = "") -> dict[str, Any] | None:
    key = parse_object_identifier_token(identifier)
    if key is None:
        return None
    obj_type, instance = key
    return {
        "object_type": obj_type,
        "instance": instance,
        "object_name": description.strip() or identifier.strip(),
    }


def parse_object_identifier_token(value: Any) -> tuple[str, int] | None:
    match = re.match(r"^\s*([A-Za-z][A-Za-z_-]*)\s*[-_ ]?\s*(\d+)\s*$", str(value or ""))
    if not match:
        return None
    obj_type = TYPE_BY_LABEL.get(match.group(1).strip().lower())
    if not obj_type:
        return None
    return obj_type, int(match.group(2))


def load_custom_table_upload(
    file_storage: Any,
    saved_device: dict[str, Any],
    *,
    allow_new_csv_points: bool = False,
) -> dict[str, Any]:
    filename = (file_storage.filename or "custom-table.csv").strip()
    if Path(filename).suffix.lower() != ".csv":
        raise ValueError("Custom Table import requires a .csv file.")

    import io

    raw = file_storage.read().decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(raw))
    saved_points = normalize_device_points(saved_device.get("points", []))
    points_by_key = {
        (point["object_type"], int(point["instance"])): point
        for point in saved_points
    }
    allow_csv_points = allow_new_csv_points or not points_by_key
    imported_points_by_key: dict[tuple[str, int], dict[str, Any]] = {}
    columns = [
        {"name": "Column 1", "rows": []},
        {"name": "Column 2", "rows": []},
        {"name": "Column 3", "rows": []},
    ]
    seen: set[tuple[str, int]] = set()
    matched = 0
    missing = 0
    duplicates = 0
    fieldnames = {str(name or "").strip().lower() for name in (reader.fieldnames or [])}

    if {"object_type", "instance", "object_name"}.issubset(fieldnames):
        ordered_rows: list[dict[str, Any]] = []
        for csv_row in reader:
            obj_type = str(csv_row.get("object_type") or "").strip().lower()
            instance_raw = str(csv_row.get("instance") or "").strip()
            description = str(csv_row.get("object_name") or "").strip()
            try:
                key = (obj_type, int(instance_raw))
            except Exception:
                missing += 1
                continue
            if key in seen:
                duplicates += 1
                continue
            seen.add(key)
            point = points_by_key.get(key)
            if point is None and allow_csv_points:
                point = {"object_type": obj_type, "instance": key[1], "object_name": description}
                points_by_key[key] = point
                imported_points_by_key[key] = point
            if point is None:
                missing += 1
                continue
            ordered_rows.append({
                "object_type": point["object_type"],
                "instance": int(point["instance"]),
                "object_identifier": object_identifier_for_point(point),
                "description": description or point.get("object_name") or object_identifier_for_point(point),
                "initial_value": collapse_duplicated_display_value(csv_row.get("present_value")),
            })
            matched += 1

        if not matched:
            raise ValueError("No Custom Table rows matched the selected Live Device point list.")

        rows_per_column = max(1, math.ceil(len(ordered_rows) / 3))
        for index, row in enumerate(ordered_rows):
            columns[min(index // rows_per_column, 2)]["rows"].append(row)
        return {
            "name": Path(filename).stem or "Custom Table",
            "source_filename": filename,
            "imported_at": datetime.now().isoformat(timespec="seconds"),
            "columns": columns,
            "matched_count": matched,
            "missing_count": missing,
            "duplicate_count": duplicates,
            "_points": list(imported_points_by_key.values()),
        }

    for csv_row in reader:
        for column_index, column in enumerate(columns, start=1):
            identifier = str(csv_row.get(f"column_{column_index}_object_identifier") or "").strip()
            if not identifier:
                continue
            key = parse_object_identifier_token(identifier)
            if key is None:
                missing += 1
                continue
            if key in seen:
                duplicates += 1
                continue
            seen.add(key)
            point = points_by_key.get(key)
            if point is None and allow_csv_points:
                description_for_point = str(csv_row.get(f"column_{column_index}_description") or identifier).strip()
                point = point_from_object_identifier(identifier, description_for_point)
                if point:
                    points_by_key[key] = point
                    imported_points_by_key[key] = point
            if point is None:
                missing += 1
                continue
            description = str(csv_row.get(f"column_{column_index}_description") or point.get("object_name") or identifier).strip()
            initial_value = collapse_duplicated_display_value(csv_row.get(f"column_{column_index}_present_value"))
            column["rows"].append({
                "object_type": point["object_type"],
                "instance": int(point["instance"]),
                "object_identifier": object_identifier_for_point(point),
                "description": description,
                "initial_value": initial_value,
            })
            matched += 1

    if not matched:
        raise ValueError("No Custom Table rows matched the selected Live Device point list.")

    return {
        "name": Path(filename).stem or "Custom Table",
        "source_filename": filename,
        "imported_at": datetime.now().isoformat(timespec="seconds"),
        "columns": columns,
        "matched_count": matched,
        "missing_count": missing,
        "duplicate_count": duplicates,
        "_points": list(imported_points_by_key.values()),
    }


def custom_table_from_template(template: dict[str, Any]) -> dict[str, Any]:
    points = normalize_template_points(template.get("points", []))
    if not points:
        raise ValueError("Selected Template does not contain any usable points.")
    columns = [
        {"name": "Column 1", "rows": []},
        {"name": "Column 2", "rows": []},
        {"name": "Column 3", "rows": []},
    ]
    rows_per_column = max(1, math.ceil(len(points) / 3))
    for index, point in enumerate(points):
        column = columns[min(index // rows_per_column, 2)]
        column["rows"].append({
            "object_type": point["object_type"],
            "instance": int(point["instance"]),
            "object_identifier": object_identifier_for_point(point),
            "description": point.get("object_name") or object_identifier_for_point(point),
            "initial_value": "",
        })
    return {
        "name": template.get("template_name") or template.get("template_id") or "Template Import",
        "source_filename": "",
        "source_template_id": template.get("template_id", ""),
        "source": "saved_template",
        "imported_at": datetime.now().isoformat(timespec="seconds"),
        "columns": columns,
        "matched_count": len(points),
        "missing_count": 0,
        "duplicate_count": 0,
        "_points": points,
    }



# --- Saved devices ----------------------------------------------------------
def saved_device_path(device_profile_id: str) -> Path:
    safe = slugify(device_profile_id).replace("..", "")
    return SAVED_DEVICE_DIR / f"{safe}.json"


def normalize_device_points(points: Any) -> list[dict[str, Any]]:
    """Keep only static point metadata needed for future live refreshes."""
    normalized: list[dict[str, Any]] = []
    for point in points or []:
        obj_type = str(point.get("object_type", "")).strip().lower()
        instance_raw = point.get("instance", "")
        try:
            instance = int(instance_raw)
        except Exception:
            continue
        if not obj_type or instance < 0:
            continue
        object_name = str(point.get("object_name") or point.get("expected_name") or "").strip()
        normalized.append({
            "object_type": obj_type,
            "instance": instance,
            "object_name": object_name,
        })
    return normalized


def load_saved_devices() -> list[dict[str, Any]]:
    devices: list[dict[str, Any]] = []
    for path in sorted(SAVED_DEVICE_DIR.glob("*.json")):
        try:
            data = json.loads(path.read_text())
            data["device_profile_id"] = path.stem
            data["point_count"] = len(normalize_device_points(data.get("points", [])))
            devices.append(data)
        except Exception:
            continue
    def device_sort_key(device: dict[str, Any]) -> tuple[int, int | str, str]:
        raw_device_id = str(device.get("device_id") or "").strip()
        if raw_device_id.isdigit():
            return (0, int(raw_device_id), str(device.get("device_name") or "").lower())
        return (1, raw_device_id.lower(), str(device.get("device_name") or "").lower())

    devices.sort(key=device_sort_key)
    return devices


def load_saved_device(device_profile_id: str) -> dict[str, Any]:
    path = saved_device_path(device_profile_id)
    if not path.exists():
        raise FileNotFoundError(f"Saved device not found: {device_profile_id}")
    data = json.loads(path.read_text())
    data["device_profile_id"] = path.stem
    data["points"] = normalize_device_points(data.get("points", []))
    data["point_count"] = len(data["points"])
    return data


def find_saved_device_for_device_id(device_id: str) -> dict[str, Any] | None:
    target = str(device_id or "").strip()
    if not target:
        return None
    for saved_device in load_saved_devices():
        if str(saved_device.get("device_id", "")).strip() == target:
            try:
                return load_saved_device(str(saved_device.get("device_profile_id", "")).strip())
            except Exception:
                return saved_device
    return None


def save_saved_device(data: dict[str, Any]) -> str:
    ensure_runtime_initialized()
    name = data.get("device_name") or f"Device {data.get('device_id', '')}".strip() or "BACnet Device"
    base = f"{data.get('device_id', 'device')}-{name}"
    device_profile_id = slugify(base)
    path = saved_device_path(device_profile_id)
    if path.exists():
        device_profile_id = f"{device_profile_id}-{uuid4().hex[:6]}"
        path = saved_device_path(device_profile_id)
    payload = dict(data)
    payload["device_profile_id"] = device_profile_id
    payload["device_name"] = name
    payload["points"] = normalize_device_points(payload.get("points", []))
    payload["point_count"] = len(payload["points"])
    now = datetime.now().isoformat(timespec="seconds")
    payload.setdefault("created_at", now)
    payload["updated_at"] = now
    path.write_text(json.dumps(payload, indent=2))
    return device_profile_id


def update_saved_device_custom_table(device_profile_id: str, custom_table: dict[str, Any]) -> None:
    ensure_runtime_initialized()
    path = saved_device_path(device_profile_id)
    if not path.exists():
        raise FileNotFoundError(f"Saved device not found: {device_profile_id}")
    payload = json.loads(path.read_text())
    payload["custom_table"] = custom_table
    payload["updated_at"] = datetime.now().isoformat(timespec="seconds")
    path.write_text(json.dumps(payload, indent=2))


def update_saved_device_from_custom_table_import(
    device_profile_id: str,
    custom_table: dict[str, Any],
    imported_points: list[dict[str, Any]],
) -> None:
    ensure_runtime_initialized()
    path = saved_device_path(device_profile_id)
    if not path.exists():
        raise FileNotFoundError(f"Saved device not found: {device_profile_id}")
    payload = json.loads(path.read_text())
    existing_points = normalize_device_points(payload.get("points", []))
    points_by_key = {
        (str(point.get("object_type", "")).strip().lower(), int(point.get("instance", -1))): point
        for point in existing_points
    }
    for point in normalize_device_points(imported_points):
        points_by_key[(str(point.get("object_type", "")).strip().lower(), int(point.get("instance", -1)))] = point
    payload["points"] = list(points_by_key.values())
    payload["point_count"] = len(payload["points"])
    payload["custom_table"] = custom_table
    if custom_table.get("source_template_id"):
        payload["source_template_id"] = str(custom_table.get("source_template_id") or "")
        payload["source_template_name"] = str(custom_table.get("name") or custom_table.get("source_template_id") or "")
    now = datetime.now().isoformat(timespec="seconds")
    payload["updated_at"] = now
    path.write_text(json.dumps(payload, indent=2))


def rename_saved_device(device_profile_id: str, device_name: str) -> None:
    ensure_runtime_initialized()
    path = saved_device_path(device_profile_id)
    if not path.exists():
        raise FileNotFoundError(f"Saved device not found: {device_profile_id}")
    name = device_name.strip()
    if not name:
        raise ValueError("Live Device name cannot be blank.")
    payload = json.loads(path.read_text())
    payload["device_name"] = name
    payload["updated_at"] = datetime.now().isoformat(timespec="seconds")
    path.write_text(json.dumps(payload, indent=2))


def context_rows_to_device_points(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    points: list[dict[str, Any]] = []
    for row in rows or []:
        points.append({
            "object_type": row.get("object_type", ""),
            "instance": row.get("instance", ""),
            "object_name": row.get("object_name") or row.get("expected_name") or "",
        })
    return normalize_device_points(points)


def context_rows_to_live_snapshot(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Keep the already-read live columns when a loaded view becomes a device."""
    snapshots: list[dict[str, Any]] = []
    for row in rows or []:
        obj_type = str(row.get("object_type", "")).strip().lower()
        instance_raw = row.get("instance", "")
        try:
            instance = int(instance_raw)
        except Exception:
            continue
        if not obj_type or instance < 0:
            continue
        snapshots.append({
            "object_type": obj_type,
            "instance": instance,
            "present_value": str(row.get("present_value") or ""),
            "display_present_value": str(row.get("display_present_value") or row.get("present_value") or ""),
            "raw_present_value": str(row.get("raw_present_value") or row.get("present_value") or ""),
            "active_priority": str(row.get("active_priority") or ""),
            "priority_array": str(row.get("priority_array") or ""),
            "priority_array_state": str(row.get("priority_array_state") or priority_array_metadata_state(str(row.get("priority_array") or ""))),
            "status": str(row.get("status") or "Not refreshed"),
            "timestamp": str(row.get("timestamp") or ""),
            "read_source": str(row.get("read_source") or "Loaded view"),
        })
    return snapshots


def export_results(device_id: str, template_id: str, rows: list[dict[str, Any]]) -> dict[str, str]:
    ensure_runtime_initialized()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    base = f"device-{device_id}-{template_id}-{stamp}"
    csv_path = EXPORT_DIR / f"{base}.csv"
    json_path = EXPORT_DIR / f"{base}.json"

    fieldnames = ["object_type", "instance", "object_name", "present_value", "status", "timestamp"]
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})

    json_path.write_text(json.dumps({
        "device": device_id,
        "template_id": template_id,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "points": rows,
    }, indent=2))

    return {"csv": csv_path.name, "json": json_path.name}




# --- Present Value write helpers -------------------------------------------
PV_WRITE_TYPES = {
    "analog-output": {
        "label": "AO",
        "tag": "4",
        "value_hint": "72.5",
        "note": "Analog output writes use a decimal number.",
        "family": "analog",
    },
    "analog-value": {
        "label": "AV",
        "tag": "4",
        "value_hint": "72.5",
        "note": "Analog value writes use a decimal number.",
        "family": "analog",
    },
    "binary-output": {
        "label": "BO",
        "tag": "9",
        "value_hint": "0 or 1",
        "note": "Binary output values are usually 0=inactive/off and 1=active/on.",
        "family": "binary",
    },
    "binary-value": {
        "label": "BV",
        "tag": "9",
        "value_hint": "0 or 1",
        "note": "Binary value values are usually 0=inactive/off and 1=active/on.",
        "family": "binary",
    },
    "multi-state-output": {
        "label": "MSO",
        "tag": "2",
        "value_hint": "1, 2, 3...",
        "note": "Multi-state output writes use the numeric state number.",
        "family": "multi-state",
    },
    "multi-state-value": {
        "label": "MSV",
        "tag": "2",
        "value_hint": "1, 2, 3...",
        "note": "Multi-state value writes use the numeric state number.",
        "family": "multi-state",
    },
}

MULTI_STATE_TYPES = {"multi-state-input", "multi-state-output", "multi-state-value"}


def is_pv_write_type(obj_type: str) -> bool:
    return (obj_type or "").strip().lower() in PV_WRITE_TYPES


def split_top_level_commas(text: str) -> list[str]:
    """Split BACnet pretty-print arrays without breaking nested values."""
    parts: list[str] = []
    buf: list[str] = []
    depth = 0
    for ch in text or "":
        if ch in "[({":
            depth += 1
        elif ch in "])}" and depth > 0:
            depth -= 1
        if ch == "," and depth == 0:
            part = "".join(buf).strip()
            if part:
                parts.append(part)
            buf = []
        else:
            buf.append(ch)
    part = "".join(buf).strip()
    if part:
        parts.append(part)
    return parts


def is_null_priority_entry(value: str) -> bool:
    text = clean(value).strip().lower()
    if not text:
        return True
    null_tokens = {"null", "(null)", "[null]", "{null}", "--", "none"}
    if text in null_tokens:
        return True
    return bool(re.fullmatch(r"\[?\s*null\s*\]?", text))


def parse_priority_array_entries(raw: str) -> list[str]:
    """Return priority-array entries in priority order when possible."""
    text = clean(raw)
    if not text:
        return []

    # Common bacnet-stack form is a comma-separated array. Remove only one outer
    # wrapper so inner values remain intact.
    trimmed = text.strip()
    if (trimmed.startswith("[") and trimmed.endswith("]")) or (trimmed.startswith("{") and trimmed.endswith("}")):
        trimmed = trimmed[1:-1].strip()

    entries = split_top_level_commas(trimmed)
    if len(entries) >= 16:
        return entries[:16]

    # Fallback for formats like "[1] NULL [2] Real 72.0 ...".
    indexed = re.findall(r"\[\s*(\d{1,2})\s*\]\s*([^\[]+)", text)
    if indexed:
        out = [""] * 16
        for idx_text, value in indexed:
            idx = int(idx_text)
            if 1 <= idx <= 16:
                out[idx - 1] = value.strip(" ,;:")
        return out

    return entries


def active_priority_from_array(raw: str) -> str:
    """Return the first non-NULL BACnet priority number, or blank if none."""
    entries = parse_priority_array_entries(raw)
    for idx, entry in enumerate(entries[:16], start=1):
        if not is_null_priority_entry(entry):
            return str(idx)
    return ""


def complete_priority_array_entries(raw: str) -> list[str]:
    """Return exactly 16 priority entries only when the metadata is complete."""
    entries = parse_priority_array_entries(raw)
    if len(entries) != 16:
        return []
    return entries


def priority_array_metadata_state(raw: str) -> str:
    text = clean(raw)
    if not text:
        return "unread"
    return "complete" if complete_priority_array_entries(text) else "incomplete"


def active_priority_from_complete_array(raw: str) -> str:
    """Derive active priority only from a complete 16-slot Priority_Array."""
    entries = complete_priority_array_entries(raw)
    if not entries:
        return ""
    for idx, entry in enumerate(entries, start=1):
        if not is_null_priority_entry(entry):
            return str(idx)
    return ""


def normalize_pv_with_priority(display_pv: Any, priority_array: Any) -> dict[str, str]:
    """Return display PV/active priority using only a complete Priority_Array."""
    display = strip_priority_suffix(display_pv)
    raw_array = str(priority_array or "")
    state = priority_array_metadata_state(raw_array)
    active_priority = active_priority_from_complete_array(raw_array) if state == "complete" else ""
    return {
        "present_value": pv_with_priority(display, active_priority),
        "display_present_value": display,
        "active_priority": active_priority,
        "priority_array_state": state,
    }


def priority_array_table(raw: str) -> list[dict[str, str]]:
    names = [
        "Manual Life Safety",
        "Auto Life Safety",
        "Priority Three",
        "Priority Four",
        "Critical Equipment Control",
        "Minimum On Off",
        "Priority Seven",
        "Manual Operator",
        "Priority Nine",
        "Priority Ten",
        "Priority Eleven",
        "Priority Twelve",
        "Priority Thirteen",
        "Priority Fourteen",
        "Priority Fifteen",
        "Priority Sixteen",
    ]
    entries = parse_priority_array_entries(raw)
    rows: list[dict[str, str]] = []
    for level, name in enumerate(names, start=1):
        raw_value = entries[level - 1] if len(entries) >= level else ""
        rows.append({
            "level": str(level),
            "name": name,
            "value": "null" if is_null_priority_entry(raw_value) else raw_value,
        })
    return rows


def read_priority_array_raw(device_id: str, obj_type: str, instance: str | int, ports: list[str] | None = None) -> str:
    if not is_pv_write_type(obj_type):
        return ""
    return (
        read_property(str(device_id), obj_type, instance, "priority-array", timeout=10, ports=ports)
        or read_property(str(device_id), obj_type, instance, "87", timeout=10, ports=ports)
    )


def read_active_priority(device_id: str, obj_type: str, instance: str | int, ports: list[str] | None = None) -> tuple[str, str]:
    raw = read_priority_array_raw(device_id, obj_type, instance, ports=ports)
    return active_priority_from_array(raw), raw


def pv_with_priority(display_pv: str, active_priority: str) -> str:
    return f"{display_pv} @P{active_priority}" if active_priority else display_pv


def strip_priority_suffix(value: Any) -> str:
    return re.sub(r"\s+@P?\d+\s*$", "", str(value or "").strip(), flags=re.IGNORECASE)


def collapse_duplicated_display_value(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    parts = text.split()
    if len(parts) >= 2 and len(parts) % 2 == 0:
        midpoint = len(parts) // 2
        if parts[:midpoint] == parts[midpoint:]:
            return " ".join(parts[:midpoint])
    return text


def normalize_read_method(value: str | None) -> str:
    """Normalize all UI aliases into the two supported view-read modes."""
    method = (value or "rpm").strip().lower()
    if method in {"safe", "single", "individual", "bacrp", "slow"}:
        return "safe"
    return "rpm"


def parse_rpm_property_values(output: str) -> dict[tuple[str, int], dict[str, str]]:
    """Parse bacrpm output for multiple object/property reads.

    bacnet-stack output varies by version, so this accepts the common object
    headers already used by the object-name parser and captures simple
    property lines such as object-name, present-value, priority-array, and
    state-text. Values that span multiple lines may still fall back to bacrp.
    """
    values: dict[tuple[str, int], dict[str, str]] = {}
    current: tuple[str, int] | None = None
    prop_aliases = {
        "77": "object-name",
        "85": "present-value",
        "87": "priority-array",
        "110": "state-text",
    }

    collecting: dict[str, Any] | None = None

    def brace_delta(text: str) -> int:
        return sum(1 for ch in text if ch in "{[(") - sum(1 for ch in text if ch in "}])")

    def finish_collection() -> None:
        nonlocal collecting
        if not collecting:
            return
        key = collecting["key"]
        prop = collecting["prop"]
        lines = collecting["lines"]
        values.setdefault(key, {})[prop] = clean(" ".join(line.strip() for line in lines))
        collecting = None

    for raw_line in (output or "").splitlines():
        line = raw_line.strip()
        if not line or line in {"{", "}"} or line.startswith("device #"):
            if collecting and line == "}":
                finish_collection()
            continue

        object_match = (
            re.match(r"^\(?([a-z]+(?:-[a-z]+)*)\s*,\s*(\d+)\)?$", line, flags=re.IGNORECASE)
            or re.match(r"^([a-z]+(?:-[a-z]+)*)\s+#?(\d+)\s*$", line, flags=re.IGNORECASE)
        )
        if object_match:
            finish_collection()
            current = (object_match.group(1).strip().lower(), int(object_match.group(2)))
            values.setdefault(current, {})
            continue

        if not current:
            continue

        if collecting:
            collecting["lines"].append(line)
            collecting["balance"] += brace_delta(line)
            if collecting["balance"] <= 0:
                finish_collection()
            continue

        prop_match = re.match(r"^(?:property\s+)?([a-z]+(?:-[a-z]+)*|\d+)\s*(?::|=)\s*(.*)$", line, flags=re.IGNORECASE)
        if not prop_match:
            continue

        prop = prop_aliases.get(prop_match.group(1).strip().lower(), prop_match.group(1).strip().lower())
        val = clean(prop_match.group(2))
        if prop in {"object-name", "present-value", "priority-array", "state-text"}:
            balance = brace_delta(val)
            if prop in {"priority-array", "state-text"} and balance > 0:
                collecting = {"key": current, "prop": prop, "lines": [val], "balance": balance}
            else:
                values.setdefault(current, {})[prop] = val

    finish_collection()

    return values


def format_present_value_cached(raw_pv: str, obj_type: str, states: list[str] | None = None) -> str:
    """Format a PV using already-read RPM state-text when available."""
    if obj_type not in MULTI_STATE_TYPES:
        return raw_pv
    value = parse_numeric_present_value(raw_pv)
    states = states or []
    if value is not None and 1 <= value <= len(states):
        return f"{states[value - 1]} ({value})"
    if value is not None:
        return f"State {value} ({value})"
    return raw_pv


def _rpm_output_status(output: str) -> str:
    text = str(output or "").lower()
    if "segmentation not supported" in text:
        return "abort_segmentation_not_supported"
    if "bacnet abort" in text:
        return "abort"
    if "bacnet reject" in text:
        return "reject"
    if "timed out" in text or "apdu timeout" in text:
        return "timeout"
    if "runtime is busy" in text:
        return "client_lock_busy"
    if "error" in text:
        return "error"
    return "ok"


def read_template_points_rpm(
    device_id: str,
    points: list[dict[str, Any]],
    job_id: str | None = None,
) -> tuple[dict[tuple[str, int], dict[str, str]], dict[str, Any]]:
    """RPM-read object-name, PV, and optional priority/state text for template points.

    Missing/unparsed values are intentionally allowed; the view route falls back
    to single-property bacrp reads only where required. Saved template names are
    used directly when RPM does not return object-name, which avoids a slow
    extra bacrp read per point.
    """
    route_args = build_route_args(device_id, use_directed=True)
    native_bip_route = bool(get_saved_native_bip_route(str(device_id)))
    requested_block_size = NATIVE_BIP_RPM_VIEW_BLOCK_SIZE if native_bip_route else RPM_VIEW_BLOCK_SIZE
    block_size = max(1, min(requested_block_size, 40))
    results: dict[tuple[str, int], dict[str, str]] = {}
    stats: dict[str, Any] = {
        "method": "rpm",
        "block_size": block_size,
        "effective_block_size": block_size,
        "transport": "native-bip" if native_bip_route else "routed-or-default",
        "blocks_requested": 0,
        "batches": [],
        "points_requested": 0,
        "objects_parsed": 0,
        "properties_parsed": 0,
    }

    clean_points: list[dict[str, Any]] = []
    for point in points:
        try:
            obj_type = str(point.get("object_type", "")).strip().lower()
            instance = int(point.get("instance", ""))
        except Exception:
            continue
        if not obj_type or obj_type == "schedule":
            continue
        clean_points.append({
            "object_type": obj_type,
            "instance": instance,
            "object_name": str(point.get("object_name", "") or ""),
        })

    stats["points_requested"] = len(clean_points)
    planned_batches = math.ceil(len(clean_points) / block_size) if clean_points else 0
    stats["planned_batches"] = planned_batches
    stats["total_batches"] = planned_batches
    stats["split_batches"] = 0

    pending_blocks: list[list[dict[str, Any]]] = [
        clean_points[block_start:block_start + block_size]
        for block_start in range(0, len(clean_points), block_size)
    ]
    batch_index = 0
    preview_rows_by_key: dict[tuple[str, int], dict[str, Any]] = {}
    while pending_blocks:
        block = pending_blocks.pop(0)
        batch_index += 1
        total_batches = batch_index + len(pending_blocks)
        stats["total_batches"] = max(stats.get("total_batches", 0), total_batches)
        stats["blocks_requested"] += 1
        requested_keys = [(point["object_type"], int(point["instance"])) for point in block]
        args = ["./bacrpm", device_id]
        for point in block:
            obj_type = point["object_type"]
            instance = str(point["instance"])
            props = ["77", "85"]
            if is_pv_write_type(obj_type):
                props.append("87")
            if obj_type in MULTI_STATE_TYPES:
                props.append("110")
            args.extend([obj_type, instance, ",".join(props)])
        args.extend(route_args)

        if job_id:
            _set_job(
                VIEW_JOBS,
                VIEW_LOCK,
                job_id,
                percent=5 + int((batch_index - 1) * 25 / max(total_batches, 1)),
                current_point=f"RPM batch {batch_index}/{total_batches}",
                rpm_stats=stats,
                message=(
                    f"Sending RPM batch {batch_index} of {total_batches} "
                    f"(effective block size {block_size}, {len(block)} object(s))."
                ),
            )
        batch_started = time.monotonic()
        out = ""
        parsed: dict[tuple[str, int], dict[str, str]] = {}
        try:
            out = run_bacnet(args, timeout=30)
            parsed = parse_rpm_property_values(out)
        except Exception:
            parsed = {}
        elapsed = time.monotonic() - batch_started
        output_status = _rpm_output_status(out)
        parsed_keys = set(parsed.keys())
        missing_keys = [f"{obj_type}:{instance}" for obj_type, instance in requested_keys if (obj_type, instance) not in parsed_keys]
        split_for_retry = output_status == "abort_segmentation_not_supported" and len(block) > 1
        object_keys = [f"{obj_type}:{instance}" for obj_type, instance in requested_keys]
        batch_stats = {
            "batch": batch_index,
            "total_batches": total_batches,
            "requested_count": len(block),
            "parsed_count": len(parsed),
            "missing_count": len(missing_keys),
            "missing_objects": missing_keys,
            "object_keys": object_keys,
            "returned_object_keys": [f"{obj_type}:{instance}" for obj_type, instance in parsed.keys()],
            "elapsed_sec": round(elapsed, 3),
            "status": "split_retry" if split_for_retry else output_status,
        }
        stats["batches"].append(batch_stats)
        if split_for_retry:
            midpoint = max(1, len(block) // 2)
            pending_blocks = [block[:midpoint], block[midpoint:]] + pending_blocks
            stats["split_batches"] += 1
            stats["total_batches"] = batch_index + len(pending_blocks)
            if job_id:
                _set_job(
                    VIEW_JOBS,
                    VIEW_LOCK,
                    job_id,
                    percent=5 + int(batch_index * 25 / max(stats["total_batches"], 1)),
                    current_point=f"RPM batch {batch_index}/{stats['total_batches']}",
                    rpm_stats=stats,
                    message=(
                        f"RPM batch {batch_index} was too large for an unsegmented response; "
                        f"splitting {len(block)} object(s) into smaller RPM batches."
                    ),
                )
            continue
        if job_id:
            _set_job(
                VIEW_JOBS,
                VIEW_LOCK,
                job_id,
                percent=5 + int(batch_index * 25 / max(total_batches, 1)),
                current_point=f"RPM batch {batch_index}/{total_batches}",
                rpm_stats=stats,
                message=(
                    f"RPM batch {batch_index} of {total_batches} returned "
                    f"{len(parsed)} of {len(block)} object(s) in {elapsed:.2f}s "
                    f"({output_status})."
                ),
            )

        for key, props in parsed.items():
            results.setdefault(key, {}).update(props)
        if job_id:
            for point in block:
                key = (point["object_type"], int(point["instance"]))
                props = results.get(key, {})
                if not props:
                    continue
                obj_type, instance = key
                raw_pv = props.get("present-value", "")
                state_text = parse_state_text(props.get("state-text", "")) if obj_type in MULTI_STATE_TYPES else []
                display_pv = format_present_value_cached(raw_pv, obj_type, state_text)
                active_priority = ""
                priority_array = ""
                priority_array_state = "unread"
                if is_pv_write_type(obj_type):
                    priority_array = props.get("priority-array", "")
                    priority_array_state = priority_array_metadata_state(priority_array)
                    active_priority = active_priority_from_complete_array(priority_array)
                preview_rows_by_key[key] = {
                    "object_type": obj_type,
                    "type_label": TYPE_LABELS.get(obj_type, obj_type),
                    "instance": instance,
                    "object_name": props.get("object-name") or point.get("object_name", ""),
                    "expected_name": point.get("object_name", ""),
                    "present_value": pv_with_priority(display_pv, active_priority),
                    "display_present_value": display_pv,
                    "raw_present_value": raw_pv,
                    "active_priority": active_priority,
                    "priority_array": priority_array,
                    "priority_array_state": priority_array_state,
                    "state_options": state_text,
                    "status": "OK" if raw_pv != "" else "No PV / unreadable",
                    "timestamp": datetime.now().isoformat(timespec="seconds"),
                    "read_source": "RPM",
                }
            _set_job(
                VIEW_JOBS,
                VIEW_LOCK,
                job_id,
                scanned=len(preview_rows_by_key),
                partial_rows=list(preview_rows_by_key.values()),
                found_count=len(preview_rows_by_key),
                rpm_stats=stats,
            )

    stats["objects_parsed"] = len(results)
    stats["properties_parsed"] = sum(len(props) for props in results.values())
    return results, stats


def normalize_pv_write_type(obj_type: str) -> str:
    obj_type = (obj_type or "").strip().lower()
    aliases = {
        "ao": "analog-output",
        "av": "analog-value",
        "bo": "binary-output",
        "bv": "binary-value",
        "mso": "multi-state-output",
        "msv": "multi-state-value",
        "msi": "multi-state-input",
        "analog-output": "analog-output",
        "analog-value": "analog-value",
        "binary-output": "binary-output",
        "binary-value": "binary-value",
        "multi-state-output": "multi-state-output",
        "multi-state-value": "multi-state-value",
        "multi-state-input": "multi-state-input",
    }
    return aliases.get(obj_type, "analog-value")


def default_pv_tag(obj_type: str) -> str:
    obj_type = normalize_pv_write_type(obj_type)
    return PV_WRITE_TYPES[obj_type]["tag"]


def parse_numeric_present_value(value: str) -> int | None:
    """Extract the numeric BACnet state/value from bacrp output."""
    text = clean(value)
    match = re.search(r"[-+]?\d+", text)
    if not match:
        return None
    try:
        return int(match.group(0))
    except ValueError:
        return None


def parse_state_text(raw: str) -> list[str]:
    """Parse BACnet state-text output into a 1-based list of state names."""
    text = clean(raw)
    if not text:
        return []

    quoted = re.findall(r'"([^"\\]*(?:\\.[^"\\]*)*)"', text)
    if quoted:
        return [item.strip() for item in quoted if item.strip()]

    text = text.strip().strip("{}[]()")
    if not text:
        return []
    parts = [part.strip().strip('"') for part in re.split(r"[,;]", text)]
    return [part for part in parts if part]


def _state_text_array_length(raw: str) -> int | None:
    text = clean(raw)
    match = re.search(r"\d+", text or "")
    if not match:
        return None
    try:
        length = int(match.group(0))
    except ValueError:
        return None
    return length if 0 <= length <= 256 else None


def read_state_text_options(
    device_id: str,
    obj_type: str,
    instance: str | int,
    ports: list[str] | None = None,
) -> dict[str, Any]:
    """Read BACnet State_Text using array length/indexes, with whole-array fallback."""
    obj_type = (obj_type or "").strip().lower()
    if obj_type not in MULTI_STATE_TYPES:
        return {"states": [], "status": "not-multi-state", "error": ""}

    errors: list[str] = []
    for prop in ("state-text", "110"):
        raw_length = read_property(str(device_id), obj_type, instance, prop, timeout=8, ports=ports, array_index=0)
        length = _state_text_array_length(raw_length)
        if length is not None:
            states: list[str] = []
            for index in range(1, length + 1):
                raw_state = read_property(str(device_id), obj_type, instance, prop, timeout=8, ports=ports, array_index=index)
                state = clean(raw_state)
                if not state or _bacnet_output_failed(raw_state):
                    errors.append(f"{prop}[{index}]: {raw_state or 'blank'}")
                    continue
                states.append(state)
            return {
                "states": states,
                "status": "ok" if len(states) == length else "partial",
                "error": "; ".join(errors),
                "property": prop,
                "length": length,
            }
        if raw_length:
            errors.append(f"{prop}[0]: {raw_length}")

    for prop in ("state-text", "110"):
        raw = read_property(str(device_id), obj_type, instance, prop, timeout=8, ports=ports)
        states = [] if _bacnet_output_failed(raw) else parse_state_text(raw)
        if states:
            return {
                "states": states,
                "status": "ok",
                "error": "",
                "property": prop,
                "length": len(states),
            }
        if raw:
            errors.append(f"{prop}: {raw}")

    return {"states": [], "status": "unsupported", "error": "; ".join(errors), "property": "", "length": 0}


def read_state_text(device_id: str, obj_type: str, instance: str | int, ports: list[str] | None = None) -> list[str]:
    if obj_type not in MULTI_STATE_TYPES:
        return []
    return list(read_state_text_options(str(device_id), obj_type, instance, ports=ports).get("states") or [])


def format_present_value(device_id: str, obj_type: str, instance: str | int, raw_pv: str, ports: list[str] | None = None) -> str:
    """Display MSV/MSO/MSI as State Text (numeric value)."""
    if obj_type not in MULTI_STATE_TYPES:
        return raw_pv
    value = parse_numeric_present_value(raw_pv)
    states = read_state_text(str(device_id), obj_type, instance, ports=ports)
    if value is not None and 1 <= value <= len(states):
        return f"{states[value - 1]} ({value})"
    if value is not None:
        return f"State {value} ({value})"
    return raw_pv


def read_priority_snapshot(device_id: str, obj_type: str, instance: str | int, ports: list[str] | None = None) -> dict[str, str]:
    obj_type = normalize_pv_write_type(obj_type)
    object_name = read_property(str(device_id), obj_type, instance, "object-name", timeout=8, ports=ports)
    raw_pv = (
        read_property(str(device_id), obj_type, instance, "present-value", timeout=8, ports=ports)
        or read_property(str(device_id), obj_type, instance, "85", timeout=8, ports=ports)
    )
    states = read_state_text(str(device_id), obj_type, instance, ports=ports)
    priority_array = read_priority_array_raw(str(device_id), obj_type, instance, ports=ports)
    active_priority = active_priority_from_array(priority_array)
    display_pv = format_present_value(str(device_id), obj_type, instance, raw_pv, ports=ports)
    return {
        "object_name": object_name,
        "present_value": pv_with_priority(display_pv, active_priority),
        "display_present_value": display_pv,
        "raw_present_value": raw_pv,
        "active_priority": active_priority,
        "state_text": ", ".join([f"{idx + 1}={name}" for idx, name in enumerate(states)]),
        "state_options": states,
        "selected_state": str(parse_numeric_present_value(raw_pv) or ""),
        "priority_array": priority_array,
        "relinquish_default": read_property(str(device_id), obj_type, instance, "relinquish-default", timeout=8, ports=ports)
        or read_property(str(device_id), obj_type, instance, "104", timeout=8, ports=ports),
    }

def write_relinquish_default(device_id: str, obj_type: str, instance: str | int, tag: str, value: str) -> dict[str, Any]:
    """Write BACnet Relinquish_Default / property 104.

    This is the safer default commissioning write because it changes the value
    the object falls back to after all priority-array commands are NULL. It does
    not occupy Priority 16 or any other command priority.
    """
    obj_type = normalize_pv_write_type(obj_type)
    tag = str(tag or default_pv_tag(obj_type)).strip()
    value = str(value).strip()
    if value == "":
        return {"ok": False, "message": "Relinquish Default value is required."}

    try:
        command = [
            "./bacwp",
            str(device_id),
            obj_type,
            str(instance),
            "relinquish-default",
            "0",
            "-1",
            tag,
            value,
        ]
        native_binding = _native_bip_write_binding(str(device_id))
        if native_binding:
            detail = _run_native_bip_bacwp_with_address_cache(
                command,
                native_binding,
                timeout=20,
                ports=get_edge_program_bacnet_ports(),
            )
            out = str(detail.get("output") or "")
            snapshot = read_priority_snapshot_native_bip(native_binding, obj_type, instance)
        else:
            out = run_bacnet(command, timeout=20)
            snapshot = read_priority_snapshot(str(device_id), obj_type, instance)
        ack = "WriteProperty Acknowledged" in out
        return {
            "ok": ack,
            "ack": ack,
            "device": str(device_id),
            "object_type": obj_type,
            "instance": str(instance),
            "property": "relinquish-default",
            "priority": 0,
            "tag": tag,
            "value": value,
            "relinquish": False,
            "message": out or "No bacwp output",
            "snapshot": snapshot,
        }
    except Exception as exc:
        return {
            "ok": False,
            "device": str(device_id),
            "object_type": obj_type,
            "instance": str(instance),
            "property": "relinquish-default",
            "priority": 0,
            "tag": tag,
            "value": value,
            "relinquish": False,
            "message": str(exc),
            "snapshot": {},
        }


def write_present_value(
    device_id: str,
    obj_type: str,
    instance: str | int,
    priority: int,
    tag: str,
    value: str,
    relinquish: bool = False,
    ports: list[str] | None = None,
) -> dict[str, Any]:
    obj_type = normalize_pv_write_type(obj_type)
    priority = max(1, min(16, int(priority or 16)))
    if relinquish:
        tag = "0"
        value = "0"
    else:
        tag = str(tag or default_pv_tag(obj_type)).strip()
        value = str(value).strip()

    if not relinquish and value == "":
        return {"ok": False, "message": "Write value is required."}

    try:
        command = [
            "./bacwp",
            str(device_id),
            obj_type,
            str(instance),
            "present-value",
            str(priority),
            "-1",
            tag,
            value,
        ]
        native_binding = _native_bip_write_binding(str(device_id))
        if native_binding:
            detail = _run_native_bip_bacwp_with_address_cache(
                command,
                native_binding,
                timeout=20,
                ports=get_edge_program_bacnet_ports(),
            )
        else:
            detail = run_bacnet_detailed(command, timeout=20, ports=ports)
        out = str(detail.get("output") or "")
        snapshot = (
            read_priority_snapshot_native_bip(native_binding, obj_type, instance)
            if native_binding
            else read_priority_snapshot(str(device_id), obj_type, instance, ports=ports)
        )
        ack = "WriteProperty Acknowledged" in out
        readback_confirmed = bool(str(snapshot.get("raw_present_value") or snapshot.get("present_value") or "").strip())
        return {
            "ok": ack and readback_confirmed,
            "ack": ack,
            "readback_confirmed": readback_confirmed,
            "device": str(device_id),
            "object_type": obj_type,
            "instance": str(instance),
            "property": "present-value",
            "priority": priority,
            "tag": tag,
            "value": value,
            "relinquish": relinquish,
            "message": out or ("Write acknowledged but readback failed." if ack else "No bacwp output"),
            "snapshot": snapshot,
            "diagnostics": {
                "command": detail.get("args") or command,
                "source_port": detail.get("port") or "",
                "returncode": detail.get("returncode"),
                "stdout": detail.get("stdout") or "",
                "stderr": detail.get("stderr") or "",
                "elapsed_sec": detail.get("elapsed_sec"),
                "timed_out": bool(detail.get("timed_out")),
                "native_bip_address_cache": detail.get("native_bip_address_cache") or "",
            },
        }
    except Exception as exc:
        return {
            "ok": False,
            "device": str(device_id),
            "object_type": obj_type,
            "instance": str(instance),
            "property": "present-value",
            "priority": priority,
            "tag": tag,
            "value": value,
            "relinquish": relinquish,
            "message": str(exc),
            "snapshot": {},
        }


# --- Timed override helpers -------------------------------------------------
TIMED_OVERRIDE_MAX_ATTEMPTS = int(os.environ.get("TIMED_OVERRIDE_MAX_ATTEMPTS", "5"))
TIMED_OVERRIDE_ANALOG_TOLERANCE = float(os.environ.get("TIMED_OVERRIDE_ANALOG_TOLERANCE", "0.001"))


def timed_override_retry_delay(attempt_count: int) -> int:
    if attempt_count <= 0:
        return 30
    if attempt_count == 1:
        return 60
    return 300


def timed_override_user() -> str:
    return str(session.get("username") or session.get("user") or AUTH_USERNAME or "operator")


def timed_override_gateway() -> dict[str, str]:
    gateway = get_gateway_identity()
    ip = gateway.get("ip") or ""
    interface = gateway.get("interface") or ""
    if ip.startswith("127.") or ip in {"", "UNKNOWN"}:
        try:
            config = routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS)
            bip = next((item for item in config.get("bip_interfaces") or [] if item.get("enabled")), None)
            bind_address = str((bip or {}).get("bind_address") or "").strip()
            if bind_address and bind_address not in {"0.0.0.0", "127.0.0.1"}:
                ip = bind_address
                interface = str((bip or {}).get("linux_interface") or interface)
        except Exception:
            pass
    return {
        "gateway_id": socket.gethostname(),
        "gateway_ip": ip,
        "gateway_interface": interface,
        "gateway_state": gateway.get("state") or "",
    }


def timed_override_route_snapshot(device_id: str) -> dict[str, Any]:
    route = get_cached_bacnet_route(str(device_id))
    route_args, ports = get_cached_bacnet_request_route(str(device_id))
    native_binding = _native_bip_write_binding(str(device_id))
    classification = "native-bip" if native_binding else ("routed" if route_args else "default")
    return {
        "classification": classification,
        "cached_route": route,
        "route_args": route_args,
        "ports": ports or [],
        "native_binding": native_binding,
    }


def timed_override_priority_entry(snapshot: dict[str, Any], priority: int) -> str:
    entries = parse_priority_array_entries(str(snapshot.get("priority_array") or ""))
    if 1 <= priority <= len(entries):
        return str(entries[priority - 1]).strip()
    return ""


def _numeric_value(value: Any) -> float | None:
    text = clean(str(value or ""))
    match = re.search(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)", text)
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def normalize_timed_override_value(obj_type: str, tag: str, value: Any) -> str:
    obj_type = normalize_pv_write_type(obj_type)
    family = PV_WRITE_TYPES.get(obj_type, {}).get("family")
    if family == "analog":
        number = _numeric_value(value)
        if number is None:
            raise ValueError("Analog timed override value must be numeric.")
        return f"{number:.6f}".rstrip("0").rstrip(".")
    number = parse_numeric_present_value(str(value))
    if number is None:
        raise ValueError("Timed override value must include a BACnet state number.")
    return str(number)


def timed_override_values_match(obj_type: str, expected_normalized: str, current_raw: str) -> bool:
    obj_type = normalize_pv_write_type(obj_type)
    if is_null_priority_entry(current_raw):
        return False
    family = PV_WRITE_TYPES.get(obj_type, {}).get("family")
    if family == "analog":
        expected = _numeric_value(expected_normalized)
        current = _numeric_value(current_raw)
        if expected is None or current is None:
            return False
        tolerance = max(TIMED_OVERRIDE_ANALOG_TOLERANCE, abs(expected) * 0.00001)
        return abs(expected - current) <= tolerance
    current = parse_numeric_present_value(current_raw)
    try:
        expected_int = int(float(expected_normalized))
    except Exception:
        return False
    return current == expected_int


def timed_override_read_snapshot(row: dict[str, Any]) -> dict[str, str]:
    native_binding = _native_bip_write_binding(str(row["device_id"]))
    if native_binding:
        return read_priority_snapshot_native_bip(native_binding, str(row["object_type"]), str(row["object_instance"]))
    return read_priority_snapshot(str(row["device_id"]), str(row["object_type"]), str(row["object_instance"]), ports=get_edge_program_bacnet_ports())


def create_timed_override(
    *,
    device_id: str,
    obj_type: str,
    instance: str | int,
    priority: int,
    tag: str,
    value: str,
    duration_amount: int,
    duration_unit: str,
    description: str = "",
    display_value: str = "",
    source_page: str = "",
    created_by: str = "",
) -> dict[str, Any]:
    block_live_operation("Timed override creation")
    obj_type = normalize_pv_write_type(obj_type)
    if obj_type not in PV_WRITE_TYPES:
        raise ValueError("Only AO, AV, BO, BV, MSO, and MSV timed overrides are enabled.")
    priority = max(1, min(16, int(priority)))
    amount = int(duration_amount)
    if amount <= 0:
        raise ValueError("Timed override duration must be greater than zero.")
    unit = (duration_unit or "minutes").strip().lower()
    if unit not in {"minutes", "hours", "days"}:
        raise ValueError("Duration unit must be minutes, hours, or days.")
    delta = {"minutes": timedelta(minutes=amount), "hours": timedelta(hours=amount), "days": timedelta(days=amount)}[unit]
    expires_at = (datetime.now(timezone.utc) + delta).replace(microsecond=0).isoformat()
    tag = str(tag or default_pv_tag(obj_type)).strip()
    normalized_requested = normalize_timed_override_value(obj_type, tag, value)

    result = write_present_value(str(device_id), obj_type, instance, priority, tag, str(value), relinquish=False)
    if not result.get("ok") or not result.get("ack"):
        raise RuntimeError(str(result.get("message") or "Timed override write was not acknowledged."))
    snapshot = result.get("snapshot") or {}
    entry = timed_override_priority_entry(snapshot, priority)
    if is_null_priority_entry(entry):
        raise RuntimeError("Timed override write ACKed, but selected priority read back Null.")
    normalized_confirmed = normalize_timed_override_value(obj_type, tag, entry)
    if not timed_override_values_match(obj_type, normalized_requested, entry):
        raise RuntimeError(f"Timed override readback mismatch at priority {priority}: {entry}")

    gateway = timed_override_gateway()
    route_snapshot = timed_override_route_snapshot(str(device_id))
    override_id = f"to-{uuid4().hex}"
    payload = {
        "id": override_id,
        "gateway_id": gateway["gateway_id"],
        "gateway_ip": gateway["gateway_ip"],
        "device_id": str(device_id),
        "object_type": obj_type,
        "object_instance": str(instance),
        "description": description or str(snapshot.get("object_name") or ""),
        "property_identifier": "present-value",
        "priority": priority,
        "bacnet_tag": tag,
        "requested_value": str(value),
        "requested_value_normalized": normalized_requested,
        "confirmed_value": entry,
        "confirmed_value_normalized": normalized_confirmed,
        "display_value": display_value or str(snapshot.get("display_present_value") or value),
        "route_classification": str(route_snapshot.get("classification") or ""),
        "route_snapshot_json": json.dumps(route_snapshot, sort_keys=True),
        "source_page": source_page,
        "created_by": created_by or timed_override_user(),
        "expires_at": expires_at,
        "status": "active",
    }
    store = timed_override_store()
    row = store.create_override(payload)
    store.add_audit(override_id, "created", {"write_result": result, "expires_at": expires_at}, operator=payload["created_by"])
    return {"ok": True, "override": row, "write_result": result}


def expire_timed_override(override_id: str, *, operator: str = "scheduler") -> dict[str, Any]:
    row = timed_override_store().get(str(override_id))
    if not row:
        raise KeyError(override_id)
    if str(row.get("status")) not in set(ACTIONABLE_STATUSES):
        return {"ok": True, "status": row.get("status"), "message": "Override is not active."}
    try:
        snapshot = timed_override_read_snapshot(row)
        entry = timed_override_priority_entry(snapshot, int(row["priority"]))
    except Exception as exc:
        if int(row.get("attempt_count") or 0) + 1 >= TIMED_OVERRIDE_MAX_ATTEMPTS:
            updated = timed_override_store().finish(str(override_id), "failed", f"Readback failed: {exc}", {"error": str(exc)}, operator=operator)
            return {"ok": False, "status": "failed", "override": updated}
        updated = timed_override_store().retry_later(str(override_id), f"Readback failed: {exc}", delay_seconds=timed_override_retry_delay(int(row.get("attempt_count") or 0)), operator=operator)
        return {"ok": False, "status": "retry_pending", "override": updated}

    if is_null_priority_entry(entry):
        updated = timed_override_store().finish(str(override_id), "already_relinquished", "Priority entry was already Null.", {"entry": entry, "snapshot": snapshot}, operator=operator)
        return {"ok": True, "status": "already_relinquished", "override": updated}
    if not timed_override_values_match(str(row["object_type"]), str(row["confirmed_value_normalized"]), entry):
        updated = timed_override_store().finish(str(override_id), "superseded", "Priority value changed before expiration.", {"expected": row["confirmed_value_normalized"], "current": entry, "snapshot": snapshot}, operator=operator)
        return {"ok": True, "status": "superseded", "override": updated}

    result = write_present_value(str(row["device_id"]), str(row["object_type"]), str(row["object_instance"]), int(row["priority"]), "0", "", relinquish=True)
    if not result.get("ok") or not result.get("ack"):
        error = str(result.get("message") or "Relinquish was not acknowledged.")
        if int(row.get("attempt_count") or 0) + 1 >= TIMED_OVERRIDE_MAX_ATTEMPTS:
            updated = timed_override_store().finish(str(override_id), "failed", error, {"relinquish_result": result}, operator=operator)
            return {"ok": False, "status": "failed", "override": updated}
        updated = timed_override_store().retry_later(str(override_id), error, delay_seconds=timed_override_retry_delay(int(row.get("attempt_count") or 0)), operator=operator)
        return {"ok": False, "status": "retry_pending", "override": updated}
    after = result.get("snapshot") or timed_override_read_snapshot(row)
    after_entry = timed_override_priority_entry(after, int(row["priority"]))
    if not is_null_priority_entry(after_entry):
        error = f"Relinquish ACKed, but priority {row['priority']} read back {after_entry}."
        updated = timed_override_store().retry_later(str(override_id), error, delay_seconds=timed_override_retry_delay(int(row.get("attempt_count") or 0)), operator=operator)
        return {"ok": False, "status": "retry_pending", "override": updated}
    updated = timed_override_store().finish(str(override_id), "completed", "Matching priority value relinquished and confirmed Null.", {"before": entry, "relinquish_result": result, "after": after_entry}, operator=operator)
    return {"ok": True, "status": "completed", "override": updated}


def bulk_process_timed_overrides(override_ids: list[str], action: str, *, operator: str = "") -> dict[str, Any]:
    summary = {
        "total_processed": 0,
        "matched_and_relinquished": 0,
        "superseded_and_skipped": 0,
        "already_relinquished": 0,
        "retry_pending": 0,
        "failed": 0,
        "canceled": 0,
        "results": [],
    }
    store = timed_override_store()
    for override_id in override_ids:
        row = store.get(str(override_id))
        if not row:
            continue
        summary["total_processed"] += 1
        if action == "cancel_timer":
            updated = store.cancel_timer_only(str(override_id), operator=operator)
            summary["canceled"] += 1
            result = {"id": override_id, "status": "canceled", "ok": True, "override": updated}
        else:
            lock_until = (datetime.now(timezone.utc) + timedelta(seconds=45)).replace(microsecond=0).isoformat()
            claimed = store.claim(str(override_id), f"bulk:{operator or 'operator'}", lock_until)
            if not claimed:
                result = {"id": override_id, "status": row.get("status"), "ok": False, "message": "Override could not be claimed."}
                summary["failed"] += 1
            else:
                result = expire_timed_override(str(override_id), operator=operator or "operator")
                status = str(result.get("status") or "")
                if status == "completed":
                    summary["matched_and_relinquished"] += 1
                elif status == "superseded":
                    summary["superseded_and_skipped"] += 1
                elif status == "already_relinquished":
                    summary["already_relinquished"] += 1
                elif status == "retry_pending":
                    summary["retry_pending"] += 1
                elif status == "failed":
                    summary["failed"] += 1
        summary["results"].append(result)
    store.add_audit("bulk", action, {"operator": operator, "override_ids": override_ids, "summary": summary}, operator=operator)
    return summary


def timed_override_bulk_summary(result: dict[str, Any]) -> str:
    return (
        f"Timed override bulk action: selected {result.get('total_processed', 0)}, "
        f"relinquished {result.get('matched_and_relinquished', 0)}, "
        f"canceled {result.get('canceled', 0)}, "
        f"superseded/skipped {result.get('superseded_and_skipped', 0)}, "
        f"already relinquished {result.get('already_relinquished', 0)}, "
        f"retry pending {result.get('retry_pending', 0)}, "
        f"failed {result.get('failed', 0)}."
    )


def short_timed_override_id(override_id: Any) -> str:
    text = str(override_id or "")
    if len(text) <= 14:
        return text
    return f"{text[:8]}…{text[-5:]}"


def timed_override_local_time(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return "—"
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return text
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")


def timed_override_remaining_label(expires_at: Any) -> str:
    text = str(expires_at or "").strip()
    if not text:
        return "—"
    try:
        expires = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return "—"
    if expires.tzinfo is None:
        expires = expires.replace(tzinfo=timezone.utc)
    seconds = int((expires - datetime.now(timezone.utc)).total_seconds())
    if seconds <= 0:
        return "due"
    if seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    if seconds < 86400:
        return f"{seconds // 3600}h {(seconds % 3600) // 60}m"
    return f"{seconds // 86400}d {(seconds % 86400) // 3600}h"


def timed_override_detail_items(row: dict[str, Any], fields: list[tuple[str, str]]) -> list[dict[str, str]]:
    items: list[dict[str, str]] = []
    for key, label in fields:
        value = row.get(key)
        items.append({
            "key": key,
            "label": label,
            "value": "—" if value in {None, ""} else str(value),
        })
    return items


def timed_override_live_status(row: dict[str, Any]) -> dict[str, Any]:
    snapshot = timed_override_read_snapshot(row)
    priority = int(row.get("priority") or 0)
    entry = timed_override_priority_entry(snapshot, priority)
    expected = str(row.get("confirmed_value_normalized") or "")
    matches = timed_override_values_match(str(row.get("object_type") or ""), expected, entry)
    return {
        "snapshot": snapshot,
        "priority_entry": entry,
        "matches": matches,
        "state": "matches" if matches else ("null" if is_null_priority_entry(entry) else "superseded"),
        "refreshed_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
    }


def timed_override_detail_payload(override_id: str, *, refresh_live: bool = False) -> tuple[dict[str, Any] | None, int]:
    row = timed_override_store().get(override_id)
    if not row:
        return None, 404
    try:
        route_snapshot = json.loads(row.get("route_snapshot_json") or "{}")
    except Exception:
        route_snapshot = {}
    live_status: dict[str, Any] | None = None
    live_error = ""
    if refresh_live:
        try:
            live_status = timed_override_live_status(row)
        except Exception as exc:
            live_error = str(exc)
    payload = {
        "ok": True,
        "override": row,
        "route_snapshot": route_snapshot,
        "current_route": timed_override_route_snapshot(str(row.get("device_id") or "")),
        "audit": timed_override_store().audit_for(override_id),
        "live_status": live_status,
        "live_error": live_error,
    }
    return payload, 200


def timed_override_action_return_url() -> str:
    candidate = ""
    if not request.is_json:
        candidate = str(request.form.get("return_to") or "").strip()
    if not candidate:
        candidate = str(request.referrer or "").strip()
    if candidate:
        try:
            parsed = urlsplit(candidate)
        except ValueError:
            parsed = None
        if parsed and not parsed.scheme and not parsed.netloc:
            path = parsed.path or "/"
            if path == "/timed-overrides" or path.startswith("/timed-overrides/"):
                target = path
                if parsed.query:
                    target = f"{target}?{parsed.query}"
                return target
    return url_for("timed_overrides_page")


def timed_override_detail_return_url(override_id: str) -> str:
    return url_for("timed_override_detail", override_id=override_id)


def timed_override_actionable_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    actionable = [row for row in rows if str(row.get("status") or "") in ACTIONABLE_STATUSES]
    priorities = sorted(
        {str(row.get("priority") or "") for row in actionable if str(row.get("priority") or "")},
        key=lambda item: int(item) if item.isdigit() else 999,
    )
    devices = {str(row.get("device_id") or "") for row in actionable if str(row.get("device_id") or "")}
    return {
        "count": len(actionable),
        "device_count": len(devices),
        "priorities": priorities,
        "priority_label": ", ".join(f"P{priority}" for priority in priorities) if priorities else "—",
    }


def wants_explicit_json_response() -> bool:
    return bool(
        request.is_json
        or request.headers.get("X-Requested-With") == "XMLHttpRequest"
        or request.headers.get("X-Edge-Api") == "1"
    )


def timed_override_filters_from_request() -> dict[str, Any]:
    status = request.args.getlist("status")
    if not status and request.args.get("default", "1") == "1":
        status = list(ACTIVE_STATUSES)
    filters: dict[str, Any] = {"statuses": [item for item in status if item]}
    for key in ["gateway", "device_id", "object_type", "object_instance", "priority", "creator", "description", "created_from", "created_to", "expires_from", "expires_to"]:
        value = request.args.get(key, "").strip()
        if value:
            filters[key] = value
    for flag in ["overdue"]:
        if request.args.get(flag):
            filters[flag] = True
    return filters


def timed_override_custom_filter_submitted() -> bool:
    filter_keys = {
        "default",
        "status",
        "gateway",
        "device_id",
        "object_type",
        "object_instance",
        "priority",
        "creator",
        "description",
        "created_from",
        "created_to",
        "expires_from",
        "expires_to",
        "overdue",
    }
    return any(key in request.args for key in filter_keys)


def timed_override_dashboard_summary(rows: list[dict[str, Any]]) -> dict[str, int]:
    now = datetime.now(timezone.utc)
    soon = now + timedelta(minutes=30)
    summary = {"active": 0, "expiring_soon": 0, "retry_pending": 0, "failed": 0}
    for row in rows:
        status = str(row.get("status") or "")
        if status == "active":
            summary["active"] += 1
        elif status == "retry_pending":
            summary["retry_pending"] += 1
        elif status == "failed":
            summary["failed"] += 1
        expires_raw = str(row.get("expires_at") or "")
        try:
            expires = datetime.fromisoformat(expires_raw.replace("Z", "+00:00"))
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            if status in ACTIONABLE_STATUSES and now <= expires <= soon:
                summary["expiring_soon"] += 1
        except Exception:
            pass
    return summary


def compact_timed_override_remaining(expires_at: str, *, now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    try:
        expires = datetime.fromisoformat(str(expires_at or "").replace("Z", "+00:00"))
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
    except Exception:
        return "time unknown"
    seconds = int((expires - now).total_seconds())
    if seconds <= 0:
        return "due"
    minutes = math.ceil(seconds / 60)
    if minutes < 1:
        return "<1m"
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    rem_minutes = minutes % 60
    if hours < 24:
        return f"{hours}h {rem_minutes}m" if rem_minutes else f"{hours}h"
    days = hours // 24
    rem_hours = hours % 24
    return f"{days}d {rem_hours}h" if rem_hours else f"{days}d"


def decorate_timed_override_badge(row: dict[str, Any], *, now: datetime | None = None) -> dict[str, Any]:
    item = dict(row)
    value = str(item.get("display_value") or item.get("confirmed_value") or item.get("requested_value") or "").strip()
    item["badge_label"] = f"Timed P{item.get('priority')}: {value} · {compact_timed_override_remaining(str(item.get('expires_at') or ''), now=now)}"
    item["badge_title"] = (
        f"Timed override {item.get('id')} | status {item.get('status')} | "
        f"created {item.get('created_at') or 'unknown'} | expires {item.get('expires_at') or 'unknown'}"
    )
    item["badge_state"] = "retrying" if item.get("status") == "retry_pending" else ("failed" if item.get("status") == "failed" else "active")
    return item


def active_timed_overrides_for_device(device_id: str) -> dict[str, list[dict[str, Any]]]:
    if not str(device_id or "").strip():
        return {}
    rows = timed_override_store().query({"statuses": list(ACTIONABLE_STATUSES), "device_id": str(device_id)})
    out: dict[str, list[dict[str, Any]]] = {}
    now = datetime.now(timezone.utc)
    for row in rows:
        key = f"{row.get('object_type')}:{row.get('object_instance')}"
        out.setdefault(key, []).append(decorate_timed_override_badge(row, now=now))
    return out


# --- Schedule helpers -------------------------------------------------------
def split_device_ids(value: str) -> list[str]:
    ids: list[str] = []
    for part in re.split(r"[\s,;]+", value or ""):
        part = part.strip()
        if part and part.isdigit() and part not in ids:
            ids.append(part)
    return ids


def parse_weekly_schedule_text(raw: str) -> dict[str, dict[str, Any]]:
    """Parse bacnet-stack weekly-schedule text into simple UI rows.

    Expected Viconics/bacnet-stack form:
    (Enumerated; Mon: [08:00:00.00 1, 17:30:00.00 0]; ...; Sun: [])
    """
    day_aliases = {
        "Mon": "Monday",
        "Tue": "Tuesday",
        "Wed": "Wednesday",
        "Thu": "Thursday",
        "Fri": "Friday",
        "Sat": "Saturday",
        "Sun": "Sunday",
    }
    parsed = {day: {"enabled": False, "on": "08:00", "off": "17:00"} for day in DAYS_OF_WEEK}
    for short, full in day_aliases.items():
        match = re.search(rf"{short}:\s*\[([^\]]*)\]", raw or "")
        if not match:
            continue
        body = match.group(1).strip()
        if not body:
            continue
        pairs = re.findall(r"(\d{2}:\d{2})(?::\d{2}\.\d{2})?\s+([^,\]]+)", body)
        if len(pairs) >= 2:
            parsed[full] = {"enabled": True, "on": pairs[0][0], "off": pairs[1][0]}
    return parsed


def weekly_schedule_string(rows: list[dict[str, Any]], value_type: str = "enumerated", on_value: str = "1", off_value: str = "0") -> str:
    """Build the exact bacnet-stack ASCII weekly-schedule value accepted by VT8650.

    Viconics reads/writes as Enumerated values where 1=occupied/on and 0=unoccupied/off.
    """
    type_prefix = {
        "enumerated": "Enumerated",
        "binary": "Enumerated",  # Viconics occupancy schedule accepted enumerated 1/0.
        "boolean": "Enumerated",
        "real": "Real",
    }.get((value_type or "enumerated").lower(), "Enumerated")
    day_short = {
        "Monday": "Mon",
        "Tuesday": "Tue",
        "Wednesday": "Wed",
        "Thursday": "Thu",
        "Friday": "Fri",
        "Saturday": "Sat",
        "Sunday": "Sun",
    }
    row_map = {r.get("day"): r for r in rows}
    parts: list[str] = []
    for day in DAYS_OF_WEEK:
        short = day_short[day]
        row = row_map.get(day, {})
        if row.get("enabled") and row.get("on") and row.get("off"):
            on = str(row["on"])[:5]
            off = str(row["off"])[:5]
            parts.append(f"{short}: [{on}:00.00 {on_value}, {off}:00.00 {off_value}]")
        else:
            parts.append(f"{short}: []")
    return f"({type_prefix}; " + "; ".join(parts) + ")"


def read_schedule(device_id: str, instance: str | int) -> dict[str, Any]:
    """Read schedule metadata plus raw and parsed weekly-schedule text."""
    weekly = read_property(str(device_id), "schedule", instance, "weekly-schedule", timeout=12)
    return {
        "device": str(device_id),
        "instance": int(instance),
        "object_name": read_property(str(device_id), "schedule", instance, "object-name", timeout=8),
        "present_value": read_property(str(device_id), "schedule", instance, "present-value", timeout=8)
        or read_property(str(device_id), "schedule", instance, "85", timeout=8),
        "weekly_schedule": weekly,
        "weekly_rows": parse_weekly_schedule_text(weekly),
        "effective_period": read_property(str(device_id), "schedule", instance, "effective-period", timeout=8),
        "schedule_default": read_property(str(device_id), "schedule", instance, "schedule-default", timeout=8),
    }


def discover_schedules_on_device(device_id: str, start_index: int = 1, end_index: int | None = None) -> list[dict[str, Any]]:
    start_index = safe_int(str(start_index), 1, minimum=1, maximum=MAX_OBJECTS)
    if end_index is None:
        end_index = DEFAULT_SCAN_LIMIT
    end_index = safe_int(str(end_index), DEFAULT_SCAN_LIMIT, minimum=1, maximum=MAX_OBJECTS)
    if end_index < start_index:
        start_index, end_index = end_index, start_index

    schedules: list[dict[str, Any]] = []
    for index in range(start_index, end_index + 1):
        try:
            out = run_bacnet(["./bacrp", device_id, "device", device_id, "object-list", str(index)], timeout=6)
        except Exception:
            continue
        parsed = parse_object_identifier(out)
        if not parsed:
            continue
        obj_type, instance = parsed
        if obj_type != "schedule":
            continue
        schedules.append({
            "index": index,
            "instance": int(instance),
            "object_name": read_property(device_id, "schedule", instance, "object-name", timeout=8),
            "present_value": read_property(device_id, "schedule", instance, "present-value", timeout=8),
        })
    return schedules


def parse_schedule_form(form: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for day in DAYS_OF_WEEK:
        key = day.lower()
        enabled = form.get(f"{key}_enabled") == "on"
        on_time = (form.get(f"{key}_on") or "").strip()
        off_time = (form.get(f"{key}_off") or "").strip()
        if enabled and on_time and off_time:
            rows.append({"day": day, "enabled": True, "on": on_time, "off": off_time})
        else:
            rows.append({"day": day, "enabled": False, "on": "", "off": ""})
    return rows


def save_schedule_plan(payload: dict[str, Any]) -> Path:
    ensure_runtime_initialized()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    devices = "-".join(payload.get("devices", [])[:3]) or "device"
    path = SCHEDULE_DIR / f"schedule-plan-{devices}-{payload.get('schedule_instance', 'x')}-{stamp}.json"
    path.write_text(json.dumps(payload, indent=2))
    return path


def apply_schedule_plan_with_helper(plan_path: Path) -> dict[str, Any]:
    """Optional legacy external helper hook."""
    block_live_operation("Schedule write helper execution")
    if not ENABLE_SCHEDULE_WRITES:
        return {"applied": False, "message": "Schedule write disabled. Plan was saved only."}
    if not SCHEDULE_WRITE_HELPER:
        return {"applied": False, "message": "No external helper configured."}
    try:
        schedule_port = get_bacnet_ports()[0]
        lock_path = _take_bacnet_lock("edge-bacnet-ui:schedule-helper", schedule_port)
    except FileExistsError:
        return {
            "applied": False,
            "message": f"BACnet runtime is busy. Another local BACnet command is already using UDP {get_bacnet_ports()[0]}.",
        }

    try:
        out = subprocess.run(
            [SCHEDULE_WRITE_HELPER, str(plan_path)],
            cwd=BASE_DIR,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            timeout=60,
        )
        return {
            "applied": out.returncode == 0,
            "message": (out.stdout + out.stderr).strip() or f"helper exit code {out.returncode}",
        }
    except Exception as exc:
        return {"applied": False, "message": str(exc)}
    finally:
        _release_bacnet_lock(lock_path)


def write_weekly_schedule(device_id: str, schedule_instance: str | int, weekly_value: str) -> dict[str, Any]:
    """Write BACnet weekly-schedule using bacnet-stack bacwp and verify readback."""
    if not ENABLE_SCHEDULE_WRITES:
        return {"device": str(device_id), "ok": False, "message": "Schedule writes disabled."}
    try:
        out = run_bacnet([
            "./bacwp",
            str(device_id),
            "schedule",
            str(schedule_instance),
            "weekly-schedule",
            "0",
            "-1",
            "-1",
            weekly_value,
        ], timeout=30)
        verify = read_property(str(device_id), "schedule", schedule_instance, "weekly-schedule", timeout=12)
        ack = "WriteProperty Acknowledged" in out
        verified = clean(verify) == clean(weekly_value)
        return {
            "device": str(device_id),
            "ok": ack and verified,
            "ack": ack,
            "verified": verified,
            "message": out or "No bacwp output",
            "verify": verify,
        }
    except Exception as exc:
        return {"device": str(device_id), "ok": False, "message": str(exc), "verify": ""}

# --- Authentication ---------------------------------------------------------
def is_json_api_request() -> bool:
    """Return JSON errors for background/API calls instead of HTML redirects."""
    return (
        request.path.startswith("/template/scan/")
        or request.headers.get("X-Requested-With") == "fetch"
        or request.accept_mimetypes.best == "application/json"
    )


def _is_loopback_request() -> bool:
    try:
        return ipaddress.ip_address(request.remote_addr or "").is_loopback
    except ValueError:
        return False


def _internal_edge_agent_authorized() -> tuple[Response, int] | None:
    if not _is_loopback_request():
        return jsonify({"ok": False, "error": "Loopback access is required."}), 403
    if not EDGE_AGENT_WRITE_TOKEN:
        return jsonify({"ok": False, "error": "Internal edge-agent write adapter is not configured."}), 503
    authorization = request.headers.get("Authorization", "")
    prefix = "Bearer "
    token = authorization[len(prefix):].strip() if authorization.startswith(prefix) else ""
    if not token or not hmac.compare_digest(token, EDGE_AGENT_WRITE_TOKEN):
        return jsonify({"ok": False, "error": "Invalid edge-agent credentials."}), 401
    return None


@app.before_request
def require_login():
    if request.path == "/api/internal/edge-agent/bacnet/write-batch":
        return _internal_edge_agent_authorized()
    if not AUTH_ENABLED:
        return None

    endpoint = request.endpoint or ""
    if endpoint in {"login", "static"}:
        return None

    next_url = request.full_path if request.query_string else request.path

    if session.get("authenticated"):
        now = int(time.time())
        try:
            last_seen = int(session.get("last_seen", now))
        except Exception:
            last_seen = now

        if SESSION_TIMEOUT_SECONDS > 0 and (now - last_seen) > SESSION_TIMEOUT_SECONDS:
            session.clear()
            if is_json_api_request():
                return {
                    "ok": False,
                    "error": "Session timed out. Please log in again, then restart the scan.",
                    "login_url": url_for("login", next=next_url),
                }, 401
            flash("Session timed out. Please log in again.", "error")
            return redirect(url_for("login", next=next_url))

        session["last_seen"] = now
        session.modified = True
        return None

    if is_json_api_request():
        return {
            "ok": False,
            "error": "Login required. Please log in, then restart the scan.",
            "login_url": url_for("login", next=next_url),
        }, 401

    return redirect(url_for("login", next=next_url))

@app.after_request
def add_no_cache_headers(response):
    if request.endpoint != "static":
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


@app.route("/login", methods=["GET", "POST"])
def login() -> str | Response:
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        if username == AUTH_USERNAME and password == AUTH_PASSWORD:
            now = int(time.time())
            session.clear()
            session.permanent = True
            session["authenticated"] = True
            session["username"] = username
            session["authenticated_at"] = now
            session["last_seen"] = now
            next_url = (request.args.get("next") or url_for("index")).strip()
            if not next_url.startswith("/"):
                next_url = url_for("index")
            return redirect(next_url)
        flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout() -> Response:
    session.clear()
    flash("Logged out.", "ok")
    return redirect(url_for("login"))


@app.route("/bacnet/runtime-mode", methods=["POST"])
def bacnet_runtime_mode() -> Response:
    mode = (request.form.get("mode") or "").strip()
    try:
        set_bacnet_mode(mode)
        label = BACNET_MODE_BY_ID[mode]["label"]
        flash(f"BACnet runtime mode set to {label}.", "ok")
    except Exception as exc:
        flash(str(exc), "error")
    next_url = (request.form.get("next") or request.referrer or url_for("index")).strip()
    if not next_url.startswith("/"):
        next_url = url_for("index")
    return redirect(next_url)


@app.route("/edge-agent/restart", methods=["POST"])
def restart_edge_agent() -> Response:
    """Restart only the fixed Edge-agent service through its fixed helper."""
    next_url = (request.form.get("next") or request.referrer or url_for("index")).strip()
    if not next_url.startswith("/"):
        next_url = url_for("index")
    if request.form.get("confirm") != "restart-edge-agent":
        record_local_audit("restart_edge_agent", "rejected", "confirmation missing")
        flash("Edge agent restart was not confirmed.", "error")
        return redirect(next_url)
    if in_safe_mode():
        record_local_audit("restart_edge_agent", "blocked", "safe mode")
        flash("Edge agent restart is disabled while EDGE_UI_SAFE_MODE=1.", "error")
        return redirect(next_url)
    try:
        result = subprocess.run(
            ["sudo", "-n", EDGE_AGENT_RESTART_HELPER],
            capture_output=True,
            text=True,
            timeout=45,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        record_local_audit("restart_edge_agent", "failed", type(exc).__name__)
        flash("Edge agent restart could not be started. Check the local service helper.", "error")
        return redirect(next_url)
    if result.returncode == 0:
        record_local_audit("restart_edge_agent", "completed", "iot-cx-agent.service active")
        flash("Edge agent restarted and is active.", "ok")
    else:
        record_local_audit("restart_edge_agent", "failed", f"helper exit {result.returncode}")
        flash("Edge agent restart failed. Check the gateway service logs.", "error")
    return redirect(next_url)



def _parse_discovery_output(raw: str, job_id: str | None = None, options: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Parse bacwi output, apply discovery filters, and enrich devices with metadata."""
    candidates: list[dict[str, str]] = _parse_bacwi_candidates(raw)

    options = options or {}
    device_filter = set(options.get("device_filter") or [])
    network_filter = set(options.get("network_filter") or [])
    include_kept = bool(options.get("include_kept", False))
    original_count = len(candidates)
    candidates = filter_discovery_candidates(candidates, device_filter, network_filter, include_kept)

    devices: list[dict[str, Any]] = []
    total = len(candidates)
    if job_id:
        _set_job(
            DISCOVERY_JOBS,
            DISCOVERY_LOCK,
            job_id,
            total=total,
            scanned=0,
            percent=10,
            found_count=0,
            message=f"Matched {total} device candidate(s) from {original_count} I-Am response(s). Reading metadata...",
        )
    for idx, item in enumerate(candidates, start=1):
        device_id = item["device"]
        if job_id:
            _set_job(
                DISCOVERY_JOBS,
                DISCOVERY_LOCK,
                job_id,
                scanned=idx - 1,
                total=total,
                percent=10 + int(((idx - 1) * 85 / total)) if total else 90,
                current_device=device_id,
                found_count=len(devices),
                message=f"Reading device metadata for {device_id} ({idx} of {total})...",
            )
        meta = read_device_metadata(device_id)
        devices.append(_normalize_device_record({
            **item,
            "name": meta.get("name", ""),
            "vendor": meta.get("vendor", ""),
            "model": meta.get("model", ""),
            "kept": True,
            "source": "discovered",
            "last_seen": datetime.now().isoformat(timespec="seconds"),
        }))
        if job_id:
            _set_job(
                DISCOVERY_JOBS,
                DISCOVERY_LOCK,
                job_id,
                scanned=idx,
                total=total,
                percent=10 + int((idx * 85 / total)) if total else 95,
                current_device=device_id,
                found_count=len(devices),
                devices=devices,
                message=f"Device {device_id} complete. Found {len(devices)} device(s).",
            )
    return devices


def _discovery_worker(job_id: str, options: dict[str, Any] | None = None) -> None:
    """Background filtered device discovery used by the Discover Devices progress UI."""
    options = options or {}
    _set_job(
        DISCOVERY_JOBS,
        DISCOVERY_LOCK,
        job_id,
        status="running",
        done=False,
        error="",
        total=0,
        scanned=0,
        percent=5,
        current_device="",
        found_count=0,
        devices=[],
        raw="",
        started_at=datetime.now().isoformat(timespec="seconds"),
        message="Sending BACnet Who-Is...",
        options=options,
    )
    try:
        raw = run_bacnet(["./bacwi"], timeout=25)
        _set_job(
            DISCOVERY_JOBS,
            DISCOVERY_LOCK,
            job_id,
            raw=raw,
            percent=10,
            message="Who-Is complete. Parsing I-Am responses...",
        )
        devices = _parse_discovery_output(raw, job_id=job_id, options=options)
        kept_devices = upsert_kept_devices(devices) if devices else load_kept_devices()
        cache_file = CACHE_DIR / "last_discovery.json"
        cache_file.write_text(json.dumps({"timestamp": datetime.now().isoformat(timespec="seconds"), "devices": kept_devices}, indent=2))
        _set_job(
            DISCOVERY_JOBS,
            DISCOVERY_LOCK,
            job_id,
            status="complete",
            done=True,
            percent=100,
            scanned=len(devices),
            total=len(devices),
            found_count=len(devices),
            devices=devices,
            message=f"Discovery complete. Found {len(devices)} device(s).",
        )
    except Exception as exc:
        _set_job(
            DISCOVERY_JOBS,
            DISCOVERY_LOCK,
            job_id,
            status="error",
            done=True,
            error=str(exc),
            message=f"Discovery failed: {exc}",
        )


def build_view_context(
    device_id: str,
    template_id: str,
    read_method: str,
    job_id: str | None = None,
    template_override: dict[str, Any] | None = None,
    saved_device: dict[str, Any] | None = None,
    refresh_static: bool = True,
) -> dict[str, Any]:
    """Read a saved template/device point list and return the render context.

    When refresh_static is False, the saved object names are trusted and only live
    values such as Present Value and priority/active priority are refreshed.
    """
    template = template_override if template_override is not None else load_template(template_id)
    rows: list[dict[str, Any]] = []
    timestamp = datetime.now().isoformat(timespec="seconds")
    template_points = normalize_template_points(template.get("points", []))
    total = len(template_points)

    rpm_values: dict[tuple[str, int], dict[str, str]] = {}
    rpm_stats: dict[str, Any] = {"method": read_method}
    if read_method == "rpm":
        if job_id:
            _set_job(
                VIEW_JOBS,
                VIEW_LOCK,
                job_id,
                percent=5,
                scanned=0,
                total=total,
                found_count=0,
                message=f"RPM batch-reading {total} template point(s)...",
            )
        rpm_values, rpm_stats = read_template_points_rpm(device_id, template_points, job_id=job_id)
        if job_id:
            _set_job(
                VIEW_JOBS,
                VIEW_LOCK,
                job_id,
                percent=35,
                scanned=0,
                total=total,
                found_count=0,
                message="RPM batch read complete. Formatting point values...",
            )

    fallback_reads = 0
    for idx, point in enumerate(template_points, start=1):
        obj_type = point.get("object_type", "")
        instance = point.get("instance", "")
        expected_name = point.get("object_name", "")
        if job_id:
            base_percent = 35 if read_method == "rpm" else 5
            span = 55 if read_method == "rpm" else 85
            _set_job(
                VIEW_JOBS,
                VIEW_LOCK,
                job_id,
                scanned=idx - 1,
                total=total,
                percent=base_percent + int(((idx - 1) * span / total)) if total else 90,
                current_point=f"{TYPE_LABELS.get(str(obj_type), str(obj_type))}{instance}",
                found_count=len(rows),
                message=f"Reading/formatting {obj_type} {instance} ({idx} of {total})...",
            )

        key: tuple[str, int] | None = None
        try:
            key = (str(obj_type).strip().lower(), int(instance))
        except Exception:
            key = None
        rpm_row = rpm_values.get(key, {}) if key else {}

        # In RPM view, trust the saved template name if RPM did not return object-name.
        # Do not spend one bacrp per point just to re-read names.
        if not refresh_static:
            actual_name = expected_name
        elif read_method == "rpm":
            actual_name = rpm_row.get("object-name") or expected_name
        else:
            actual_name = read_property(device_id, obj_type, instance, "object-name")

        raw_pv = rpm_row.get("present-value", "")
        read_source = "RPM" if raw_pv != "" else "Single fallback"
        if raw_pv == "":
            raw_pv = read_present_value(device_id, obj_type, instance)
            fallback_reads += 1

        state_text = parse_state_text(rpm_row.get("state-text", "")) if obj_type in MULTI_STATE_TYPES else []
        if obj_type in MULTI_STATE_TYPES and not state_text:
            state_text = read_state_text(device_id, obj_type, instance)
        if obj_type in MULTI_STATE_TYPES and not state_text:
            display_pv = format_present_value(device_id, obj_type, instance, raw_pv)
            fallback_reads += 1
        else:
            display_pv = format_present_value_cached(raw_pv, obj_type, state_text)

        active_priority = ""
        priority_array = ""
        priority_array_state = "unread"
        if is_pv_write_type(obj_type):
            priority_array = rpm_row.get("priority-array", "")
            if priority_array:
                priority_array_state = priority_array_metadata_state(priority_array)
                active_priority = active_priority_from_complete_array(priority_array)
            else:
                active_priority, priority_array = read_active_priority(device_id, obj_type, instance)
                priority_array_state = priority_array_metadata_state(priority_array)
                fallback_reads += 1

        display_pv_with_priority = pv_with_priority(display_pv, active_priority)
        status = "OK"
        if obj_type != "schedule" and raw_pv == "":
            status = "No PV / unreadable"
        if expected_name and actual_name and expected_name != actual_name:
            status = "Name mismatch"

        rows.append({
            "object_type": obj_type,
            "type_label": TYPE_LABELS.get(obj_type, obj_type),
            "instance": instance,
            "object_name": actual_name or expected_name,
            "expected_name": expected_name,
            "present_value": display_pv_with_priority,
            "display_present_value": display_pv,
            "raw_present_value": raw_pv,
            "active_priority": active_priority,
            "priority_array": priority_array,
            "priority_array_state": priority_array_state,
            "state_options": state_text,
            "status": status,
            "timestamp": timestamp,
            "read_source": read_source,
        })

        if job_id:
            current_object = f"{TYPE_LABELS.get(str(obj_type), str(obj_type))}{instance}"
            base_percent = 35 if read_method == "rpm" else 5
            span = 55 if read_method == "rpm" else 85
            _set_job(
                VIEW_JOBS,
                VIEW_LOCK,
                job_id,
                scanned=idx,
                total=total,
                percent=base_percent + int((idx * span / total)) if total else 90,
                current_point=current_object,
                partial_rows=rows,
                found_count=len(rows),
                message=f"{current_object} complete ({idx} of {total}).",
            )

    rpm_stats["fallback_reads"] = fallback_reads
    if job_id:
        _set_job(
            VIEW_JOBS,
            VIEW_LOCK,
            job_id,
            percent=92,
            rpm_stats=rpm_stats,
            message="Building exports and reading device summary...",
        )
    exports = export_results(device_id, template_id, rows)
    if saved_device is not None and not refresh_static:
        meta = saved_live_device_metadata(device_id, saved_device)
        rpm_stats["metadata_source"] = "saved-device-cache"
    else:
        meta = read_device_metadata(device_id)
        rpm_stats["metadata_source"] = "live-bacnet"
    return {
        "device_id": device_id,
        "meta": meta,
        "template": template,
        "saved_device": saved_device,
        "rows": rows,
        "exports": exports,
        "read_method": read_method,
        "rpm_view_block_size": RPM_VIEW_BLOCK_SIZE,
        "rpm_stats": rpm_stats,
    }


def _view_worker(job_id: str, device_id: str, template_id: str, read_method: str) -> None:
    """Background template view read used by the View Template progress UI."""
    _set_job(
        VIEW_JOBS,
        VIEW_LOCK,
        job_id,
        status="running",
        done=False,
        error="",
        device_id=device_id,
        template_id=template_id,
        read_method=read_method,
        total=0,
        scanned=0,
        percent=1,
        current_point="",
        found_count=0,
        started_at=datetime.now().isoformat(timespec="seconds"),
        message="Starting template view read...",
    )
    try:
        context = build_view_context(device_id, template_id, read_method, job_id=job_id)
        _set_job(
            VIEW_JOBS,
            VIEW_LOCK,
            job_id,
            status="complete",
            done=True,
            percent=100,
            context=context,
            found_count=len(context.get("rows", [])),
            rpm_stats=context.get("rpm_stats", {}),
            message=f"Template view complete. Read {len(context.get('rows', []))} point(s).",
        )
    except Exception as exc:
        _set_job(
            VIEW_JOBS,
            VIEW_LOCK,
            job_id,
            status="error",
            done=True,
            error=str(exc),
            message=f"Template view failed: {exc}",
        )


def _saved_device_view_worker(
    job_id: str,
    device_profile_id: str,
    read_method: str,
    point_filter: set[tuple[str, int]] | None = None,
) -> None:
    """Background live refresh for a saved device profile."""
    try:
        saved_device = load_saved_device(device_profile_id)
        device_id = str(saved_device.get("device_id", "")).strip()
        saved_points = normalize_device_points(saved_device.get("points", []))
        if point_filter:
            saved_points = [
                point for point in saved_points
                if (str(point.get("object_type", "")).strip().lower(), int(point.get("instance", -1))) in point_filter
            ]
            if not saved_points:
                raise ValueError("No selected refresh points matched this Live Device.")
        template = {
            "template_id": f"saved-device-{device_profile_id}",
            "template_name": saved_device.get("device_name") or f"Device {device_id}",
            "points": saved_points,
            "source": "saved_device",
        }
        _set_job(
            VIEW_JOBS,
            VIEW_LOCK,
            job_id,
            status="running",
            done=False,
            error="",
            device_id=device_id,
            template_id=template["template_id"],
            device_profile_id=device_profile_id,
            read_method=read_method,
            refresh_scope="selected" if point_filter else "all",
            total=len(template["points"]),
            scanned=0,
            percent=1,
            current_point="",
            partial_rows=[],
            found_count=0,
            started_at=datetime.now().isoformat(timespec="seconds"),
            message="Starting saved device live refresh...",
        )
        context = build_view_context(
            device_id=device_id,
            template_id=template["template_id"],
            read_method=read_method,
            job_id=job_id,
            template_override=template,
            saved_device=saved_device,
            refresh_static=False,
        )
        rows = context.get("rows", [])
        save_live_device_last_rows(device_profile_id, rows, merge=bool(point_filter))
        _set_job(
            VIEW_JOBS,
            VIEW_LOCK,
            job_id,
            status="complete",
            done=True,
            percent=100,
            context=context,
            partial_rows=rows,
            found_count=len(rows),
            rpm_stats=context.get("rpm_stats", {}),
            last_refreshed_at=datetime.now().isoformat(timespec="seconds"),
            message=f"Saved device refresh complete. Read {len(rows)} point(s).",
        )
    except Exception as exc:
        _set_job(
            VIEW_JOBS,
            VIEW_LOCK,
            job_id,
            status="error",
            done=True,
            error=str(exc),
            message=f"Saved device refresh failed: {exc}",
        )


def build_live_device_initial_rows(saved_device: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the saved/static point list for the Live Device page.

    This intentionally does not perform BACnet reads. The table stays visible and
    the browser refresh button updates only live columns in place.
    """
    last_rows_by_key: dict[tuple[str, str], dict[str, Any]] = {}
    for row in saved_device.get("last_rows", []) or []:
        key = (str(row.get("object_type", "")).strip().lower(), str(row.get("instance", "")).strip())
        last_rows_by_key[key] = row

    rows: list[dict[str, Any]] = []
    for point in normalize_device_points(saved_device.get("points", [])):
        obj_type = str(point.get("object_type", "")).strip().lower()
        instance = str(point.get("instance", "")).strip()
        key = (obj_type, instance)
        last = last_rows_by_key.get(key, {})
        priority_array = str(last.get("priority_array") or "")
        display_present_value = collapse_duplicated_display_value(
            last.get("display_present_value") or strip_priority_suffix(last.get("present_value", ""))
        )
        normalized_priority = normalize_pv_with_priority(display_present_value, priority_array)
        rows.append({
            "object_type": obj_type,
            "type_label": TYPE_LABELS.get(obj_type, obj_type),
            "instance": instance,
            "object_name": point.get("object_name", ""),
            "present_value": normalized_priority["present_value"],
            "display_present_value": normalized_priority["display_present_value"],
            "raw_present_value": collapse_duplicated_display_value(last.get("raw_present_value", "")),
            "active_priority": normalized_priority["active_priority"],
            "priority_array": priority_array,
            "priority_array_state": normalized_priority["priority_array_state"],
            "status": last.get("status", "Not refreshed"),
            "timestamp": last.get("timestamp", ""),
            "read_source": last.get("read_source", "Saved static point"),
        })
    return rows


def build_custom_table_columns(saved_device: dict[str, Any], rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    custom_table = saved_device.get("custom_table") or {}
    columns = custom_table.get("columns") if isinstance(custom_table, dict) else None
    if not isinstance(columns, list):
        return []
    rows_by_key = {
        (str(row.get("object_type", "")).strip().lower(), str(row.get("instance", "")).strip()): row
        for row in rows
    }
    rendered_columns: list[dict[str, Any]] = []
    for column in columns:
        rendered_rows: list[dict[str, Any]] = []
        for layout_row in column.get("rows", []) or []:
            key = (
                str(layout_row.get("object_type", "")).strip().lower(),
                str(layout_row.get("instance", "")).strip(),
            )
            live_row = dict(rows_by_key.get(key, {}))
            if not live_row:
                continue
            if not live_row.get("present_value") and layout_row.get("initial_value"):
                initial_value = collapse_duplicated_display_value(layout_row.get("initial_value"))
                live_row["present_value"] = initial_value
                live_row["display_present_value"] = initial_value
                live_row["raw_present_value"] = ""
            live_row["object_identifier"] = layout_row.get("object_identifier") or object_identifier_for_point(live_row)
            live_row["custom_description"] = layout_row.get("description") or live_row.get("object_name") or live_row["object_identifier"]
            rendered_rows.append(live_row)
        rendered_columns.append({
            "name": column.get("name") or f"Column {len(rendered_columns) + 1}",
            "rows": rendered_rows,
        })
    return rendered_columns


def save_live_device_last_rows(device_profile_id: str, rows: list[dict[str, Any]], *, merge: bool = False) -> None:
    """Persist only the last live values; the saved static point list is unchanged."""
    path = saved_device_path(device_profile_id)
    if not path.exists():
        return
    try:
        payload = json.loads(path.read_text())
    except Exception:
        return
    if merge:
        merged: dict[tuple[str, str], dict[str, Any]] = {}
        for row in payload.get("last_rows", []) or []:
            key = (str(row.get("object_type", "")).strip().lower(), str(row.get("instance", "")).strip())
            if key[0] and key[1]:
                merged[key] = row
        for row in rows:
            key = (str(row.get("object_type", "")).strip().lower(), str(row.get("instance", "")).strip())
            if key[0] and key[1]:
                if not str(row.get("present_value") or "").strip() and key in merged:
                    preserved = dict(merged[key])
                    preserved["status"] = str(row.get("status") or "Read returned blank; kept last value")
                    preserved["read_source"] = str(row.get("read_source") or "Blank refresh result")
                    preserved["timestamp"] = str(row.get("timestamp") or datetime.now().isoformat(timespec="seconds"))
                    if row.get("active_priority") is not None:
                        preserved["active_priority"] = str(row.get("active_priority") or "")
                    if row.get("priority_array") is not None:
                        preserved["priority_array"] = str(row.get("priority_array") or "")
                    preserved["priority_array_state"] = str(row.get("priority_array_state") or priority_array_metadata_state(str(row.get("priority_array") or "")))
                    merged[key] = preserved
                    continue
                merged[key] = row
        payload["last_rows"] = list(merged.values())
    else:
        payload["last_rows"] = rows
    payload["last_refreshed_at"] = datetime.now().isoformat(timespec="seconds")
    payload["updated_at"] = payload["last_refreshed_at"]
    path.write_text(json.dumps(payload, indent=2))


def normalize_refresh_point_filter(points: Any) -> set[tuple[str, int]]:
    filters: set[tuple[str, int]] = set()
    if not isinstance(points, list):
        return filters
    for point in points:
        if not isinstance(point, dict):
            continue
        obj_type = str(point.get("object_type", "")).strip().lower()
        try:
            instance = int(point.get("instance", ""))
        except Exception:
            continue
        if obj_type and instance >= 0:
            filters.add((obj_type, instance))
    return filters


def normalize_live_rows_snapshot(rows: Any) -> list[dict[str, Any]]:
    snapshots: list[dict[str, Any]] = []
    if not isinstance(rows, list):
        return snapshots
    for row in rows:
        if not isinstance(row, dict):
            continue
        obj_type = str(row.get("object_type", "")).strip().lower()
        try:
            instance = int(row.get("instance", ""))
        except Exception:
            continue
        if not obj_type or instance < 0:
            continue
        present_value = collapse_duplicated_display_value(row.get("present_value"))
        snapshots.append({
            "object_type": obj_type,
            "instance": instance,
            "present_value": present_value,
            "display_present_value": collapse_duplicated_display_value(row.get("display_present_value") or present_value),
            "raw_present_value": collapse_duplicated_display_value(row.get("raw_present_value") or ""),
            "active_priority": str(row.get("active_priority") or ""),
            "priority_array": str(row.get("priority_array") or ""),
            "status": str(row.get("status") or "Saved from Live Device screen"),
            "timestamp": str(row.get("timestamp") or datetime.now().isoformat(timespec="seconds")),
            "read_source": str(row.get("read_source") or "Saved screen value"),
        })
    return snapshots


def build_live_device_refresh(
    device_profile_id: str,
    read_method: str,
    point_filter: set[tuple[str, int]] | None = None,
) -> dict[str, Any]:
    """Refresh only live values for a saved device and return JSON-friendly rows.

    No object-list scan and no object-name rebuild happens here. Object names come
    from the saved device profile. Only Present Value / 85, priority array, active
    priority, and read status are updated.
    """
    saved_device = load_saved_device(device_profile_id)
    device_id = str(saved_device.get("device_id", "")).strip()
    saved_points = normalize_device_points(saved_device.get("points", []))
    if point_filter:
        saved_points = [
            point for point in saved_points
            if (str(point.get("object_type", "")).strip().lower(), int(point.get("instance", -1))) in point_filter
        ]
        if not saved_points:
            raise ValueError("No selected refresh points matched this Live Device.")
    template = {
        "template_id": f"saved-device-{device_profile_id}",
        "template_name": saved_device.get("device_name") or f"Device {device_id}",
        "points": saved_points,
        "source": "saved_device",
    }
    context = build_view_context(
        device_id=device_id,
        template_id=template["template_id"],
        read_method=read_method,
        template_override=template,
        saved_device=saved_device,
        refresh_static=False,
    )
    rows = context.get("rows", [])
    save_live_device_last_rows(device_profile_id, rows, merge=bool(point_filter))
    return {
        "ok": True,
        "device_profile_id": device_profile_id,
        "device_id": device_id,
        "device_name": saved_device.get("device_name", ""),
        "read_method": read_method,
        "refresh_scope": "selected" if point_filter else "all",
        "rows": rows,
        "count": len(rows),
        "rpm_stats": context.get("rpm_stats", {}),
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "last_refreshed_at": datetime.now().isoformat(timespec="seconds"),
    }



# --- BACnet Program Object / PRG helpers -----------------------------------
PROGRAM_CHANGE_COMMANDS = {
    "ready": {"value": 0, "label": "Ready", "danger": False},
    "run": {"value": 2, "label": "Run", "danger": True},
    "halt": {"value": 3, "label": "Halt", "danger": True},
    "restart": {"value": 4, "label": "Restart", "danger": True},
}


def read_program_object(device_id: str, program_instance: str | int) -> dict[str, Any]:
    """Read the useful BACnet Program object status properties.

    KMC BAC-190063 testing confirmed these reads on port 47809:
    object-name, description, program-state, program-change, reason-for-halt,
    and status-flags. Reliability may not be supported on every controller.
    """
    device_id = str(device_id).strip()
    program_instance = str(program_instance).strip()
    return {
        "device": device_id,
        "instance": program_instance,
        "object_name": read_property(device_id, "program", program_instance, "object-name", timeout=8),
        "description": read_property(device_id, "program", program_instance, "description", timeout=8),
        "object_identifier": read_property(device_id, "program", program_instance, "object-identifier", timeout=8),
        "object_type": read_property(device_id, "program", program_instance, "object-type", timeout=8),
        "program_state": read_property(device_id, "program", program_instance, "program-state", timeout=8)
        or read_property(device_id, "program", program_instance, "92", timeout=8),
        "program_change": read_property(device_id, "program", program_instance, "program-change", timeout=8)
        or read_property(device_id, "program", program_instance, "90", timeout=8),
        "reason_for_halt": read_property(device_id, "program", program_instance, "reason-for-halt", timeout=8)
        or read_property(device_id, "program", program_instance, "100", timeout=8),
        "status_flags": read_property(device_id, "program", program_instance, "status-flags", timeout=8),
        "reliability": read_property(device_id, "program", program_instance, "reliability", timeout=8),
        "out_of_service": read_property(device_id, "program", program_instance, "out-of-service", timeout=8),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def discover_programs_on_device(device_id: str, start_index: int = 1, end_index: int | None = None) -> list[dict[str, Any]]:
    """Find Program objects by walking the device object-list indexes."""
    device_id = str(device_id).strip()
    start_index = safe_int(str(start_index), 1, minimum=1, maximum=MAX_OBJECTS)
    if end_index is None:
        end_index = DEFAULT_SCAN_LIMIT
    end_index = safe_int(str(end_index), DEFAULT_SCAN_LIMIT, minimum=1, maximum=MAX_OBJECTS)
    if end_index < start_index:
        start_index, end_index = end_index, start_index

    programs: list[dict[str, Any]] = []
    for index in range(start_index, end_index + 1):
        try:
            out = run_bacnet(["./bacrp", device_id, "device", device_id, "object-list", str(index)], timeout=6)
        except Exception:
            continue
        parsed = parse_object_identifier(out)
        if not parsed:
            continue
        obj_type, instance = parsed
        if obj_type != "program":
            continue
        programs.append({
            "index": index,
            "instance": int(instance),
            "object_name": read_property(device_id, "program", instance, "object-name", timeout=8),
            "description": read_property(device_id, "program", instance, "description", timeout=8),
            "program_state": read_property(device_id, "program", instance, "program-state", timeout=8),
            "program_change": read_property(device_id, "program", instance, "program-change", timeout=8),
            "reason_for_halt": read_property(device_id, "program", instance, "reason-for-halt", timeout=8),
        })
    return programs


def write_program_change(device_id: str, program_instance: str | int, command: str) -> dict[str, Any]:
    """Write BACnet Program Change.

    Confirmed working against KMC BAC-190063:
      bacwp DEVICE program PRG program-change 0 -1 9 VALUE

    priority 0 = no priority sent
    index -1 = no array index
    tag 9 = BACnet application tag Enumerated
    """
    device_id = str(device_id).strip()
    program_instance = str(program_instance).strip()
    command = (command or "").strip().lower()
    if command not in PROGRAM_CHANGE_COMMANDS:
        return {"ok": False, "message": f"Unsupported Program Change command: {command}"}

    value = PROGRAM_CHANGE_COMMANDS[command]["value"]
    try:
        out = run_bacnet([
            "./bacwp",
            device_id,
            "program",
            program_instance,
            "program-change",
            "0",
            "-1",
            "9",
            str(value),
        ], timeout=20)
        ack = "WriteProperty Acknowledged" in out
        snapshot = read_program_object(device_id, program_instance)
        return {
            "ok": ack,
            "ack": ack,
            "device": device_id,
            "instance": program_instance,
            "command": command,
            "command_label": PROGRAM_CHANGE_COMMANDS[command]["label"],
            "value": value,
            "message": out or "No bacwp output",
            "snapshot": snapshot,
        }
    except Exception as exc:
        return {
            "ok": False,
            "device": device_id,
            "instance": program_instance,
            "command": command,
            "value": value,
            "message": str(exc),
            "snapshot": {},
        }

# --- Routes -----------------------------------------------------------------
@app.route("/")
def index() -> str:
    return render_template("index.html", templates=load_templates(), bacnet_port=get_bacnet_port_label(), max_objects=MAX_OBJECTS, schedule_writes_enabled=ENABLE_SCHEDULE_WRITES)


@app.route("/discover")
def discover() -> str:
    """Discovery dialog plus kept-device list. Does not start a scan by itself."""
    _cleanup_job_store(DISCOVERY_JOBS, DISCOVERY_LOCK)
    return render_template(
        "discover.html",
        devices=[],
        kept_devices=load_kept_devices(),
        raw="",
        templates=load_templates(),
        filters={},
        from_results=False,
    )


@app.route("/discover/start", methods=["POST"])
def discover_start() -> str:
    _cleanup_job_store(DISCOVERY_JOBS, DISCOVERY_LOCK)
    device_filter_raw = (request.form.get("device_filter") or "").strip()
    network_filter_raw = (request.form.get("network_filter") or "").strip()
    include_kept = request.form.get("include_kept") == "1"
    all_devices = request.form.get("all_devices") == "1"
    all_networks = request.form.get("all_networks") == "1"

    device_filter = set() if all_devices else parse_filter_values(device_filter_raw)
    network_filter = set() if all_networks else parse_filter_values(network_filter_raw)

    options = {
        "device_filter": sorted(device_filter),
        "network_filter": sorted(network_filter),
        "include_kept": include_kept,
        "device_filter_raw": device_filter_raw,
        "network_filter_raw": network_filter_raw,
        "all_devices": all_devices,
        "all_networks": all_networks,
    }

    job_id = uuid4().hex
    _set_job(
        DISCOVERY_JOBS,
        DISCOVERY_LOCK,
        job_id,
        status="queued",
        done=False,
        error="",
        percent=0,
        scanned=0,
        total=0,
        current_device="",
        found_count=0,
        devices=[],
        raw="",
        options=options,
        message="Queued discovery...",
        created_at=datetime.now().isoformat(timespec="seconds"),
    )
    thread = threading.Thread(target=_discovery_worker, args=(job_id, options), daemon=True)
    thread.start()
    return render_template("discover_progress.html", job_id=job_id)


@app.route("/discover/kept/update", methods=["POST"])
def update_kept_devices() -> Response:
    current_ids = parse_filter_values(request.form.get("current_devices", ""))
    keep_ids = set(request.form.getlist("keep_device"))
    existing = {d["device"]: d for d in load_kept_devices() if d.get("device")}
    posted_rows: dict[str, dict[str, Any]] = {}

    for device_id in current_ids:
        posted_rows[device_id] = _normalize_device_record({
            "device": device_id,
            "mac": request.form.get(f"mac_{device_id}", ""),
            "snet": request.form.get(f"snet_{device_id}", ""),
            "sadr": request.form.get(f"sadr_{device_id}", ""),
            "apdu": request.form.get(f"apdu_{device_id}", ""),
            "name": request.form.get(f"name_{device_id}", ""),
            "vendor": request.form.get(f"vendor_{device_id}", ""),
            "model": request.form.get(f"model_{device_id}", ""),
            "kept": True,
            "source": "kept",
            "last_seen": datetime.now().isoformat(timespec="seconds"),
        })

    for device_id in current_ids:
        if device_id in keep_ids:
            existing[device_id] = posted_rows.get(device_id, existing.get(device_id, {"device": device_id}))
        else:
            existing.pop(device_id, None)

    save_kept_devices(list(existing.values()))
    flash("Kept device list updated.", "ok")
    return redirect(url_for("discover"))


@app.route("/discover/kept/clear", methods=["POST"])
def clear_kept_devices() -> Response:
    save_kept_devices([])
    flash("Cleared all kept devices.", "ok")
    return redirect(url_for("discover"))


@app.route("/discover/status/<job_id>", methods=["GET"])
def discover_status(job_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    job = _get_job(DISCOVERY_JOBS, DISCOVERY_LOCK, job_id)
    if not job:
        return {"ok": False, "error": "Discovery job not found or expired."}, 404
    job["ok"] = True
    return job


@app.route("/discover/results/<job_id>")
def discover_results(job_id: str) -> str | Response:
    job = _get_job(DISCOVERY_JOBS, DISCOVERY_LOCK, job_id)
    if not job:
        flash("Discovery job not found or expired.", "error")
        return redirect(url_for("index"))
    if not job.get("done"):
        return render_template("discover_progress.html", job_id=job_id)
    if job.get("error"):
        flash(job.get("error"), "error")
    devices = job.get("devices", [])
    return render_template(
        "discover.html",
        devices=devices,
        kept_devices=load_kept_devices(),
        raw=job.get("raw", ""),
        templates=load_templates(),
        filters=job.get("options", {}),
        from_results=True,
    )

@app.route("/template/build", methods=["GET"])
def build_template() -> str:
    device_id = request.args.get("device", "").strip()
    start_index = safe_int(request.args.get("start"), 1, minimum=1, maximum=MAX_OBJECTS)
    end_index = safe_int(request.args.get("end") or request.args.get("limit"), DEFAULT_SCAN_LIMIT, minimum=1, maximum=MAX_OBJECTS)
    if end_index < start_index:
        start_index, end_index = end_index, start_index
    scan_method = (request.args.get("method") or "rpm").strip().lower()
    if scan_method not in {"indexed", "rpm"}:
        scan_method = "rpm"

    if not device_id:
        flash("Device ID is required.", "error")
        return redirect(url_for("discover"))

    meta = cached_device_metadata(device_id)
    sync_scan = request.args.get("sync") == "1"
    objects = read_indexed_object_list(device_id, start_index=start_index, end_index=end_index, names_only=True) if sync_scan else []
    return render_template(
        "build_template.html",
        device_id=device_id,
        start_index=start_index,
        end_index=end_index,
        meta=meta,
        objects=objects,
        max_objects=MAX_OBJECTS,
        sync_scan=sync_scan,
        scan_method=scan_method,
        route=get_cached_bacnet_route(device_id),
        rpm_block_size=RPM_BLOCK_SIZE,
    )


@app.route("/template/scan/start", methods=["POST"])
def start_template_scan() -> dict[str, Any] | Response:
    device_id = request.form.get("device", "").strip()
    start_index = safe_int(request.form.get("start"), 1, minimum=1, maximum=MAX_OBJECTS)
    end_index = safe_int(request.form.get("end") or request.form.get("limit"), DEFAULT_SCAN_LIMIT, minimum=1, maximum=MAX_OBJECTS)
    if end_index < start_index:
        start_index, end_index = end_index, start_index
    scan_method = (request.form.get("method") or "rpm").strip().lower()
    if scan_method not in {"indexed", "rpm"}:
        scan_method = "rpm"

    if not device_id.isdigit():
        return {"ok": False, "error": "Numeric Device ID is required."}, 400
    busy_message = bacnet_runtime_busy_message()
    if busy_message:
        return {"ok": False, "error": busy_message}, 409

    _cleanup_scan_jobs()
    job_id = uuid4().hex
    _set_scan_job(
        job_id,
        status="queued",
        done=False,
        error="",
        device_id=device_id,
        start_index=start_index,
        end_index=end_index,
        total=max(0, end_index - start_index + 1),
        scan_method=scan_method,
        scanned=0,
        percent=0,
        current_index=start_index,
        current_object="",
        found_count=0,
        objects=[],
        message="Queued...",
        created_at=datetime.now().isoformat(timespec="seconds"),
    )
    thread = threading.Thread(
        target=_template_scan_worker,
        args=(job_id, device_id, start_index, end_index, scan_method),
        daemon=True,
    )
    thread.start()
    return {"ok": True, "job_id": job_id}


@app.route("/template/scan/status/<job_id>", methods=["GET"])
def template_scan_status(job_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    job = _get_scan_job(job_id)
    if not job:
        return {"ok": False, "error": "Scan job not found or expired."}, 404
    job["ok"] = True
    return job


@app.route("/template/save", methods=["POST"])
def save_template_route() -> Response:
    template_name = request.form.get("template_name", "").strip()
    vendor = request.form.get("vendor", "").strip()
    model = request.form.get("model", "").strip()
    device_name_match = request.form.get("device_name_match", "").strip()
    selected = request.form.getlist("selected_points")

    if not template_name:
        flash("Template name is required.", "error")
        return redirect(request.referrer or url_for("index"))

    points = points_from_selected_form()

    if not points:
        flash("No points selected. Template was not saved.", "error")
        return redirect(request.referrer or url_for("index"))

    template_id = save_template({
        "template_name": template_name,
        "vendor": vendor,
        "model": model,
        "device_name_match": device_name_match,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "points": points,
    })
    flash(f"Template saved: {template_name} ({len(points)} points)", "ok")
    return redirect(url_for("templates_page", selected=template_id))


@app.route("/templates")
def templates_page() -> str:
    return render_template("templates.html", templates=load_templates(), selected=request.args.get("selected"))


@app.route("/template/<template_id>.json")
def download_template(template_id: str):
    path = template_path(template_id)
    if not path.exists():
        flash("Template not found.", "error")
        return redirect(url_for("templates_page"))
    return send_file(path, as_attachment=True, download_name=path.name)


@app.route("/template/<template_id>.csv")
def download_template_csv(template_id: str):
    try:
        template = load_template(template_id)
    except Exception:
        flash("Template not found.", "error")
        return redirect(url_for("templates_page"))
    return template_to_csv_response(template, template_id)


@app.route("/template/delete/<template_id>", methods=["POST"])
def delete_template(template_id: str) -> Response:
    path = template_path(template_id)
    if path.exists():
        try:
            template = load_template(template_id)
            name = template.get("template_name") or template_id
        except Exception:
            name = template_id
        path.unlink()
        flash(f"Template deleted: {name}.", "ok")
    else:
        flash("Template not found.", "error")
    return redirect(url_for("templates_page"))


@app.route("/template/export/selected.csv", methods=["POST"])
def export_selected_template_csv():
    template_name = request.form.get("template_name", "BACnet Template").strip() or "BACnet Template"
    points = points_from_selected_form()
    if not points:
        flash("No points selected. CSV was not exported.", "error")
        return redirect(request.referrer or url_for("index"))
    return template_to_csv_response({"points": points}, template_name)


@app.route("/template/upload", methods=["POST"])
def upload_template() -> Response:
    uploaded = request.files.get("template_file")
    if not uploaded or not uploaded.filename:
        flash("Choose a .json or .csv template file to upload.", "error")
        return redirect(url_for("templates_page"))

    try:
        template = load_template_upload(uploaded)
        if not template.get("points"):
            raise ValueError("Template file did not contain any valid points.")
        template.setdefault("created_at", datetime.now().isoformat(timespec="seconds"))
        template_id = save_template(template)
    except Exception as exc:
        flash(f"Template upload failed: {exc}", "error")
        return redirect(url_for("templates_page"))

    flash(f"Template loaded: {template.get('template_name')} ({len(template.get('points', []))} points)", "ok")
    return redirect(url_for("templates_page", selected=template_id))



@app.route("/devices")
def devices_page() -> str:
    return render_template(
        "devices.html",
        devices=load_saved_devices(),
        kept_devices=load_kept_devices(),
        templates=load_templates(),
    )


def edge_trend_devices() -> list[dict[str, Any]]:
    """Return saved points with the device identity needed by the local collector."""
    devices: list[dict[str, Any]] = []
    for saved in load_saved_devices():
        try:
            device_instance = int(saved.get("device_id"))
        except (TypeError, ValueError):
            continue
        try:
            device = load_saved_device(str(saved["device_profile_id"]))
        except (FileNotFoundError, KeyError):
            continue
        device["device_instance"] = device_instance
        devices.append(device)
    return devices


def parse_edge_trend_points(values: list[str], devices: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_key: dict[str, dict[str, Any]] = {}
    for device in devices:
        profile_id = str(device["device_profile_id"])
        for point in device.get("points", []):
            key = f"{profile_id}|{point['object_type']}|{point['instance']}"
            by_key[key] = {
                "device_profile_id": profile_id,
                "device_instance": int(device["device_instance"]),
                "object_type": str(point["object_type"]),
                "object_instance": int(point["instance"]),
                "object_name": str(point.get("object_name") or ""),
            }
    selected: list[dict[str, Any]] = []
    seen: set[tuple[int, str, int]] = set()
    for value in values:
        point = by_key.get(value)
        if not point:
            continue
        identity = (point["device_instance"], point["object_type"], point["object_instance"])
        if identity not in seen:
            selected.append(point)
            seen.add(identity)
    return selected


@app.route("/edge-trends", methods=["GET", "POST"])
def edge_trends_page() -> str | Response:
    if not EDGE_TRENDS_UI_ENABLED:
        return render_template("edge_trends_disabled.html")
    store = trend_store()
    devices = edge_trend_devices()
    if request.method == "POST":
        action = (request.form.get("action") or "").strip()
        try:
            group_id = request.form.get("group_id", type=int)
            if action == "save":
                interval_sec = int(request.form.get("interval_sec") or "0")
                group_id = store.save_group(
                    group_id=group_id,
                    name=request.form.get("name") or "",
                    interval_sec=interval_sec,
                    enabled=request.form.get("enabled") == "on",
                    points=parse_edge_trend_points(request.form.getlist("point"), devices),
                )
                flash("Local trend group saved. It is independent of existing cloud trends.", "ok")
                return redirect(url_for("edge_trends_page", selected=group_id))
            if not group_id:
                raise ValueError("Trend group not found.")
            if action == "enable":
                store.set_enabled(group_id, True)
                flash("Local trend group enabled.", "ok")
            elif action == "disable":
                store.set_enabled(group_id, False)
                flash("Local trend group disabled. Existing cloud trends were not changed.", "ok")
            elif action == "delete":
                store.delete_group(group_id)
                flash("Local trend group deleted. Existing cloud trends were not changed.", "ok")
            else:
                raise ValueError("Unsupported local trend action.")
        except (TypeError, ValueError) as exc:
            flash(str(exc), "error")
        return redirect(url_for("edge_trends_page"))

    selected_id = request.args.get("selected", type=int)
    selected = store.group(selected_id) if selected_id else None
    selected_keys = {
        f"{point['device_profile_id']}|{point['object_type']}|{point['object_instance']}"
        for point in (store.points(selected_id) if selected else [])
    }
    return render_template(
        "edge_trends.html",
        devices=devices,
        groups=store.groups(),
        selected=selected,
        selected_keys=selected_keys,
        dashboard=store.dashboard(),
    )


TREND_RANGE_SECONDS = {"1h": 3600, "4h": 4 * 3600, "24h": 24 * 3600, "2d": 2 * 86400, "7d": 7 * 86400}


def trend_viewer_range(range_value: str | None, hours_value: str | None) -> tuple[str, int | None, int]:
    """Resolve the viewer time range to (range id, custom hours, window seconds)."""
    range_id = (range_value or "24h").strip().lower()
    if range_id == "custom":
        custom_hours = safe_int(hours_value, 24, minimum=1, maximum=24 * 30)
        return "custom", custom_hours, custom_hours * 3600
    range_id = range_id if range_id in TREND_RANGE_SECONDS else "24h"
    return range_id, None, TREND_RANGE_SECONDS[range_id]


def trend_viewer_range_args(range_value: str | None, hours_value: str | None) -> dict[str, Any]:
    """The query arguments that carry the current range across a redirect."""
    range_id, custom_hours, _ = trend_viewer_range(range_value, hours_value)
    args: dict[str, Any] = {"range": range_id}
    if custom_hours is not None:
        args["hours"] = custom_hours
    return args


@app.route("/edge-trends/view", methods=["GET", "POST"])
def edge_trends_viewer() -> str | Response:
    if not EDGE_TRENDS_UI_ENABLED:
        return render_template("edge_trends_disabled.html")
    store = trend_store()
    group_id = request.args.get("group", type=int)
    if request.method == "POST":
        group_id = request.form.get("group", type=int)
        # The range the engineer was looking at has to survive the save, and so
        # does the identity of the view they just wrote, or the redirect drops
        # them back onto an unselected default view.
        redirect_args = trend_viewer_range_args(
            (request.form.get("range") or "24h"),
            request.form.get("hours"),
        )
        saved_view_id = request.form.get("view_id", type=int)
        try:
            settings_json = request.form.get("settings_json") or "{}"
            json.loads(settings_json)
            # A trend group owns exactly one viewer configuration, so saving is an
            # update of that record.  There is no name to supply and nothing to
            # choose between, which is why this cannot create a second one.
            store.save_group_viewer_settings(group_id or 0, settings_json)
            flash("Graph controls saved.", "ok")
        except (ValueError, json.JSONDecodeError) as exc:
            flash(str(exc), "error")
        return redirect(url_for("edge_trends_viewer", group=group_id, **redirect_args))
    if not group_id:
        flash("Choose a local trend group to view.", "error")
        return redirect(url_for("edge_trends_page"))
    group = store.group(group_id)
    if not group:
        flash("Local trend group not found.", "error")
        return redirect(url_for("edge_trends_page"))
    range_id, custom_hours, window_seconds = trend_viewer_range(request.args.get("range"), request.args.get("hours"))
    points = store.points(group_id)
    now = datetime.now(timezone.utc)
    since = (now - timedelta(seconds=window_seconds)).isoformat(timespec="seconds")
    # Two independent budgets.  The table shows the newest raw rows; the graph
    # covers the whole window, per point, downsampled only when it must be.
    samples = store.samples(group_id, since=since, limit=RECENT_SAMPLE_ROWS)
    graph_rows = store.graph_samples(
        group_id,
        since=since,
        until=now.isoformat(timespec="seconds"),
        target_values=GRAPH_TARGET_VALUES,
    )

    def point_label(row: dict[str, Any]) -> str:
        label = f"DI{row['device_instance']} | {TYPE_LABELS.get(str(row['object_type']), str(row['object_type']).upper())}{row['object_instance']}"
        return label + (f" — {row['object_name']}" if row.get("object_name") else "")

    chart_samples: list[dict[str, Any]] = []
    for sample in graph_rows:
        numeric_value = numeric_sample_value(sample["value_text"])
        if numeric_value is None:
            continue
        chart_samples.append({
            "time": sample["sampled_at"],
            "value": numeric_value,
            "display_value": str(sample["value_text"] or "").strip(),
            "point_id": int(sample["trend_point_id"]),
            "object_type": str(sample["object_type"]),
            "label": point_label(sample),
        })
    chart_points = [
        {
            "id": int(point["id"]),
            "label": point_label(point),
            "object_type": str(point["object_type"]),
        }
        for point in points
    ]
    # The group's saved Graph Controls, migrated from the newest named view the
    # first time this group is opened after the change.
    stored_view = store.group_viewer_settings(group_id)
    selected_view_settings: dict[str, Any] = {}
    if stored_view:
        try:
            parsed_settings = json.loads(stored_view["settings_json"] or "{}")
        except (TypeError, json.JSONDecodeError):
            parsed_settings = {}
        if isinstance(parsed_settings, dict):
            selected_view_settings = parsed_settings
    return render_template(
        "edge_trend_viewer.html",
        group=group,
        points=points,
        range_id=range_id,
        custom_hours=custom_hours,
        range_options=[("1h", "1 hour"), ("4h", "4 hours"), ("24h", "24 hours"), ("2d", "2 days"), ("7d", "7 days")],
        samples=samples,
        recent_sample_limit=RECENT_SAMPLE_ROWS,
        chart_samples=chart_samples,
        chart_points=chart_points,
        selected_view_settings=selected_view_settings,
    )


@app.route("/devices/custom-table/import", methods=["POST"])
def import_device_custom_table() -> Response:
    device_profile_id = request.form.get("device_profile_id", "").strip()
    device_targets = [target.strip() for target in request.form.getlist("device_target") if target.strip()]
    device_target = request.form.get("device_target", "").strip()
    if device_target and device_target not in device_targets:
        device_targets.append(device_target)
    uploaded = request.files.get("custom_table_file")
    import_source_raw = request.form.get("import_source", "upload").strip()
    import_source = import_source_raw.lower()
    source_template_id = request.form.get("source_template_id", "").strip()
    if import_source.startswith("template:"):
        source_template_id = import_source_raw.split(":", 1)[1].strip()
        import_source = "template"
    if not device_profile_id and len(device_targets) == 1 and device_targets[0].startswith("saved:"):
        device_profile_id = device_targets[0].split(":", 1)[1].strip()
    if not device_profile_id and not device_targets:
        flash("Choose one or more discovered devices or saved Live Devices this Custom Table belongs to.", "error")
        return redirect(url_for("devices_page"))
    if import_source == "template" and not source_template_id:
        flash("Choose a saved Template to import.", "error")
        return redirect(url_for("devices_page", selected=device_profile_id))
    if import_source != "template" and (not uploaded or not uploaded.filename):
        flash("Choose a Custom Table CSV to import.", "error")
        return redirect(url_for("devices_page", selected=device_profile_id))
    upload_name = uploaded.filename if uploaded else ""
    upload_bytes = uploaded.read() if uploaded else b""
    source_template: dict[str, Any] | None = None
    if import_source == "template":
        try:
            source_template = load_template(source_template_id)
        except Exception as exc:
            flash(f"Template import failed: {exc}", "error")
            return redirect(url_for("devices_page", selected=device_profile_id))

    class UploadedCopy:
        filename = upload_name

        def read(self) -> bytes:
            return upload_bytes

    if device_profile_id:
        targets = [f"saved:{device_profile_id}"]
    else:
        targets = device_targets

    imported_summaries: list[str] = []
    last_profile_id = device_profile_id
    total_matched = 0
    total_duplicates = 0
    total_missing = 0
    try:
        for target in targets:
            created = False
            allow_new_csv_points = True
            if target.startswith("saved:"):
                current_profile_id = target.split(":", 1)[1].strip()
                saved_device = load_saved_device(current_profile_id)
                allow_new_csv_points = False
            else:
                device_id = target.split(":", 1)[1].strip() if target.startswith("kept:") else target.strip()
                kept = next((d for d in load_kept_devices() if str(d.get("device")) == device_id), {})
                if not device_id:
                    raise ValueError("Choose a discovered device before importing the Custom Table.")
                existing_saved = find_saved_device_for_device_id(device_id)
                if existing_saved:
                    current_profile_id = str(existing_saved.get("device_profile_id", "")).strip()
                    saved_device = load_saved_device(current_profile_id)
                else:
                    current_profile_id = ""
                    saved_device = {
                        "device_id": device_id,
                        "device_name": kept.get("name") or f"Device {device_id}",
                        "source_template_id": source_template_id if source_template else "",
                        "source_template_name": (source_template or {}).get("template_name") or "Custom Table CSV",
                        "meta": kept,
                        "points": [],
                    }
                    created = True
            if source_template is not None:
                custom_table = custom_table_from_template(source_template)
            else:
                custom_table = load_custom_table_upload(UploadedCopy(), saved_device, allow_new_csv_points=allow_new_csv_points)
            imported_points = custom_table.pop("_points", [])
            if created:
                saved_device["points"] = imported_points
                if source_template is not None:
                    saved_device["source_template_id"] = str(source_template.get("template_id") or source_template_id)
                    saved_device["source_template_name"] = str(source_template.get("template_name") or source_template_id)
                saved_device["custom_table"] = custom_table
                saved_device["last_rows"] = context_rows_to_live_snapshot([
                    {
                        "object_type": row.get("object_type", ""),
                        "instance": row.get("instance", ""),
                        "object_name": row.get("description", ""),
                        "present_value": collapse_duplicated_display_value(row.get("initial_value")),
                        "display_present_value": collapse_duplicated_display_value(row.get("initial_value")),
                        "raw_present_value": "",
                        "status": "CSV initial value" if row.get("initial_value") else "Not refreshed",
                        "read_source": "Custom Table CSV",
                    }
                    for column in custom_table.get("columns", [])
                    for row in column.get("rows", [])
                ])
                current_profile_id = save_saved_device(saved_device)
                saved_device = load_saved_device(current_profile_id)
            else:
                update_saved_device_from_custom_table_import(current_profile_id, custom_table, imported_points)
                saved_device = load_saved_device(current_profile_id)
            last_profile_id = current_profile_id
            total_matched += int(custom_table.get("matched_count") or 0)
            total_duplicates += int(custom_table.get("duplicate_count") or 0)
            total_missing += int(custom_table.get("missing_count") or 0)
            imported_summaries.append(str(saved_device.get("device_name") or current_profile_id))
    except Exception as exc:
        flash(f"Custom Table import failed: {exc}", "error")
        return redirect(url_for("devices_page", selected=last_profile_id or device_profile_id))
    flash(
        "Custom Table imported for "
        f"{', '.join(imported_summaries)}: "
        f"{total_matched} matched, "
        f"{total_duplicates} duplicate skipped, "
        f"{total_missing} missing.",
        "ok",
    )
    if len(imported_summaries) == 1 and last_profile_id:
        return redirect(url_for("view_saved_device", device_profile_id=last_profile_id))
    return redirect(url_for("devices_page", selected=last_profile_id or ""))


@app.route("/devices/save", methods=["POST"])
def save_device_from_view() -> Response:
    device_id = request.form.get("device_id", "").strip()
    device_name = request.form.get("device_name", "").strip()
    template_id = request.form.get("template_id", "").strip()
    rows_json = request.form.get("rows_json", "[]")
    meta_json = request.form.get("meta_json", "{}")
    if not device_id:
        flash("Device ID is required to save a device.", "error")
        return redirect(request.referrer or url_for("index"))
    if not device_name:
        flash("Enter a device name before saving.", "error")
        return redirect(request.referrer or url_for("index"))
    try:
        rows = json.loads(rows_json)
        meta = json.loads(meta_json)
    except Exception as exc:
        flash(f"Could not save device point list: {exc}", "error")
        return redirect(request.referrer or url_for("index"))
    points = context_rows_to_device_points(rows)
    if not points:
        flash("No points were available to save for this device.", "error")
        return redirect(request.referrer or url_for("index"))
    device_profile_id = save_saved_device({
        "device_id": device_id,
        "device_name": device_name,
        "source_template_id": template_id,
        "source_template_name": request.form.get("template_name", "").strip(),
        "meta": meta,
        "points": points,
        "last_rows": context_rows_to_live_snapshot(rows),
        "last_refreshed_at": datetime.now().isoformat(timespec="seconds"),
    })
    flash(f"Saved device: {device_name} ({len(points)} points).", "ok")
    return redirect(url_for("devices_page", selected=device_profile_id))


@app.route("/devices/export/<device_profile_id>.csv")
def export_saved_device_commissioning_template(device_profile_id: str) -> Response:
    """Download a saved live-device point list as a commissioning CSV."""
    saved_device = load_saved_device(device_profile_id)
    rows = [
        {
            "object_type": point.get("object_type", ""),
            "instance": point.get("instance", ""),
            "object_name": point.get("object_name", ""),
        }
        for point in saved_device.get("points", [])
    ]
    return template_to_csv_response(
        {"points": rows},
        f"{saved_device.get('device_name', device_profile_id)}-commissioning",
    )


@app.route("/devices/view/<device_profile_id>")
def view_saved_device(device_profile_id: str) -> str | Response:
    """Open a saved Live Device without rebuilding the table.

    The old behavior immediately started a full view job, which made Live Devices
    feel the same as opening a template. This route now renders the saved/static
    point list first; the browser refresh button updates live values in place.
    """
    try:
        saved_device = load_saved_device(device_profile_id)
    except FileNotFoundError as exc:
        flash(str(exc), "error")
        return redirect(url_for("devices_page"))

    rows = build_live_device_initial_rows(saved_device)
    custom_table_columns = build_custom_table_columns(saved_device, rows)
    active_timed_overrides = active_timed_overrides_for_device(str(saved_device.get("device_id", "")))
    return render_template(
        "live_device.html",
        saved_device=saved_device,
        device_id=saved_device.get("device_id", ""),
        rows=rows,
        custom_table_columns=custom_table_columns,
        active_timed_overrides=active_timed_overrides,
        default_read_method=normalize_read_method(request.args.get("read_method") or "rpm"),
        rpm_view_block_size=RPM_VIEW_BLOCK_SIZE,
        last_refreshed_at=saved_device.get("last_refreshed_at", ""),
    )


@app.route("/devices/live/<device_profile_id>/refresh", methods=["POST", "GET"])
def refresh_live_device(device_profile_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    payload = request.get_json(silent=True) if request.is_json else {}
    read_method = normalize_read_method((payload or {}).get("read_method") or request.values.get("read_method") or "rpm")
    point_filter = normalize_refresh_point_filter((payload or {}).get("points"))
    try:
        return build_live_device_refresh(device_profile_id, read_method, point_filter=point_filter or None)
    except FileNotFoundError as exc:
        return {"ok": False, "error": str(exc)}, 404
    except Exception as exc:
        return {"ok": False, "error": str(exc)}, 500


@app.route("/devices/live/<device_profile_id>/refresh/start", methods=["POST"])
def start_live_device_refresh(device_profile_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    payload = request.get_json(silent=True) if request.is_json else {}
    read_method = normalize_read_method((payload or {}).get("read_method") or "rpm")
    point_filter = normalize_refresh_point_filter((payload or {}).get("points"))
    try:
        load_saved_device(device_profile_id)
    except FileNotFoundError as exc:
        return {"ok": False, "error": str(exc)}, 404

    _cleanup_job_store(VIEW_JOBS, VIEW_LOCK)
    job_id = uuid4().hex
    _set_job(
        VIEW_JOBS,
        VIEW_LOCK,
        job_id,
        status="queued",
        done=False,
        error="",
        device_profile_id=device_profile_id,
        read_method=read_method,
        refresh_scope="selected" if point_filter else "all",
        total=len(point_filter),
        scanned=0,
        percent=0,
        current_point="",
        partial_rows=[],
        found_count=0,
        message="Queued Live Device refresh...",
        created_at=datetime.now().isoformat(timespec="seconds"),
    )
    thread = threading.Thread(
        target=_saved_device_view_worker,
        args=(job_id, device_profile_id, read_method, point_filter or None),
        daemon=True,
    )
    thread.start()
    return {"ok": True, "job_id": job_id}


@app.route("/devices/live/refresh/status/<job_id>", methods=["GET"])
def live_device_refresh_status(job_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    job = _get_job(VIEW_JOBS, VIEW_LOCK, job_id)
    if not job:
        return {"ok": False, "error": "Live Device refresh job not found or expired."}, 404
    context = job.pop("context", None)
    if context and not job.get("partial_rows"):
        job["partial_rows"] = context.get("rows", [])
    job["ok"] = True
    return job


@app.route("/devices/live/<device_profile_id>/save-values", methods=["POST"])
def save_live_device_screen_values(device_profile_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    payload = request.get_json(silent=True) if request.is_json else {}
    rows = normalize_live_rows_snapshot((payload or {}).get("rows"))
    if not rows:
        return {"ok": False, "error": "No Live Device values were provided to save."}, 400
    try:
        load_saved_device(device_profile_id)
        save_live_device_last_rows(device_profile_id, rows, merge=True)
    except FileNotFoundError as exc:
        return {"ok": False, "error": str(exc)}, 404
    except Exception as exc:
        return {"ok": False, "error": str(exc)}, 500
    return {
        "ok": True,
        "device_profile_id": device_profile_id,
        "saved_count": len(rows),
        "last_refreshed_at": datetime.now().isoformat(timespec="seconds"),
        "message": f"Saved {len(rows)} current Live Device value(s).",
    }


@app.route("/devices/live/<device_profile_id>/save-as", methods=["POST"])
def save_live_device_as_new(device_profile_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    payload = request.get_json(silent=True) if request.is_json else {}
    rows = normalize_live_rows_snapshot((payload or {}).get("rows"))
    device_name = str((payload or {}).get("device_name") or "").strip()
    if not device_name:
        return {"ok": False, "error": "New Live Device name is required."}, 400
    try:
        source = load_saved_device(device_profile_id)
    except FileNotFoundError as exc:
        return {"ok": False, "error": str(exc)}, 404
    now = datetime.now().isoformat(timespec="seconds")
    data = {
        "device_id": source.get("device_id", ""),
        "device_name": device_name,
        "source_template_id": source.get("source_template_id", ""),
        "source_template_name": source.get("source_template_name", ""),
        "meta": source.get("meta", {}),
        "points": source.get("points", []),
        "last_rows": rows or source.get("last_rows", []),
        "last_refreshed_at": now,
    }
    if source.get("custom_table"):
        data["custom_table"] = source.get("custom_table")
    new_profile_id = save_saved_device(data)
    return {
        "ok": True,
        "device_profile_id": new_profile_id,
        "device_name": device_name,
        "saved_count": len(data["last_rows"]),
        "message": f"Saved as new Live Device: {device_name}.",
        "redirect_url": url_for("view_saved_device", device_profile_id=new_profile_id),
    }


@app.route("/devices/rename/<device_profile_id>", methods=["POST"])
def rename_saved_device_route(device_profile_id: str) -> Response:
    device_name = request.form.get("device_name", "").strip()
    try:
        rename_saved_device(device_profile_id, device_name)
        flash(f"Renamed Live Device to {device_name}.", "ok")
    except Exception as exc:
        flash(f"Rename failed: {exc}", "error")
    return redirect(url_for("devices_page", selected=device_profile_id))


@app.route("/devices/delete/<device_profile_id>", methods=["POST"])
def delete_saved_device(device_profile_id: str) -> Response:
    path = saved_device_path(device_profile_id)
    if path.exists():
        path.unlink()
        flash("Saved device deleted.", "ok")
    else:
        flash("Saved device not found.", "error")
    return redirect(url_for("devices_page"))


@app.route("/view", methods=["GET"])
def view_device() -> str | Response:
    device_id = request.args.get("device", "").strip()
    template_id = request.args.get("template", "").strip()
    read_method = normalize_read_method(
        request.args.get("read_method")
        or request.args.get("method")
        or request.args.get("mode")
        or request.args.get("read")
        or "rpm"
    )
    if not device_id or not template_id:
        flash("Device ID and template are required.", "error")
        return redirect(url_for("index"))

    _cleanup_job_store(VIEW_JOBS, VIEW_LOCK)
    job_id = uuid4().hex
    _set_job(
        VIEW_JOBS,
        VIEW_LOCK,
        job_id,
        status="queued",
        done=False,
        error="",
        device_id=device_id,
        template_id=template_id,
        read_method=read_method,
        percent=0,
        scanned=0,
        total=0,
        current_point="",
        found_count=0,
        message="Queued template view read...",
        created_at=datetime.now().isoformat(timespec="seconds"),
    )
    thread = threading.Thread(target=_view_worker, args=(job_id, device_id, template_id, read_method), daemon=True)
    thread.start()
    return render_template(
        "view_progress.html",
        job_id=job_id,
        device_id=device_id,
        template_id=template_id,
        read_method=read_method,
    )


@app.route("/view/status/<job_id>", methods=["GET"])
def view_status(job_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    job = _get_job(VIEW_JOBS, VIEW_LOCK, job_id)
    if not job:
        return {"ok": False, "error": "View job not found or expired."}, 404
    # Do not ship full row/export context on every poll. The result route renders it.
    job.pop("context", None)
    job["ok"] = True
    return job


@app.route("/view/results/<job_id>")
def view_results(job_id: str) -> str | Response:
    job = _get_job(VIEW_JOBS, VIEW_LOCK, job_id)
    if not job:
        flash("Template view job not found or expired.", "error")
        return redirect(url_for("index"))
    if not job.get("done"):
        return render_template(
            "view_progress.html",
            job_id=job_id,
            device_id=job.get("device_id", ""),
            template_id=job.get("template_id", ""),
            read_method=job.get("read_method", "rpm"),
        )
    if job.get("error"):
        flash(job.get("error"), "error")
        return redirect(url_for("index"))
    context = job.get("context") or {}
    if not context:
        flash("Template view completed, but no result context was saved.", "error")
        return redirect(url_for("index"))
    return render_template("view_device.html", **context)

@app.route("/exports/<filename>")
def download_export(filename: str):
    safe = Path(filename).name
    path = EXPORT_DIR / safe
    if not path.exists():
        flash("Export not found.", "error")
        return redirect(url_for("index"))
    return send_file(path, as_attachment=True, download_name=safe)



@app.route("/captures")
def captures_page() -> str:
    return render_template(
        "captures.html",
        interfaces=get_capture_interfaces(),
        active_jobs=active_capture_jobs(),
        capture_files=list_capture_files(),
        tcpdump_available=tcpdump_available(),
        tcpdump_path=tcpdump_path(),
        default_interface=(get_configured_interface() or get_default_route_interface() or get_first_active_interface()),
    )


@app.route("/captures/start", methods=["POST"])
def captures_start() -> Response:
    interface = (request.form.get("interface") or "").strip() or (get_configured_interface() or get_default_route_interface() or get_first_active_interface())
    filter_mode = (request.form.get("filter_mode") or "both").strip()
    custom_filter = request.form.get("custom_filter") or ""
    duration = safe_int(request.form.get("duration"), 60, minimum=0, maximum=3600)

    try:
        filter_expression = capture_filter_expression(filter_mode, custom_filter)
        job = start_capture_job(interface, filter_expression, duration)
        if duration > 0:
            flash(f"Capture started: {job['filename']} for {duration} seconds.", "ok")
        else:
            flash(f"Capture started: {job['filename']} until manually stopped.", "ok")
    except Exception as exc:
        flash(f"Capture failed to start: {exc}", "error")
    return redirect(url_for("captures_page"))


@app.route("/captures/stop/<job_id>", methods=["POST"])
def captures_stop(job_id: str) -> Response:
    if stop_capture_process(job_id):
        flash("Capture stopped.", "ok")
    else:
        flash("Capture job was not found or was already stopped.", "error")
    return redirect(url_for("captures_page"))


@app.route("/captures/jobs")
def captures_jobs() -> dict[str, Any]:
    return {
        "ok": True,
        "jobs": active_capture_jobs(),
        "files": list_capture_files(),
    }


@app.route("/captures/download/<filename>")
def captures_download(filename: str):
    safe = Path(filename).name
    path = CAPTURE_DIR / safe
    if not safe.endswith(".pcap") or not path.exists():
        flash("Capture file not found.", "error")
        return redirect(url_for("captures_page"))
    return send_file(path, as_attachment=True, download_name=safe)


@app.route("/captures/delete/<filename>", methods=["POST"])
def captures_delete(filename: str) -> Response:
    safe = Path(filename).name
    path = CAPTURE_DIR / safe
    if safe.endswith(".pcap") and path.exists():
        path.unlink()
        flash("Capture deleted.", "ok")
    else:
        flash("Capture file not found.", "error")
    return redirect(url_for("captures_page"))



@app.route("/device-ping", methods=["GET", "POST"])
def device_ping_page() -> str:
    device_filter = (request.values.get("device") or "").strip()
    network_filter = (request.values.get("network") or "").strip()
    read_metadata = request.values.get("read_metadata", "yes") != "no"

    # Backward compatible: old POSTs and ?run=1 now launch the progress screen
    # instead of blocking the browser while bacwi and metadata reads run.
    if request.method == "POST" or request.args.get("run") == "1":
        return device_ping_start()

    return render_template(
        "device_ping.html",
        device_filter=device_filter,
        network_filter=network_filter,
        read_metadata=read_metadata,
        result=None,
        error="",
    )


@app.route("/device-ping/start", methods=["GET", "POST"])
def device_ping_start() -> str:
    _cleanup_job_store(DEVICE_PING_JOBS, DEVICE_PING_LOCK)
    device_filter = (request.values.get("device") or "").strip()
    network_filter = (request.values.get("network") or "").strip()
    read_metadata = request.values.get("read_metadata", "yes") != "no"

    job_id = uuid4().hex
    _set_job(
        DEVICE_PING_JOBS,
        DEVICE_PING_LOCK,
        job_id,
        status="queued",
        done=False,
        error="",
        percent=0,
        scanned=0,
        total=0,
        found_count=0,
        current_device="",
        result=None,
        rows=[],
        message="Queued ping / route check...",
        created_at=datetime.now().isoformat(timespec="seconds"),
        options={
            "device_filter": device_filter,
            "network_filter": network_filter,
            "read_metadata": read_metadata,
        },
    )
    thread = threading.Thread(
        target=_device_ping_worker,
        args=(job_id, device_filter, network_filter, read_metadata),
        daemon=True,
    )
    thread.start()
    return render_template("device_ping_progress.html", job_id=job_id)


@app.route("/device-ping/status/<job_id>", methods=["GET"])
def device_ping_status(job_id: str) -> dict[str, Any] | tuple[dict[str, Any], int]:
    job = _get_job(DEVICE_PING_JOBS, DEVICE_PING_LOCK, job_id)
    if not job:
        return {"ok": False, "error": "Ping / route check job not found or expired."}, 404
    job["ok"] = True
    # Keep polling lightweight. Full result renders from /device-ping/results.
    job.pop("result", None)
    job.pop("raw", None)
    return job


@app.route("/device-ping/results/<job_id>")
def device_ping_results(job_id: str) -> str | Response:
    job = _get_job(DEVICE_PING_JOBS, DEVICE_PING_LOCK, job_id)
    if not job:
        flash("Ping / route check job not found or expired.", "error")
        return redirect(url_for("device_ping_page"))
    if not job.get("done"):
        return render_template("device_ping_progress.html", job_id=job_id)

    result = job.get("result")
    error = job.get("error", "")
    if error:
        flash(f"Ping / route check failed: {error}", "error")

    options = job.get("options") or {}
    return render_template(
        "device_ping.html",
        device_filter=options.get("device_filter", ""),
        network_filter=options.get("network_filter", ""),
        read_metadata=bool(options.get("read_metadata", True)),
        result=result,
        error=error,
    )


@app.route("/programs", methods=["GET"])
def programs_page() -> str:
    device_id = request.args.get("device", "").strip()
    program_instance = request.args.get("program", "").strip()
    start_index = safe_int(request.args.get("start"), 1, minimum=1, maximum=MAX_OBJECTS)
    end_index = safe_int(request.args.get("end") or request.args.get("limit"), DEFAULT_SCAN_LIMIT, minimum=1, maximum=MAX_OBJECTS)
    if end_index < start_index:
        start_index, end_index = end_index, start_index

    meta: dict[str, str] = {}
    discovered: list[dict[str, Any]] = []
    selected_program: dict[str, Any] | None = None

    if device_id:
        meta = read_device_metadata(device_id)
        if program_instance:
            selected_program = read_program_object(device_id, program_instance)
        else:
            discovered = discover_programs_on_device(device_id, start_index=start_index, end_index=end_index)

    return render_template(
        "programs.html",
        device_id=device_id,
        program_instance=program_instance,
        start_index=start_index,
        end_index=end_index,
        max_objects=MAX_OBJECTS,
        meta=meta,
        discovered=discovered,
        selected_program=selected_program,
        program_commands=PROGRAM_CHANGE_COMMANDS,
    )


@app.route("/edge-programs", methods=["GET", "POST"])
def edge_programs_page() -> str | Response:
    store = program_store()
    if request.method == "POST":
        try:
            action = request.form.get("action", "save")
            program_id = int(request.form["program_id"]) if request.form.get("program_id") else None
            if action in {"run", "halt", "disable"} and program_id:
                if action == "run":
                    program = store.get(program_id)
                    if not program:
                        raise ValueError("Program not found.")
                    if program["compile_status"] != "Compiled":
                        ok, detail = store.compile(program_id)
                        if not ok:
                            raise ProgramError(detail.get("message", "Compile failed"))
                    store.set_runtime(program_id, "Running", enabled=True)
                    flash("Program is running. It reads live BACnet values on each local scan; writes occur only when its INTERVAL condition is due.", "ok")
                else:
                    store.set_runtime(program_id, "Halted", enabled=False)
                    flash("Program halted. No BACnet priorities were relinquished.", "ok")
            else:
                program_id = store.save((request.form.get("name") or "").strip(), request.form.get("description") or "", request.form.get("source_code") or "", program_id)
                if action in {"compile", "dry-run"}:
                    ok, detail = store.compile(program_id)
                    if not ok: flash(f"Compile error: {detail.get('message')}", "error")
                    elif action == "dry-run":
                        return render_template("edge_programs.html", programs=store.list(), selected=store.get(program_id), dry_result=dry_run(detail, LocalEdgeProgramBacnetAdapter()), last_execution=store.latest_execution(program_id))
            return redirect(url_for("edge_programs_page", selected=program_id))
        except (ValueError, ProgramError) as exc: flash(str(exc), "error")
    selected_id = request.args.get("selected", type=int)
    return render_template("edge_programs.html", programs=store.list(), selected=store.get(selected_id) if selected_id else None, dry_result=None, last_execution=store.latest_execution(selected_id) if selected_id else None)


@app.route("/edge-programs/<int:program_id>/status")
def edge_program_status(program_id: int) -> Response:
    """Small polling endpoint: updates status without reloading the code editor."""
    store = program_store()
    program = store.get(program_id)
    if not program:
        return jsonify({"error": "Program not found"}), 404
    execution = store.latest_execution(program_id) or {}
    def decoded(field: str, fallback: Any) -> Any:
        try:
            return json.loads(execution.get(field) or "")
        except (TypeError, ValueError, json.JSONDecodeError):
            return fallback
    writes = decoded("writes_json", [])
    return jsonify({
        "state": program["runtime_state"],
        "last_scan": program["last_executed_at"] or "Never",
        "duration_ms": execution.get("duration_ms"),
        "reads": decoded("reads_json", {}),
        "variables": decoded("variables_json", {}),
        "writes": writes,
        "suppressed_writes": sum(1 for item in writes if "WRITE SKIPPED" in str(item)),
        "error": execution.get("error_text") or program.get("last_error") or "",
    })


@app.route("/programs/control", methods=["POST"])
def programs_control() -> Response:
    device_id = request.form.get("device", "").strip()
    program_instance = request.form.get("program", "").strip()
    command = request.form.get("command", "").strip().lower()
    confirm_write = request.form.get("confirm_write") == "yes"

    if not device_id.isdigit() or not program_instance.isdigit():
        flash("Device ID and Program instance must be numeric.", "error")
        return redirect(url_for("programs_page", device=device_id, program=program_instance))
    if command not in PROGRAM_CHANGE_COMMANDS:
        flash("Unsupported Program Change command.", "error")
        return redirect(url_for("programs_page", device=device_id, program=program_instance))
    if not confirm_write:
        flash("Program command blocked. Check the confirmation box before applying BACnet Program Change writes.", "error")
        return redirect(url_for("programs_page", device=device_id, program=program_instance))

    result = write_program_change(device_id, program_instance, command)
    label = PROGRAM_CHANGE_COMMANDS[command]["label"]
    category = "ok" if result.get("ok") else "error"
    snapshot = result.get("snapshot") or {}
    state = snapshot.get("program_state", "")
    change = snapshot.get("program_change", "")
    reason = snapshot.get("reason_for_halt", "")
    flash(
        f"Program {label} {'OK' if result.get('ok') else 'FAILED'}: {result.get('message', '')} | State: {state} | Change: {change} | Halt Reason: {reason}",
        category,
    )
    return redirect(url_for("programs_page", device=device_id, program=program_instance))


@app.route("/schedules", methods=["GET"])
def schedules_page() -> str:
    device_id = request.args.get("device", "").strip()
    schedule_instance = request.args.get("schedule", "").strip()
    start_index = safe_int(request.args.get("start"), 1, minimum=1, maximum=MAX_OBJECTS)
    end_index = safe_int(request.args.get("end") or request.args.get("limit"), DEFAULT_SCAN_LIMIT, minimum=1, maximum=MAX_OBJECTS)
    if end_index < start_index:
        start_index, end_index = end_index, start_index

    discovered: list[dict[str, Any]] = []
    selected_schedule: dict[str, Any] | None = None
    meta: dict[str, str] = {}

    if device_id:
        meta = read_device_metadata(device_id)
        if schedule_instance:
            selected_schedule = read_schedule(device_id, schedule_instance)
        else:
            discovered = discover_schedules_on_device(device_id, start_index=start_index, end_index=end_index)

    return render_template(
        "schedules.html",
        device_id=device_id,
        schedule_instance=schedule_instance,
        start_index=start_index,
        end_index=end_index,
        max_objects=MAX_OBJECTS,
        meta=meta,
        discovered=discovered,
        selected_schedule=selected_schedule,
        days=DAYS_OF_WEEK,
        schedule_writes_enabled=ENABLE_SCHEDULE_WRITES,
        schedule_write_helper=SCHEDULE_WRITE_HELPER,
    )


@app.route("/schedules/apply", methods=["POST"])
def schedules_apply() -> Response:
    devices = split_device_ids(request.form.get("devices", ""))
    schedule_instance = (request.form.get("schedule_instance") or "").strip()
    mode = (request.form.get("mode") or "stage").strip()

    if not devices or not schedule_instance.isdigit():
        flash("Device ID(s) and numeric schedule instance are required.", "error")
        return redirect(request.referrer or url_for("schedules_page"))

    weekly_rows = parse_schedule_form(request.form)
    value_type = request.form.get("value_type", "enumerated")
    off_value = request.form.get("off_value", "0").strip() or "0"
    on_value = request.form.get("on_value", "1").strip() or "1"
    weekly_value = weekly_schedule_string(weekly_rows, value_type=value_type, on_value=on_value, off_value=off_value)

    payload = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "devices": devices,
        "schedule_instance": int(schedule_instance),
        "value_type": value_type,
        "off_value": off_value,
        "on_value": on_value,
        "weekly_schedule": weekly_rows,
        "bacnet_stack_weekly_schedule_value": weekly_value,
    }
    plan_path = save_schedule_plan(payload)

    if mode == "apply":
        if request.form.get("confirm_write") != "yes":
            flash(f"Schedule plan saved: {plan_path.name}. Check the confirmation box before applying writes.", "error")
        elif SCHEDULE_WRITE_HELPER:
            result = apply_schedule_plan_with_helper(plan_path)
            flash(f"Schedule plan saved: {plan_path.name}. {result['message']}", "ok" if result.get("applied") else "error")
        else:
            results = [write_weekly_schedule(device, schedule_instance, weekly_value) for device in devices]
            ok_count = sum(1 for r in results if r.get("ok"))
            result_path = SCHEDULE_DIR / f"schedule-apply-results-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
            result_path.write_text(json.dumps({"plan": payload, "results": results}, indent=2))
            details = "; ".join([f"Device {r['device']}: {'OK' if r.get('ok') else 'FAILED'}" for r in results])
            flash(f"Schedule plan saved: {plan_path.name}. Applied {ok_count}/{len(results)}. {details}", "ok" if ok_count == len(results) else "error")
    else:
        flash(f"Schedule plan staged only: {plan_path.name}", "ok")

    return redirect(url_for("schedules_page", device=devices[0], schedule=schedule_instance))


@app.route("/schedules/plans/<filename>")
def download_schedule_plan(filename: str):
    safe = Path(filename).name
    path = SCHEDULE_DIR / safe
    if not path.exists():
        flash("Schedule plan not found.", "error")
        return redirect(url_for("schedules_page"))
    return send_file(path, as_attachment=True, download_name=safe)


@app.route("/write-pv", methods=["GET"])
def write_pv_page() -> str:
    device_id = request.args.get("device", "").strip()
    obj_type = normalize_pv_write_type(request.args.get("object_type", request.args.get("type", "analog-value")))
    instance = request.args.get("instance", "").strip()
    priority = safe_int(request.args.get("priority"), 16, minimum=0, maximum=16)
    snapshot: dict[str, str] = {}
    meta: dict[str, str] = {}
    if device_id:
        meta = read_device_metadata(device_id)
    if device_id and instance:
        snapshot = read_priority_snapshot(device_id, obj_type, instance)
    return render_template(
        "write_pv.html",
        device_id=device_id,
        obj_type=obj_type,
        instance=instance,
        priority=priority,
        tag=default_pv_tag(obj_type),
        pv_write_types=PV_WRITE_TYPES,
        priorities=list(range(1, 17)),
        snapshot=snapshot,
        meta=meta,
        bacnet_port=get_bacnet_port_label(),
    )


@app.route("/write-pv/state-text", methods=["GET"])
def write_pv_state_text() -> Response:
    device_id = request.args.get("device", "").strip()
    obj_type = normalize_pv_write_type(request.args.get("object_type", request.args.get("type", "multi-state-value")))
    instance = request.args.get("instance", "").strip()
    if not device_id.isdigit() or not instance.isdigit():
        return jsonify({"ok": False, "error": "Device ID and object instance must be numeric.", "states": []}), 400
    if obj_type not in MULTI_STATE_TYPES:
        return jsonify({"ok": False, "error": "State_Text is only available on multi-state objects.", "states": []}), 400
    result = read_state_text_options(device_id, obj_type, instance)
    states = list(result.get("states") or [])
    return jsonify({
        "ok": bool(states),
        "states": states,
        "state_count": len(states),
        "status": result.get("status") or "",
        "error": result.get("error") or "",
        "property": result.get("property") or "",
        "length": result.get("length") or len(states),
    }), (200 if states else 404)


@app.route("/write-pv/snapshot", methods=["GET"])
def write_pv_snapshot() -> Response:
    device_id = request.args.get("device", "").strip()
    obj_type = normalize_pv_write_type(request.args.get("object_type", request.args.get("type", "analog-value")))
    instance = request.args.get("instance", "").strip()
    if not device_id.isdigit() or not instance.isdigit():
        return jsonify({"ok": False, "error": "Device ID and object instance must be numeric."}), 400
    if obj_type not in PV_WRITE_TYPES:
        return jsonify({"ok": False, "error": "Only commandable Present Value object types are enabled."}), 400
    try:
        native_binding = _native_bip_write_binding(device_id)
        snapshot = (
            read_priority_snapshot_native_bip(native_binding, obj_type, instance)
            if native_binding
            else read_priority_snapshot(device_id, obj_type, instance)
        )
        priority_array = str(snapshot.get("priority_array") or "")
        return jsonify({
            "ok": True,
            "snapshot": snapshot,
            "priority_table": priority_array_table(priority_array),
            "snapshot_source": "live-bacnet",
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc), "snapshot_source": "live-bacnet"}), 500


@app.route("/write-pv/apply", methods=["POST"])
def write_pv_apply() -> Response:
    device_id = request.form.get("device", "").strip()
    obj_type = normalize_pv_write_type(request.form.get("object_type", "analog-value"))
    instance = request.form.get("instance", "").strip()
    priority = safe_int(request.form.get("priority"), 0, minimum=0, maximum=16)
    tag = (request.form.get("tag") or default_pv_tag(obj_type)).strip()
    value = (request.form.get("value") or "").strip()
    action = (request.form.get("action") or "write").strip()
    confirm_write = request.form.get("confirm_write") == "yes"
    if action in {"write", "relinquish"} and priority == 0:
        priority = 16

    if not device_id.isdigit() or not instance.isdigit():
        flash("Device ID and object instance must be numeric.", "error")
        return redirect(request.referrer or url_for("write_pv_page"))
    if obj_type not in PV_WRITE_TYPES:
        flash("Only AO, AV, BO, BV, MSO, and MSV present-value writes are enabled on this page.", "error")
        return redirect(request.referrer or url_for("write_pv_page"))
    return_url = (request.form.get("return_url") or "").strip()
    if return_url and not return_url.startswith("/"):
        return_url = ""

    if not confirm_write:
        flash("Write blocked. Check the confirmation box before applying BACnet writes.", "error")
        return redirect(return_url or url_for("write_pv_page", device=device_id, object_type=obj_type, instance=instance, priority=priority))

    if action == "timed_override":
        try:
            created = create_timed_override(
                device_id=device_id,
                obj_type=obj_type,
                instance=instance,
                priority=priority,
                tag=tag,
                value=value,
                duration_amount=safe_int(request.form.get("duration_amount"), 0, minimum=0, maximum=3650),
                duration_unit=(request.form.get("duration_unit") or "minutes").strip(),
                description=(request.form.get("description") or "").strip(),
                display_value=value,
                source_page=return_url or request.referrer or "write-pv",
                created_by=timed_override_user(),
            )
            result = created.get("write_result") or {}
            result["timed_override"] = created.get("override") or {}
            result["ok"] = True
            action_label = "Timed Override"
        except Exception as exc:
            result = {"ok": False, "message": str(exc), "snapshot": {}}
            action_label = "Timed Override"
    elif action == "write_default":
        result = write_relinquish_default(device_id, obj_type, instance, tag, value)
        action_label = "Relinquish Default Write"
    else:
        relinquish = action == "relinquish"
        result = write_present_value(device_id, obj_type, instance, priority, tag, value, relinquish=relinquish)
        action_label = "Relinquish" if relinquish else f"Priority {priority} PV Write"

    category = "ok" if result.get("ok") else "error"
    message = f"{action_label} {'OK' if result.get('ok') else 'FAILED'}: {result.get('message', '')}"

    wants_json = (
        request.headers.get("X-Requested-With") == "XMLHttpRequest"
        or "application/json" in (request.headers.get("Accept") or "")
        or request.form.get("ajax") == "1"
    )
    if wants_json:
        return jsonify({
            "ok": bool(result.get("ok")),
            "category": category,
            "message": message,
            "action_label": action_label,
            "result": result,
            "snapshot": result.get("snapshot") or {},
            "device": str(device_id),
            "object_type": obj_type,
            "instance": str(instance),
            "priority": priority,
            "property": result.get("property", "present-value"),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }), (200 if result.get("ok") else 400)

    flash(message, category)
    return redirect(return_url or url_for("write_pv_page", device=device_id, object_type=obj_type, instance=instance, priority=priority))


@app.route("/write-pv/relinquish-priorities", methods=["POST"])
def write_pv_relinquish_priorities() -> Response:
    payload = request.get_json(silent=True) if request.is_json else {}
    device_id = str((payload or {}).get("device") or "").strip()
    obj_type = normalize_pv_write_type(str((payload or {}).get("object_type") or "analog-value"))
    instance = str((payload or {}).get("instance") or "").strip()
    priorities_raw = (payload or {}).get("priorities")

    if not device_id.isdigit() or not instance.isdigit():
        return jsonify({"ok": False, "message": "Device ID and object instance must be numeric."}), 400
    if obj_type not in PV_WRITE_TYPES:
        return jsonify({"ok": False, "message": "Only commandable Present Value object types are enabled."}), 400
    if not isinstance(priorities_raw, list):
        return jsonify({"ok": False, "message": "Select at least one priority to relinquish."}), 400

    priorities: list[int] = []
    for item in priorities_raw:
        try:
            priority = int(item)
        except Exception:
            continue
        if 1 <= priority <= 16 and priority not in priorities:
            priorities.append(priority)
    if not priorities:
        return jsonify({"ok": False, "message": "Select at least one priority from 1 to 16."}), 400

    results: list[dict[str, Any]] = []
    for priority in priorities:
        result = write_present_value(device_id, obj_type, instance, priority, "0", "", relinquish=True)
        results.append({
            "priority": priority,
            "ok": bool(result.get("ok")),
            "message": str(result.get("message") or ""),
            "snapshot": result.get("snapshot") or {},
        })

    ok_count = sum(1 for result in results if result["ok"])
    latest_snapshot = next((result["snapshot"] for result in reversed(results) if result.get("snapshot")), {})
    return jsonify({
        "ok": ok_count == len(results),
        "partial": 0 < ok_count < len(results),
        "successful_count": ok_count,
        "failed_count": len(results) - ok_count,
        "results": results,
        "snapshot": latest_snapshot,
        "priority_table": priority_array_table(str(latest_snapshot.get("priority_array") or "")),
        "message": f"Relinquished {ok_count} of {len(results)} selected priorit{'y' if len(results) == 1 else 'ies'}.",
    }), (200 if ok_count else 400)


@app.route("/timed-overrides")
def timed_overrides_page() -> str:
    filters = timed_override_filters_from_request()
    rows = timed_override_store().query(filters)
    all_actionable_rows = timed_override_store().query({"statuses": list(ACTIONABLE_STATUSES)})
    custom_filter = timed_override_custom_filter_submitted()
    return render_template(
        "timed_overrides.html",
        overrides=rows,
        filters=filters,
        dashboard_summary=timed_override_dashboard_summary(rows),
        relinquish_all_summary=timed_override_actionable_summary(all_actionable_rows),
        custom_filter=custom_filter,
        active_statuses=ACTIVE_STATUSES,
        actionable_statuses=ACTIONABLE_STATUSES,
        now_utc=utc_now_iso(),
        short_id=short_timed_override_id,
        local_time=timed_override_local_time,
    )


@app.route("/timed-overrides/export.csv")
def timed_overrides_export_csv() -> Response:
    filters = timed_override_filters_from_request()
    rows = timed_override_store().query(filters)
    output = io.StringIO()
    timed_override_store().export_csv(rows, output)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=timed-overrides-{stamp}.csv"},
    )


@app.route("/timed-overrides/<override_id>")
def timed_override_detail(override_id: str) -> Response:
    payload, status = timed_override_detail_payload(override_id, refresh_live=bool(request.args.get("refresh_live")))
    if not payload:
        return jsonify({"ok": False, "error": "Timed override not found."}), 404
    if wants_explicit_json_response():
        return jsonify(payload), status
    row = payload["override"]
    return render_template(
        "timed_override_detail.html",
        override=row,
        route_snapshot=payload["route_snapshot"],
        current_route=payload["current_route"],
        audit=payload["audit"],
        live_status=payload["live_status"],
        live_error=payload["live_error"],
        identity_items=timed_override_detail_items(row, [
            ("id", "Override ID"),
            ("gateway_id", "Gateway ID"),
            ("gateway_ip", "Gateway IP"),
            ("device_id", "Device instance"),
            ("object_type", "Object type"),
            ("object_instance", "Object instance"),
            ("description", "Description"),
            ("property_identifier", "Property"),
            ("priority", "Priority"),
            ("created_by", "Created by"),
            ("source_page", "Source page / workflow"),
        ]),
        value_items=timed_override_detail_items(row, [
            ("requested_value", "Requested value"),
            ("requested_value_normalized", "Requested normalized"),
            ("confirmed_value", "Confirmed written value"),
            ("confirmed_value_normalized", "Confirmed normalized"),
            ("display_value", "Display value"),
            ("bacnet_tag", "BACnet datatype/tag"),
        ]),
        timing_items=timed_override_detail_items(row, [
            ("created_at", "Created at"),
            ("expires_at", "Expires at"),
            ("completed_at", "Completed at"),
            ("updated_at", "Updated at"),
            ("last_attempt_at", "Last attempt at"),
            ("next_attempt_at", "Next retry at"),
        ]),
        status_items=timed_override_detail_items(row, [
            ("status", "Current status"),
            ("attempt_count", "Attempt count"),
            ("last_error", "Last error"),
            ("completion_reason", "Completion reason"),
            ("locked_by", "Locked / claimed by"),
            ("locked_until", "Locked until"),
        ]),
        local_time=timed_override_local_time,
        remaining_label=timed_override_remaining_label,
        short_id=short_timed_override_id,
        actionable_statuses=ACTIONABLE_STATUSES,
        now_utc=utc_now_iso(),
    )


@app.route("/timed-overrides/create", methods=["POST"])
def timed_override_create_route() -> Response:
    payload = request.get_json(silent=True) if request.is_json else request.form
    try:
        result = create_timed_override(
            device_id=str(payload.get("device") or payload.get("device_id") or "").strip(),
            obj_type=str(payload.get("object_type") or "analog-value").strip(),
            instance=str(payload.get("instance") or payload.get("object_instance") or "").strip(),
            priority=int(payload.get("priority") or 16),
            tag=str(payload.get("tag") or "").strip(),
            value=str(payload.get("value") or "").strip(),
            duration_amount=int(payload.get("duration_amount") or 0),
            duration_unit=str(payload.get("duration_unit") or "minutes").strip(),
            description=str(payload.get("description") or "").strip(),
            display_value=str(payload.get("display_value") or "").strip(),
            source_page=str(payload.get("source_page") or request.referrer or "").strip(),
            created_by=timed_override_user(),
        )
        status = 200
    except SafeModeBlocked as exc:
        result = {"ok": False, "error": str(exc)}
        status = 403
    except Exception as exc:
        result = {"ok": False, "error": str(exc)}
        status = 400
    wants_json = request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest" or "application/json" in (request.headers.get("Accept") or "")
    if wants_json:
        return jsonify(result), status
    flash(result.get("error") or "Timed override created.", "ok" if result.get("ok") else "error")
    return redirect(timed_override_action_return_url())


@app.route("/timed-overrides/<override_id>/action", methods=["POST"])
def timed_override_action(override_id: str) -> Response:
    payload = request.get_json(silent=True) if request.is_json else request.form
    action = str(payload.get("action") or "").strip()
    operator = timed_override_user()
    try:
        if action == "cancel_timer":
            if str(payload.get("confirm") or "").strip().lower() not in {"yes", "cancel timer"}:
                raise ValueError("Cancel timer confirmation is required.")
            row = timed_override_store().cancel_timer_only(override_id, operator=operator)
            result = {"ok": True, "status": "canceled", "override": row}
        elif action == "cancel_relinquish":
            result = bulk_process_timed_overrides([override_id], "relinquish", operator=operator)
            result["ok"] = True
        elif action == "extend":
            amount = int(payload.get("duration_amount") or 0)
            unit = str(payload.get("duration_unit") or "minutes").strip().lower()
            if amount <= 0 or unit not in {"minutes", "hours", "days"}:
                raise ValueError("Valid extension duration is required.")
            delta = {"minutes": timedelta(minutes=amount), "hours": timedelta(hours=amount), "days": timedelta(days=amount)}[unit]
            expires_at = (datetime.now(timezone.utc) + delta).replace(microsecond=0).isoformat()
            row = timed_override_store().extend(override_id, expires_at, operator=operator)
            result = {"ok": True, "status": "active", "override": row}
        else:
            raise ValueError("Unknown timed override action.")
        status = 200
    except Exception as exc:
        result = {"ok": False, "error": str(exc)}
        status = 400
    if wants_explicit_json_response():
        return jsonify(result), status
    message = result.get("error") or result.get("message") or "Timed override action completed."
    if action == "extend" and result.get("override"):
        message = f"Timed override extended to {result['override'].get('expires_at') or 'new expiration'}."
    elif action == "cancel_timer" and result.get("ok"):
        message = "Timed override timer canceled. BACnet command remains in place."
    elif action == "cancel_relinquish" and result.get("ok"):
        message = timed_override_bulk_summary(result)
    flash(message, "ok" if result.get("ok") else "error")
    return redirect(timed_override_detail_return_url(override_id))


@app.route("/timed-overrides/bulk-action", methods=["POST"])
def timed_override_bulk_action() -> Response:
    payload = request.get_json(silent=True) if request.is_json else request.form
    action = str(payload.get("action") or "").strip()
    operator = timed_override_user()
    if hasattr(payload, "getlist"):
        ids_raw: Any = payload.getlist("override_ids")
        if len(ids_raw) == 1:
            ids_raw = ids_raw[0]
    else:
        ids_raw = payload.get("override_ids") or []
    if isinstance(ids_raw, str):
        override_ids = [item for item in re.split(r"[\s,;]+", ids_raw) if item]
    else:
        override_ids = [str(item) for item in ids_raw if str(item).strip()]

    if action == "relinquish_all":
        if str(payload.get("confirm") or "").strip().lower() not in {"yes", "confirmed"}:
            result = {"ok": False, "error": "Relinquish all confirmation is required."}
            status = 400
        else:
            rows = timed_override_store().query({"statuses": list(ACTIONABLE_STATUSES)})
            result = bulk_process_timed_overrides([str(row["id"]) for row in rows], "relinquish", operator=operator)
            result["ok"] = True
            status = 200
    elif action in {"relinquish_selected", "cancel_selected"}:
        if not override_ids:
            result = {"ok": False, "error": "Select at least one timed override."}
            status = 400
        elif str(payload.get("confirm") or "").strip().lower() not in {"yes", "confirmed"}:
            result = {"ok": False, "error": "Bulk action confirmation is required."}
            status = 400
        else:
            result = bulk_process_timed_overrides(override_ids, "cancel_timer" if action == "cancel_selected" else "relinquish", operator=operator)
            result["ok"] = True
            status = 200
    else:
        result = {"ok": False, "error": "Unknown bulk action."}
        status = 400
    if wants_explicit_json_response():
        return jsonify(result), status
    flash(result.get("error") or timed_override_bulk_summary(result), "ok" if result.get("ok") else "error")
    return redirect(timed_override_action_return_url())


def _internal_write_value(object_type: str, value: object) -> str:
    raw = str(value if value is not None else "").strip()
    if not raw:
        raise ValueError("value is required")
    if object_type in {"analog-output", "analog-value"}:
        try:
            numeric = float(raw)
        except ValueError as exc:
            raise ValueError("analog values must be finite numbers") from exc
        if not math.isfinite(numeric):
            raise ValueError("analog values must be finite numbers")
        return raw
    if object_type in {"binary-output", "binary-value"}:
        normalized = {
            "0": "0", "inactive": "0", "off": "0", "false": "0",
            "1": "1", "active": "1", "on": "1", "true": "1",
        }.get(raw.lower())
        if normalized is None:
            raise ValueError("binary values must be active/inactive or 1/0")
        return normalized
    try:
        state = int(raw)
    except ValueError as exc:
        raise ValueError("multi-state values must be positive state numbers") from exc
    if state < 1:
        raise ValueError("multi-state values must be positive state numbers")
    return str(state)


def _internal_active_priority(snapshot: dict[str, Any]) -> int | None:
    raw = str(snapshot.get("active_priority") or "").strip()
    if raw.isdigit() and 1 <= int(raw) <= 16:
        return int(raw)
    return None


@app.route("/api/internal/edge-agent/bacnet/write-batch", methods=["POST"])
def internal_edge_agent_write_batch() -> tuple[Response, int] | Response:
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"ok": False, "error": "JSON object body is required."}), 400
    device_instance = payload.get("device_instance")
    writes = payload.get("writes")
    if isinstance(device_instance, bool) or not isinstance(device_instance, int) or device_instance < 0:
        return jsonify({"ok": False, "error": "device_instance must be a non-negative integer."}), 422
    if not isinstance(writes, list) or not writes or len(writes) > 100:
        return jsonify({"ok": False, "error": "writes must contain between 1 and 100 commands."}), 422

    validated: list[dict[str, Any]] = []
    for index, write in enumerate(writes):
        if not isinstance(write, dict):
            return jsonify({"ok": False, "error": f"writes[{index}] must be an object."}), 422
        object_type = write.get("object_type")
        object_instance = write.get("object_instance")
        action = str(write.get("action") or "write").strip().lower()
        priority = write.get("priority", 16)
        if not isinstance(object_type, str) or object_type not in PV_WRITE_TYPES:
            return jsonify({"ok": False, "error": f"writes[{index}].object_type is not commandable."}), 422
        if isinstance(object_instance, bool) or not isinstance(object_instance, int) or object_instance < 0:
            return jsonify({"ok": False, "error": f"writes[{index}].object_instance must be a non-negative integer."}), 422
        if action not in {"write", "relinquish", "relinquish-default"}:
            return jsonify({"ok": False, "error": f"writes[{index}].action is invalid."}), 422
        if isinstance(priority, bool) or not isinstance(priority, int) or not 1 <= priority <= 16:
            return jsonify({"ok": False, "error": f"writes[{index}].priority must be an integer from 1 to 16."}), 422
        try:
            value = None if action == "relinquish" else _internal_write_value(object_type, write.get("value"))
        except ValueError as exc:
            return jsonify({"ok": False, "error": f"writes[{index}]: {exc}"}), 422
        validated.append({
            "saved_point_id": str(write.get("saved_point_id") or ""),
            "object_type": object_type,
            "object_instance": object_instance,
            "action": action,
            "priority": priority,
            "value": value,
        })

    results: list[dict[str, Any]] = []
    for write in validated:
        tag = default_pv_tag(write["object_type"])
        if write["action"] == "relinquish-default":
            result = write_relinquish_default(str(device_instance), write["object_type"], write["object_instance"], tag, write["value"])
        else:
            result = write_present_value(
                str(device_instance),
                write["object_type"],
                write["object_instance"],
                write["priority"],
                tag,
                write["value"] or "",
                relinquish=write["action"] == "relinquish",
            )
        snapshot = result.get("snapshot") if isinstance(result.get("snapshot"), dict) else {}
        results.append({
            "saved_point_id": write["saved_point_id"],
            "object_type": write["object_type"],
            "object_instance": write["object_instance"],
            "action": write["action"],
            "property": result.get("property", "present-value"),
            "priority": result.get("priority", 0 if write["action"] == "relinquish-default" else write["priority"]),
            "ok": bool(result.get("ok")),
            "message": str(result.get("message") or ""),
            "present_value": snapshot.get("raw_present_value"),
            "active_priority": _internal_active_priority(snapshot),
            "priority_array": snapshot.get("priority_array"),
            "relinquish_default": snapshot.get("relinquish_default"),
            "state_text": snapshot.get("state_text"),
        })

    successful_count = sum(1 for result in results if result["ok"])
    return jsonify({
        "job_type": "bacnet_write_batch",
        "job_id": str(payload.get("job_id") or ""),
        "device_instance": device_instance,
        "status": "ok" if successful_count == len(results) else ("partial" if successful_count else "error"),
        "successful_count": successful_count,
        "failed_count": len(results) - successful_count,
        "results": results,
    })


@app.route("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "bacnet_port": get_bacnet_port_label(), "bacnet_mode": get_bacnet_mode(), "bacnet_bin": BACNET_BIN}


EDGE_ROUTER_HELPER = os.environ.get("EDGE_ROUTER_HELPER", "/usr/local/sbin/iot-cx-edge-router-control").strip() or "/usr/local/sbin/iot-cx-edge-router-control"
EDGE_ROUTER_CONFIRM_ACTIONS = {"apply", "restart", "stop", "restore_last_good"}


def _router_command_result(command: str, payload: dict[str, Any] | None = None, timeout: int = 90) -> tuple[bool, dict[str, Any], str]:
    args = ["sudo", "-n", EDGE_ROUTER_HELPER, command]
    try:
        result = subprocess.run(
            args,
            input=(json.dumps(payload) if payload is not None else None),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False, {}, f"Router helper command timed out while running {command}."
    except OSError as exc:
        return False, {}, f"Router helper command could not be started: {exc}"
    except Exception as exc:
        return False, {}, f"Router helper command failed before returning a result: {exc}"
    stdout = (result.stdout or "").strip()
    stderr = (result.stderr or "").strip()
    parsed: dict[str, Any] = {}
    if stdout:
        try:
            loaded = json.loads(stdout)
            if isinstance(loaded, dict):
                parsed = loaded
        except Exception:
            parsed = {"message": stdout}
    if result.returncode != 0 and not stderr and parsed.get("message"):
        stderr = str(parsed["message"])
    return result.returncode == 0, parsed, stderr


def _router_linux_interfaces() -> list[dict[str, str]]:
    if in_safe_mode():
        return []
    rows: list[dict[str, str]] = []
    seen: set[str] = set()
    try:
        result = subprocess.run(
            ["ip", "-4", "-o", "addr", "show", "up"],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
    except Exception:
        return rows
    for line in (result.stdout or "").splitlines():
        match = re.search(
            r"^\d+:\s+(?P<iface>[^ ]+)\s+inet\s+(?P<cidr>\d+\.\d+\.\d+\.\d+/\d+)(?:\s+brd\s+(?P<brd>\d+\.\d+\.\d+\.\d+))?",
            line,
        )
        if not match:
            continue
        iface = match.group("iface")
        if iface == "lo" or iface in seen:
            continue
        seen.add(iface)
        cidr = match.group("cidr")
        try:
            network = ipaddress.ip_interface(cidr)
            broadcast = str(network.network.broadcast_address)
            address = str(network.ip)
        except ValueError:
            broadcast = match.group("brd") or ""
            address = cidr.split("/", 1)[0]
        rows.append(
            {
                "name": iface,
                "address": address,
                "broadcast": broadcast,
                "label": f"{iface} — {address}" if address else iface,
            }
        )
    return rows


def _router_form_state(config_override: dict[str, Any] | None = None, helper_payload: dict[str, Any] | None = None) -> dict[str, Any]:
    helper_payload = helper_payload or {}
    config = routercfg.normalize_router_config(
        config_override
        or helper_payload.get("config")
        or routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS)
    )
    serial_candidates = routercfg.serial_candidates_with_assignments(config)
    runtime = routercfg.runtime_snapshot_from_helper(helper_payload.get("runtime") or helper_payload)
    recent_errors = list(runtime.get("recent_errors") or [])
    for trunk in config.get("mstp_trunks") or []:
        serial_device = str(trunk.get("serial_device") or "")
        if (
            trunk.get("enabled")
            and int(trunk.get("network_number") or 0) == 202
            and "FT8NOQWB" in serial_device
            and int(trunk.get("baud_rate") or 0) != 38400
        ):
            recent_errors.append(
                "GW006 MS/TP network 202 is expected at 38400 baud; the current router draft is set to "
                f"{trunk.get('baud_rate')}."
            )
    runtime["recent_errors"] = recent_errors
    runtime["health_display"] = _router_service_health_display(str(runtime.get("health") or ""))
    runtime["legacy_service_display"] = _legacy_router_service_display(str(runtime.get("legacy_service_status") or ""))
    mstp_status = helper_payload.get("mstp_status") or routercfg.load_mstp_status(DATA_DIR)
    return {
        "config": config,
        "runtime": runtime,
        "mstp_status": mstp_status,
        "mstp_grid": routercfg.mstp_status_grid(config, mstp_status),
        "serial_candidates": serial_candidates,
        "linux_interfaces": _router_linux_interfaces(),
        "status_aging_seconds": int(config.get("status_aging_seconds") or routercfg.DEFAULT_STATUS_AGE_SECONDS),
        "legacy_summary": helper_payload.get("legacy_summary") or {},
    }


def _router_live_state(config_override: dict[str, Any] | None = None) -> dict[str, Any]:
    if in_safe_mode():
        if config_override is None:
            return safe_router_state()
        state = _router_form_state(config_override=config_override, helper_payload=safe_router_state())
        state["edge_bacnet_router_enabled"] = bool(state["config"].get("enabled"))
        state["saved_standard_bacnet_route"] = "inactive"
        state["edge_bacnet_router_configuration"] = _router_header_summary(state["config"])
        return state
    ok, payload, error = _router_command_result("status", timeout=20)
    state = _router_form_state(config_override=config_override, helper_payload=payload)
    if not ok:
        state["runtime"]["recent_errors"] = [error or "Router helper status is unavailable."] + list(
            state["runtime"].get("recent_errors") or []
        )
        state["runtime"]["health"] = "degraded"
    state["runtime"]["health_display"] = _router_service_health_display(str(state["runtime"].get("health") or ""))
    state["runtime"]["legacy_service_display"] = _legacy_router_service_display(
        str(state["runtime"].get("legacy_service_status") or "")
    )
    state["edge_bacnet_router_enabled"] = bool(state["config"].get("enabled"))
    state["saved_standard_bacnet_route"] = payload.get("saved_standard_bacnet_route") or (
        "preserved" if state["runtime"].get("legacy_service_status") not in {"", "unknown"} else "unknown"
    )
    state["edge_bacnet_router_configuration"] = _router_header_summary(state["config"])
    return state


def _next_bip_interface(config: dict[str, Any]) -> dict[str, Any]:
    next_index = len(config.get("bip_interfaces") or []) + 1
    item = routercfg._default_bip_interface(next_index)
    used_networks = {int(entry.get("network_number") or 0) for entry in config.get("bip_interfaces") or []}
    while int(item["network_number"]) in used_networks:
        item["network_number"] = int(item["network_number"]) + 1
    used_ports = {int(entry.get("udp_port") or 0) for entry in config.get("bip_interfaces") or []}
    while int(item["udp_port"]) in used_ports:
        item["udp_port"] = int(item["udp_port"]) + 1
    return item


def _next_mstp_trunk(config: dict[str, Any]) -> dict[str, Any]:
    next_index = len(config.get("mstp_trunks") or []) + 1
    item = routercfg._default_mstp_trunk(next_index)
    used_networks = {int(entry.get("network_number") or 0) for entry in config.get("mstp_trunks") or []}
    while int(item["network_number"]) in used_networks:
        item["network_number"] = int(item["network_number"]) + 1
    return item


@app.route("/edge-bacnet-router/export.json", methods=["GET"])
def edge_bacnet_router_export() -> Response:
    config = routercfg.normalize_router_config(routercfg.load_router_config(DATA_DIR, startup_ports=BACNET_STARTUP_PORTS))
    payload = json.dumps(config, indent=2, sort_keys=True) + "\n"
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return Response(
        payload,
        mimetype="application/json",
        headers={"Content-Disposition": f"attachment; filename=edge-bacnet-router-gw006-{stamp}.json"},
    )


@app.route("/edge-bacnet-router", methods=["GET", "POST"])
def edge_bacnet_router_page() -> Response | str:
    if request.method == "POST":
        action_raw = (request.form.get("action") or "").strip()
        action, _, target_id = action_raw.partition(":")
        config: dict[str, Any] | None = None
        if action == "import_config":
            upload = request.files.get("router_config_json")
            if not upload or not upload.filename:
                flash("Choose a router configuration JSON file to import.", "error")
                return redirect(url_for("edge_bacnet_router_page"))
            try:
                raw = upload.read()
                imported = json.loads(raw.decode("utf-8"))
                if not isinstance(imported, dict):
                    raise ValueError("Router configuration JSON must contain an object.")
                config = routercfg.normalize_router_config(imported)
                routercfg.validate_router_config(
                    config,
                    serial_candidates=None if in_safe_mode() else routercfg.discover_serial_candidates(),
                )
                routercfg.save_router_config(DATA_DIR, config)
            except Exception as exc:
                flash(f"Router configuration import failed: {exc}", "error")
                state = _router_live_state()
                return render_template(
                    "edge_bacnet_router.html",
                    router_state=state,
                    valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                    valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
                )
            flash("Router configuration JSON imported as a local draft. Apply to Runtime when ready.", "ok")
            return redirect(url_for("edge_bacnet_router_page"))
        if action != "restore_last_good":
            form_data = request.form.to_dict(flat=True)
            form_data["__data_dir__"] = str(DATA_DIR)
            try:
                config = routercfg.build_router_form_config(form_data, BACNET_STARTUP_PORTS)
            except Exception as exc:
                flash(f"Router form could not be parsed: {exc}", "error")
                state = _router_live_state()
                return render_template(
                    "edge_bacnet_router.html",
                    router_state=state,
                    valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                    valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
                )
        if action in {"enable", "disable"} and config is not None:
            config["enabled"] = action == "enable"
            action = "apply"

        if action == "add_bip" and config is not None:
            config["bip_interfaces"].append(_next_bip_interface(config))
            state = _router_live_state(config_override=config)
            return render_template(
                "edge_bacnet_router.html",
                router_state=state,
                valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
            )
        if action == "remove_bip" and config is not None:
            config["bip_interfaces"] = [item for item in config.get("bip_interfaces") or [] if item.get("id") != target_id]
            if not config["bip_interfaces"]:
                config["bip_interfaces"] = [routercfg._default_bip_interface()]
            state = _router_live_state(config_override=config)
            return render_template(
                "edge_bacnet_router.html",
                router_state=state,
                valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
            )
        if action == "add_mstp" and config is not None:
            config["mstp_trunks"].append(_next_mstp_trunk(config))
            state = _router_live_state(config_override=config)
            return render_template(
                "edge_bacnet_router.html",
                router_state=state,
                valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
            )
        if action == "remove_mstp" and config is not None:
            config["mstp_trunks"] = [item for item in config.get("mstp_trunks") or [] if item.get("id") != target_id]
            if not config["mstp_trunks"]:
                config["mstp_trunks"] = [routercfg._default_mstp_trunk()]
            state = _router_live_state(config_override=config)
            return render_template(
                "edge_bacnet_router.html",
                router_state=state,
                valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
            )
        if action in EDGE_ROUTER_CONFIRM_ACTIONS and request.form.get("confirm_router") != "yes":
            flash("Confirm the Edge BACnet Router change before applying it.", "error")
            state = _router_live_state(config_override=config)
            return render_template(
                "edge_bacnet_router.html",
                router_state=state,
                valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
            )
        if action in EDGE_ROUTER_CONFIRM_ACTIONS and in_safe_mode():
            flash("Edge BACnet Router changes are disabled while EDGE_UI_SAFE_MODE=1.", "error")
            state = _router_live_state(config_override=config)
            return render_template(
                "edge_bacnet_router.html",
                router_state=state,
                valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
            )
        if action in {"validate_draft", "save_draft", "apply"} and config is not None:
            try:
                routercfg.validate_router_config(
                    config,
                    serial_candidates=None if in_safe_mode() else routercfg.discover_serial_candidates(),
                )
            except Exception as exc:
                flash(str(exc), "error")
                state = _router_live_state(config_override=config)
                return render_template(
                    "edge_bacnet_router.html",
                    router_state=state,
                    valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                    valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
                )

        if action == "validate_draft" and config is not None:
            flash("Router draft validation passed.", "ok")
            state = _router_live_state(config_override=config)
            return render_template(
                "edge_bacnet_router.html",
                router_state=state,
                valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
            )
        if action == "save_draft" and config is not None:
            try:
                routercfg.save_router_config(DATA_DIR, config)
            except Exception as exc:
                flash(f"Router draft could not be saved: {exc}", "error")
                state = _router_live_state(config_override=config)
                return render_template(
                    "edge_bacnet_router.html",
                    router_state=state,
                    valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                    valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
                )
            flash("Router draft saved locally.", "ok")
            return redirect(url_for("edge_bacnet_router_page"))
        if action == "apply" and config is not None:
            ok, payload, error = _router_command_result("apply", {"config": config}, timeout=180)
            if ok:
                try:
                    routercfg.save_router_config(DATA_DIR, config)
                except Exception as exc:
                    flash(f"Router applied, but the UI could not save the local draft: {exc}", "error")
                    state = _router_live_state(config_override=config)
                    return render_template(
                        "edge_bacnet_router.html",
                        router_state=state,
                        valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                        valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
                    )
                flash(payload.get("message") or "Router configuration applied.", "ok")
                return redirect(url_for("edge_bacnet_router_page"))
            flash(error or payload.get("message") or "Router apply failed.", "error")
            state = _router_live_state(config_override=config)
            return render_template(
                "edge_bacnet_router.html",
                router_state=state,
                valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
                valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
            )
        if action == "restart":
            ok, payload, error = _router_command_result("restart", timeout=120)
            flash(payload.get("message") or "Router restarted." if ok else (error or "Router restart failed."), "ok" if ok else "error")
            return redirect(url_for("edge_bacnet_router_page"))
        if action == "stop":
            ok, payload, error = _router_command_result("stop", timeout=120)
            flash(payload.get("message") or "Router stopped." if ok else (error or "Router stop failed."), "ok" if ok else "error")
            return redirect(url_for("edge_bacnet_router_page"))
        if action == "restore_last_good":
            ok, payload, error = _router_command_result("restore-last-good", timeout=180)
            flash(
                payload.get("message") or "Restored last-known-good router configuration." if ok else (error or "Router restore failed."),
                "ok" if ok else "error",
            )
            return redirect(url_for("edge_bacnet_router_page"))
        flash("Invalid Edge BACnet Router action.", "error")
        return redirect(url_for("edge_bacnet_router_page"))

    state = _router_live_state()
    return render_template(
        "edge_bacnet_router.html",
        router_state=state,
        valid_bip_modes=sorted(routercfg.VALID_BIP_MODES),
        valid_baud_rates=sorted(routercfg.VALID_BAUD_RATES),
    )


def create_app(*, testing: bool = False) -> Flask:
    app.config["TESTING"] = testing
    return app


if __name__ == "__main__":
    create_app()
    if not in_safe_mode():
        ensure_runtime_initialized()
        assert EDGE_PROGRAM_SCHEDULER is not None
        assert TIMED_OVERRIDE_SCHEDULER is not None
        EDGE_PROGRAM_SCHEDULER.start()
        TIMED_OVERRIDE_SCHEDULER.start()
    app.run(host=EDGE_UI_HOST, port=EDGE_UI_PORT, debug=False, use_reloader=False)
