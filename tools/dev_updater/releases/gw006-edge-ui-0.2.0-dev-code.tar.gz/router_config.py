from __future__ import annotations

import json
import os
import ipaddress
import re
import shutil
import subprocess
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4


ROUTER_CONFIG_VERSION = 2
ROUTER_CONFIG_FILE = "router-config.json"
ROUTER_CONFIG_BACKUP_DIR = "router-config-backups"
ROUTER_LAST_GOOD_FILE = "router-config.last-good.json"
ROUTER_MSTP_STATUS_FILE = "router-mstp-status.json"
ROUTER_RUNTIME_FILE = "router-runtime.json"
LEGACY_EDGE_ROUTER_FILE = "edge_bacnet_router.json"
LEGACY_MODE_FILE = "bacnet_runtime_mode.txt"

VALID_BIP_MODES = {"normal", "bbmd", "foreign"}
VALID_BAUD_RATES = {9600, 19200, 38400, 57600, 76800, 115200}
DEFAULT_STATUS_AGE_SECONDS = 180


class RouterConfigError(ValueError):
    pass


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def router_paths(data_dir: Path) -> dict[str, Path]:
    return {
        "config": data_dir / ROUTER_CONFIG_FILE,
        "last_good": data_dir / ROUTER_LAST_GOOD_FILE,
        "backup_dir": data_dir / ROUTER_CONFIG_BACKUP_DIR,
        "mstp_status": data_dir / ROUTER_MSTP_STATUS_FILE,
        "runtime": data_dir / ROUTER_RUNTIME_FILE,
        "legacy_state": data_dir / LEGACY_EDGE_ROUTER_FILE,
        "legacy_mode": data_dir / LEGACY_MODE_FILE,
    }


def _default_bip_interface(index: int = 1) -> dict[str, Any]:
    return {
        "id": f"bip-{index}",
        "enabled": True,
        "display_name": f"BACnet/IP Interface {index}",
        "network_number": index,
        "linux_interface": "",
        "bind_address": "",
        "udp_port": 47808 if index == 1 else 47808 + (index - 1),
        "mode": "normal",
        "receive_global_broadcast": True,
        "accept_unmatched_destination_ip": False,
        "nat_enabled": False,
        "advertised_ip": "",
        "advertised_port": 47808 if index == 1 else 47808 + (index - 1),
        "cross_network_broadcast": False,
        "capture_buffer_kb": 512,
        "bbmd_bdt_entries": [],
        "bbmd_accept_foreign_registrations": False,
        "foreign_device": {
            "remote_bbmd_ip": "",
            "remote_bbmd_port": 47808,
            "registration_ttl": 600,
            "registration_interval": 300,
        },
    }


def _default_mstp_trunk(index: int = 1) -> dict[str, Any]:
    return {
        "id": f"mstp-{index}",
        "enabled": True,
        "display_name": f"MS/TP Trunk {index}",
        "network_number": 200 + index,
        "serial_device": "",
        "resolved_device": "",
        "baud_rate": 38400,
        "local_mac": 2,
        "max_master": 127,
        "max_info_frames": 1,
        "usage_timeout_ms": 30,
        "reply_timeout_ms": 260,
        "retry_count": 3,
        "capture_buffer_kb": 512,
    }


def default_router_config() -> dict[str, Any]:
    return {
        "version": ROUTER_CONFIG_VERSION,
        "enabled": False,
        "config_revision": now_utc(),
        "updated_at": now_utc(),
        "last_apply": {},
        "status_aging_seconds": DEFAULT_STATUS_AGE_SECONDS,
        "bip_interfaces": [_default_bip_interface()],
        "mstp_trunks": [_default_mstp_trunk()],
    }


def _legacy_mode_ports(mode: str, startup_ports: list[str]) -> list[int]:
    mapping = {
        "bac-rtr": [47809],
        "basrtb": [47814],
        "dual-47809-first": [47809, 47814],
        "dual-47814-first": [47814, 47809],
        "edge-router-fdr": [47814, 47809],
    }
    ports = mapping.get((mode or "").strip(), [])
    if ports:
        return ports
    cleaned = []
    for port in startup_ports:
        if str(port).isdigit():
            cleaned.append(int(port))
    return cleaned or [47814]


def migrate_legacy_router_state(data_dir: Path, startup_ports: list[str]) -> dict[str, Any]:
    config = default_router_config()
    paths = router_paths(data_dir)
    legacy_enabled = False
    saved_mode = "dual-47814-first"
    legacy_state: dict[str, Any] = {}

    try:
        legacy_state = json.loads(paths["legacy_state"].read_text(encoding="utf-8"))
        legacy_enabled = bool(legacy_state.get("edge_bacnet_router_enabled"))
    except Exception:
        legacy_state = {}
    try:
        saved_mode = paths["legacy_mode"].read_text(encoding="utf-8").strip() or saved_mode
    except Exception:
        pass

    ports = _legacy_mode_ports(saved_mode, startup_ports)
    config["enabled"] = legacy_enabled
    config["bip_interfaces"] = []
    for index, port in enumerate(ports, start=1):
        bip = _default_bip_interface(index)
        bip["udp_port"] = port
        bip["enabled"] = True
        bip["display_name"] = "GW006 Primary B/IP" if index == 1 else f"GW006 B/IP {index}"
        bip["network_number"] = 1 if index == 1 else index
        bip["mode"] = "normal"
        config["bip_interfaces"].append(bip)
    config["mstp_trunks"] = [_default_mstp_trunk(1)]
    trunk = config["mstp_trunks"][0]
    router_cfg = legacy_state.get("edge_bacnet_router_configuration") or {}
    trunk["display_name"] = "GW006 USB ISO-485"
    trunk["network_number"] = int(router_cfg.get("mstp_network") or 202)
    trunk["serial_device"] = str(router_cfg.get("serial_device") or "")
    return config


def load_router_config(data_dir: Path, startup_ports: list[str] | None = None) -> dict[str, Any]:
    startup_ports = startup_ports or ["47814"]
    paths = router_paths(data_dir)
    path = paths["config"]
    if path.exists():
        raw = json.loads(path.read_text(encoding="utf-8"))
    else:
        raw = migrate_legacy_router_state(data_dir, startup_ports)
    config = normalize_router_config(raw)
    validate_router_config(config)
    return config


def normalize_router_config(raw: dict[str, Any]) -> dict[str, Any]:
    default = default_router_config()
    config = deepcopy(default)
    if not isinstance(raw, dict):
        return config
    for key in ["version", "enabled", "config_revision", "updated_at", "last_apply", "status_aging_seconds"]:
        if key in raw:
            config[key] = raw[key]
    config["bip_interfaces"] = []
    for index, item in enumerate(raw.get("bip_interfaces") or [], start=1):
        merged = _default_bip_interface(index)
        if isinstance(item, dict):
            merged.update(item)
            if isinstance(item.get("foreign_device"), dict):
                merged["foreign_device"].update(item["foreign_device"])
        for key in ["network_number", "udp_port", "advertised_port", "capture_buffer_kb"]:
            try:
                merged[key] = int(merged[key])
            except Exception:
                pass
        for key in ["remote_bbmd_port", "registration_ttl", "registration_interval"]:
            try:
                merged["foreign_device"][key] = int(merged["foreign_device"][key])
            except Exception:
                pass
        config["bip_interfaces"].append(merged)
    if not config["bip_interfaces"]:
        config["bip_interfaces"] = [_default_bip_interface()]
    config["mstp_trunks"] = []
    for index, item in enumerate(raw.get("mstp_trunks") or [], start=1):
        merged = _default_mstp_trunk(index)
        if isinstance(item, dict):
            merged.update(item)
        for key in [
            "network_number",
            "baud_rate",
            "local_mac",
            "max_master",
            "max_info_frames",
            "usage_timeout_ms",
            "reply_timeout_ms",
            "retry_count",
            "capture_buffer_kb",
        ]:
            try:
                merged[key] = int(merged[key])
            except Exception:
                pass
        config["mstp_trunks"].append(merged)
    if not config["mstp_trunks"]:
        config["mstp_trunks"] = [_default_mstp_trunk()]
    return config


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".{uuid4().hex}.tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(path)


def save_router_config(data_dir: Path, config: dict[str, Any], *, update_revision: bool = True) -> None:
    validate_router_config(config)
    paths = router_paths(data_dir)
    payload = deepcopy(config)
    payload["version"] = ROUTER_CONFIG_VERSION
    payload["updated_at"] = now_utc()
    if update_revision:
        payload["config_revision"] = payload["updated_at"]
    _atomic_write_json(paths["config"], payload)
    paths["backup_dir"].mkdir(parents=True, exist_ok=True)
    backup = paths["backup_dir"] / f"router-config-{payload['updated_at'].replace(':', '').replace('+00:00', 'Z')}.json"
    backup.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def save_last_known_good(data_dir: Path, config: dict[str, Any]) -> None:
    validate_router_config(config)
    _atomic_write_json(router_paths(data_dir)["last_good"], config)


def restore_last_known_good(data_dir: Path) -> dict[str, Any]:
    path = router_paths(data_dir)["last_good"]
    if not path.exists():
        raise RouterConfigError("No last-known-good router configuration is available.")
    config = normalize_router_config(json.loads(path.read_text(encoding="utf-8")))
    validate_router_config(config)
    save_router_config(data_dir, config)
    return config


def _require_int(name: str, value: Any, minimum: int, maximum: int) -> int:
    try:
        parsed = int(value)
    except Exception as exc:
        raise RouterConfigError(f"{name} must be an integer.") from exc
    if not minimum <= parsed <= maximum:
        raise RouterConfigError(f"{name} must be between {minimum} and {maximum}.")
    return parsed


def _validate_bdt_entries(entries: list[dict[str, Any]], *, prefix: str) -> None:
    seen: set[tuple[str, str, int]] = set()
    for index, entry in enumerate(entries, start=1):
        if not isinstance(entry, dict):
            raise RouterConfigError(f"{prefix} BDT entry {index} is invalid.")
        host = str(entry.get("host") or "").strip()
        mask = str(entry.get("mask") or "").strip()
        port = _require_int(f"{prefix} BDT port", entry.get("port", 47808), 1, 65535)
        if not host:
            raise RouterConfigError(f"{prefix} BDT entry {index} host is required.")
        key = (host, mask, port)
        if key in seen:
            raise RouterConfigError(f"{prefix} BDT entry {index} duplicates another BDT entry.")
        seen.add(key)


def validate_router_config(config: dict[str, Any], serial_candidates: list[dict[str, Any]] | None = None) -> None:
    if not isinstance(config, dict):
        raise RouterConfigError("Router configuration payload is invalid.")
    bip_interfaces = config.get("bip_interfaces") or []
    mstp_trunks = config.get("mstp_trunks") or []
    if not isinstance(bip_interfaces, list) or not bip_interfaces:
        raise RouterConfigError("At least one BACnet/IP interface definition is required.")
    if not isinstance(mstp_trunks, list):
        raise RouterConfigError("MS/TP trunk definitions are invalid.")

    active_networks: dict[int, str] = {}
    active_udp: set[tuple[str, int]] = set()
    active_serial: set[str] = set()
    serial_ids = {
        str(item.get("stable_path") or item.get("resolved_path") or "") for item in (serial_candidates or []) if isinstance(item, dict)
    }
    router_globally_enabled = bool(config.get("enabled"))

    for index, bip in enumerate(bip_interfaces, start=1):
        if not isinstance(bip, dict):
            raise RouterConfigError(f"BACnet/IP interface {index} is invalid.")
        name = str(bip.get("display_name") or f"BACnet/IP Interface {index}").strip()
        network = _require_int(f"{name} network number", bip.get("network_number", index), 1, 65534)
        port = _require_int(f"{name} UDP port", bip.get("udp_port", 47808), 1, 65535)
        linux_interface = str(bip.get("linux_interface") or "").strip()
        bind_address = str(bip.get("bind_address") or "").strip()
        mode = str(bip.get("mode") or "normal").strip().lower()
        if mode not in VALID_BIP_MODES:
            raise RouterConfigError(f"{name} mode must be one of: {', '.join(sorted(VALID_BIP_MODES))}.")
        if router_globally_enabled and bip.get("enabled", True):
            if not linux_interface:
                raise RouterConfigError(f"{name} Linux interface is required.")
            if not bind_address:
                raise RouterConfigError(f"{name} bind address is required.")
            if network in active_networks:
                raise RouterConfigError(
                    f"Duplicate active BACnet network number {network} on {name} and {active_networks[network]}."
                )
            active_networks[network] = name
            udp_key = (linux_interface, port)
            if udp_key in active_udp:
                raise RouterConfigError(f"Duplicate active UDP bind {linux_interface}:{port}.")
            active_udp.add(udp_key)
            if bip.get("nat_enabled"):
                advertised_ip = str(bip.get("advertised_ip") or "").strip()
                if not advertised_ip:
                    raise RouterConfigError(f"{name} Advertised / NAT IP is required when NAT is enabled.")
                try:
                    ipaddress.ip_address(advertised_ip)
                except ValueError:
                    raise RouterConfigError(f"{name} Advertised / NAT IP is invalid.")
                _require_int(f"{name} Advertised / NAT UDP port", bip.get("advertised_port", port), 1, 65535)
        if mode == "bbmd":
            _validate_bdt_entries(bip.get("bbmd_bdt_entries") or [], prefix=name)
        if mode == "foreign":
            foreign = bip.get("foreign_device") or {}
            if not str(foreign.get("remote_bbmd_ip") or "").strip():
                raise RouterConfigError(f"{name} foreign-device remote BBMD IP is required.")
            _require_int(f"{name} foreign-device BBMD port", foreign.get("remote_bbmd_port", 47808), 1, 65535)
            _require_int(f"{name} foreign-device TTL", foreign.get("registration_ttl", 600), 30, 65535)
            _require_int(f"{name} foreign-device interval", foreign.get("registration_interval", 300), 30, 65535)

    for index, trunk in enumerate(mstp_trunks, start=1):
        if not isinstance(trunk, dict):
            raise RouterConfigError(f"MS/TP trunk {index} is invalid.")
        name = str(trunk.get("display_name") or f"MS/TP Trunk {index}").strip()
        network = _require_int(f"{name} network number", trunk.get("network_number", 200 + index), 1, 65534)
        serial_device = str(trunk.get("serial_device") or "").strip()
        baud_rate = _require_int(f"{name} baud rate", trunk.get("baud_rate", 38400), 0, 115200)
        local_mac = _require_int(f"{name} local MAC", trunk.get("local_mac", 2), 0, 127)
        max_master = _require_int(f"{name} Max Master", trunk.get("max_master", 127), 1, 127)
        _require_int(f"{name} Max Info Frames", trunk.get("max_info_frames", 1), 1, 255)
        _require_int(f"{name} Usage timeout", trunk.get("usage_timeout_ms", 30), 1, 5000)
        _require_int(f"{name} Reply timeout", trunk.get("reply_timeout_ms", 260), 1, 10000)
        _require_int(f"{name} Retry count", trunk.get("retry_count", 3), 0, 20)
        if baud_rate not in VALID_BAUD_RATES:
            raise RouterConfigError(f"{name} baud rate {baud_rate} is not one of the supported values.")
        if router_globally_enabled and trunk.get("enabled", True):
            if not serial_device:
                raise RouterConfigError(f"{name} serial device is required.")
            if network in active_networks:
                raise RouterConfigError(
                    f"Duplicate active BACnet network number {network} on {name} and {active_networks[network]}."
                )
            active_networks[network] = name
            if serial_device in active_serial:
                raise RouterConfigError(f"{name} reuses serial device {serial_device} on another active trunk.")
            active_serial.add(serial_device)
            if serial_ids and serial_device not in serial_ids:
                # stable configured path is preferred; tolerate absent hardware only if candidate list is empty
                raise RouterConfigError(f"{name} serial device {serial_device} is not currently present.")
        if local_mac > max_master:
            raise RouterConfigError(f"{name} local MAC must not be greater than Max Master.")


def edge_router_enabled(config: dict[str, Any]) -> bool:
    return bool(config.get("enabled"))


def active_bip_ports(config: dict[str, Any]) -> list[str]:
    ports: list[str] = []
    for bip in config.get("bip_interfaces") or []:
        if bip.get("enabled"):
            port = str(bip.get("udp_port") or "").strip()
            if port and port not in ports:
                ports.append(port)
    return ports or ["47814"]


def _render_bdt_entries(entries: list[dict[str, Any]]) -> list[str]:
    lines: list[str] = []
    for entry in entries:
        host = str(entry.get("host") or "").strip()
        mask = str(entry.get("mask") or "").strip()
        port = int(entry.get("port", 47808))
        if host:
            lines.append(f"// BDT {host}/{mask}:{port}")
    return lines


def render_bacnet_router_init_cfg(config: dict[str, Any]) -> str:
    validate_router_config(config)
    blocks: list[str] = []
    for bip in config.get("bip_interfaces") or []:
        if not bip.get("enabled"):
            continue
        lines = [
            '    {',
            '        device_type = "bip";',
            f'        device = "{bip["linux_interface"]}";',
            f'        network = {int(bip["network_number"])};',
            f'        port = {int(bip["udp_port"])};',
            '    }',
        ]
        blocks.append("\n".join(lines))
    for trunk in config.get("mstp_trunks") or []:
        if not trunk.get("enabled"):
            continue
        # Keep the stable /dev/serial/by-id path in the saved UI config, but
        # render the resolved tty path for the C router app. The router copies
        # the configured device into a fixed-size buffer and aborts on the long
        # by-id symlink used by GW006.
        serial_device = trunk.get("resolved_device") or trunk["serial_device"]
        lines = [
            '    {',
            '        device_type = "mstp";',
            f'        device = "{serial_device}";',
            f'        mac = {int(trunk["local_mac"])};',
            f'        max_master = {int(trunk["max_master"])};',
            f'        max_frames = {int(trunk["max_info_frames"])};',
            f'        baud = {int(trunk["baud_rate"])};',
            '        parity = "None";',
            '        databits = 8;',
            '        stopbits = 1;',
            f'        network = {int(trunk["network_number"])};',
            '    }',
        ]
        blocks.append("\n".join(lines))
    return "ports =\n(\n" + ",\n\n".join(blocks) + "\n);\n"


def discover_serial_candidates() -> list[dict[str, Any]]:
    by_id_dir = Path("/dev/serial/by-id")
    candidates: list[dict[str, Any]] = []
    if by_id_dir.exists():
        for path in sorted(by_id_dir.iterdir()):
            try:
                resolved = path.resolve()
            except Exception:
                resolved = path
            metadata = {
                "stable_path": str(path),
                "resolved_path": str(resolved),
                "present": path.exists(),
                "vendor": "",
                "product": "",
                "serial_number": "",
                "assigned": False,
            }
            try:
                output = subprocess.run(
                    ["udevadm", "info", "-q", "property", "-n", str(resolved)],
                    capture_output=True,
                    text=True,
                    timeout=2,
                    check=False,
                )
                for line in (output.stdout or "").splitlines():
                    if line.startswith("ID_VENDOR_FROM_DATABASE="):
                        metadata["vendor"] = line.split("=", 1)[1]
                    elif line.startswith("ID_MODEL_FROM_DATABASE="):
                        metadata["product"] = line.split("=", 1)[1]
                    elif line.startswith("ID_SERIAL_SHORT="):
                        metadata["serial_number"] = line.split("=", 1)[1]
            except Exception:
                pass
            candidates.append(metadata)
    return candidates


def serial_candidates_with_assignments(config: dict[str, Any]) -> list[dict[str, Any]]:
    assigned = {str(trunk.get("serial_device") or "") for trunk in config.get("mstp_trunks") or [] if trunk.get("enabled")}
    candidates = discover_serial_candidates()
    for candidate in candidates:
        candidate["assigned"] = candidate["stable_path"] in assigned
    return candidates


def build_router_form_config(form: Any, startup_ports: list[str]) -> dict[str, Any]:
    existing = load_router_config(Path(form["__data_dir__"]), startup_ports=startup_ports)
    config = deepcopy(existing)
    config["enabled"] = form.get("router_enabled") == "yes"
    try:
        config["status_aging_seconds"] = int(form.get("status_aging_seconds") or DEFAULT_STATUS_AGE_SECONDS)
    except Exception:
        config["status_aging_seconds"] = DEFAULT_STATUS_AGE_SECONDS

    bip_count = int(form.get("bip_count") or 0)
    bip_interfaces: list[dict[str, Any]] = []
    for index in range(bip_count):
        prefix = f"bip_{index}_"
        bip = _default_bip_interface(index + 1)
        bip["id"] = form.get(prefix + "id") or bip["id"]
        bip["enabled"] = form.get(prefix + "enabled") == "on"
        bip["display_name"] = (form.get(prefix + "display_name") or bip["display_name"]).strip()
        bip["network_number"] = form.get(prefix + "network_number") or bip["network_number"]
        bip["linux_interface"] = (form.get(prefix + "linux_interface") or "").strip()
        bip["bind_address"] = (form.get(prefix + "bind_address") or "").strip()
        bip["udp_port"] = form.get(prefix + "udp_port") or bip["udp_port"]
        bip["mode"] = (form.get(prefix + "mode") or "normal").strip().lower()
        bip["receive_global_broadcast"] = form.get(prefix + "receive_global_broadcast") == "on"
        bip["accept_unmatched_destination_ip"] = form.get(prefix + "accept_unmatched_destination_ip") == "on"
        bip["nat_enabled"] = form.get(prefix + "nat_enabled") == "on"
        bip["advertised_ip"] = (form.get(prefix + "advertised_ip") or "").strip()
        bip["advertised_port"] = form.get(prefix + "advertised_port") or bip["udp_port"]
        bip["cross_network_broadcast"] = form.get(prefix + "cross_network_broadcast") == "on"
        bip["capture_buffer_kb"] = form.get(prefix + "capture_buffer_kb") or 512
        bdt_entries: list[dict[str, Any]] = []
        for raw in (form.get(prefix + "bbmd_bdt_entries") or "").splitlines():
            raw = raw.strip()
            if not raw:
                continue
            match = re.match(r"^(?P<host>[^/:\s]+)(?:/(?P<mask>[^:\s]+))?(?::(?P<port>\d+))?$", raw)
            if match:
                bdt_entries.append(
                    {
                        "host": match.group("host"),
                        "mask": match.group("mask") or "255.255.255.255",
                        "port": int(match.group("port") or bip["udp_port"]),
                    }
                )
        bip["bbmd_bdt_entries"] = bdt_entries
        bip["bbmd_accept_foreign_registrations"] = form.get(prefix + "bbmd_accept_foreign_registrations") == "on"
        bip["foreign_device"] = {
            "remote_bbmd_ip": (form.get(prefix + "fd_remote_bbmd_ip") or "").strip(),
            "remote_bbmd_port": form.get(prefix + "fd_remote_bbmd_port") or 47808,
            "registration_ttl": form.get(prefix + "fd_registration_ttl") or 600,
            "registration_interval": form.get(prefix + "fd_registration_interval") or 300,
        }
        bip_interfaces.append(bip)
    config["bip_interfaces"] = bip_interfaces or [_default_bip_interface()]

    mstp_count = int(form.get("mstp_count") or 0)
    mstp_trunks: list[dict[str, Any]] = []
    for index in range(mstp_count):
        prefix = f"mstp_{index}_"
        trunk = _default_mstp_trunk(index + 1)
        trunk["id"] = form.get(prefix + "id") or trunk["id"]
        trunk["enabled"] = form.get(prefix + "enabled") == "on"
        trunk["display_name"] = (form.get(prefix + "display_name") or trunk["display_name"]).strip()
        trunk["network_number"] = form.get(prefix + "network_number") or trunk["network_number"]
        trunk["serial_device"] = (form.get(prefix + "serial_device") or "").strip()
        trunk["resolved_device"] = (form.get(prefix + "resolved_device") or "").strip()
        trunk["baud_rate"] = form.get(prefix + "baud_rate") or trunk["baud_rate"]
        trunk["local_mac"] = form.get(prefix + "local_mac") or trunk["local_mac"]
        trunk["max_master"] = form.get(prefix + "max_master") or trunk["max_master"]
        trunk["max_info_frames"] = form.get(prefix + "max_info_frames") or trunk["max_info_frames"]
        trunk["usage_timeout_ms"] = form.get(prefix + "usage_timeout_ms") or trunk["usage_timeout_ms"]
        trunk["reply_timeout_ms"] = form.get(prefix + "reply_timeout_ms") or trunk["reply_timeout_ms"]
        trunk["retry_count"] = form.get(prefix + "retry_count") or trunk["retry_count"]
        trunk["capture_buffer_kb"] = form.get(prefix + "capture_buffer_kb") or trunk["capture_buffer_kb"]
        mstp_trunks.append(trunk)
    config["mstp_trunks"] = mstp_trunks or [_default_mstp_trunk()]
    return normalize_router_config(config)


def runtime_snapshot_from_helper(raw: dict[str, Any] | None) -> dict[str, Any]:
    runtime = {
        "service_name": "iot-cx-bacnet-router.service",
        "service_status": "not-available",
        "legacy_service_status": "unknown",
        "health": "unknown",
        "pid": "",
        "uptime": "",
        "active_networks": [],
        "active_interfaces": [],
        "serial_mappings": [],
        "route_table": [],
        "fdt_entries": [],
        "fdt_diagnostic": {},
        "fdt_read_status": "unknown",
        "fdt_read_error": "",
        "recent_errors": [],
        "last_apply": {},
    }
    if not isinstance(raw, dict):
        return runtime
    runtime.update({key: raw.get(key, runtime.get(key)) for key in runtime})
    return runtime


def load_mstp_status(data_dir: Path) -> dict[str, Any]:
    path = router_paths(data_dir)["mstp_status"]
    if not path.exists():
        return {"updated_at": "", "trunks": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"updated_at": "", "trunks": {}}


def save_mstp_status(data_dir: Path, payload: dict[str, Any]) -> None:
    _atomic_write_json(router_paths(data_dir)["mstp_status"], payload)


def mstp_status_grid(config: dict[str, Any], status_payload: dict[str, Any]) -> list[dict[str, Any]]:
    trunks: list[dict[str, Any]] = []
    trunk_status = status_payload.get("trunks") or {}
    for trunk in config.get("mstp_trunks") or []:
        cells: list[dict[str, Any]] = []
        router_mac = str(trunk.get("local_mac"))
        seen = (trunk_status.get(trunk.get("id")) or {}).get("macs") or {}
        for mac in range(128):
            key = str(mac)
            item = seen.get(key) or {}
            state = "unknown"
            if key == router_mac:
                state = "router"
            elif item.get("online"):
                state = "online"
            elif item.get("last_seen"):
                state = "offline"
            cells.append(
                {
                    "mac": mac,
                    "state": state,
                    "device_instance": item.get("device_instance", ""),
                    "device_name": item.get("device_name", ""),
                    "vendor_name": item.get("vendor_name", ""),
                    "first_seen": item.get("first_seen", ""),
                    "last_seen": item.get("last_seen", ""),
                    "response_count": item.get("response_count", 0),
                    "frame_count": item.get("frame_count", 0),
                    "error_count": item.get("error_count", 0),
                }
            )
        trunks.append({"trunk": trunk, "cells": cells, "updated_at": status_payload.get("updated_at", "")})
    return trunks
