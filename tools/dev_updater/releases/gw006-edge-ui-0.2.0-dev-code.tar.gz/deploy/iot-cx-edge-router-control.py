#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPO_ROOT = Path(os.environ.get("EDGE_ROUTER_REPO_ROOT", "/home/swadmin/edge-bacnet-ui-v2"))
sys.path.insert(0, str(REPO_ROOT))

import router_config as routercfg


DATA_DIR = Path(os.environ.get("EDGE_ROUTER_DATA_DIR", str(REPO_ROOT / "data")))
CONFIG_DIR = Path(os.environ.get("EDGE_ROUTER_CONFIG_DIR", "/etc/iot-cx/edge-bacnet-router"))
INIT_CFG = CONFIG_DIR / "init.cfg"
SERVICE_FILE = Path("/etc/systemd/system/iot-cx-bacnet-router.service")
LEGACY_SERVICE = os.environ.get("EDGE_ROUTER_LEGACY_SERVICE", "iot-cx-mstp-router.service")
ROUTER_SERVICE = os.environ.get("EDGE_ROUTER_SERVICE", "iot-cx-bacnet-router.service")
AGENT_SERVICE = os.environ.get("EDGE_ROUTER_AGENT_SERVICE", "iot-cx-agent.service")
BACKUP_ROOT = Path(os.environ.get("EDGE_ROUTER_BACKUP_DIR", "/var/lib/iot-cx-edge-router"))
BACNET_STACK_ROOT = Path(os.environ.get("BACNET_STACK_ROOT", "/home/swadmin/bacnet-stack"))
BACNET_BIN = BACNET_STACK_ROOT / "bin"
ROUTER_BUILD_DIR = BACNET_STACK_ROOT / "apps" / "router"
ROUTER_BINARY = BACNET_BIN / "router"
ROUTER_MSTP_BINARY = BACNET_BIN / "router-mstp"
DISCOVERY_PORT = os.environ.get("EDGE_ROUTER_DISCOVERY_PORT", "47816")
AGENT_CONFIG = Path(os.environ.get("EDGE_ROUTER_AGENT_CONFIG", "/etc/iot-cx-agent/agent.yaml"))
HELPER_PATH = Path("/usr/local/sbin/iot-cx-edge-router-control")
LEGACY_HELPER_BACKUP = BACKUP_ROOT / "legacy-helper"


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def run(
    args: list[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
    timeout: int = 30,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=str(cwd) if cwd else None,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=check,
    )


def systemctl(*args: str, timeout: int = 30, check: bool = True) -> subprocess.CompletedProcess[str]:
    return run(["/bin/systemctl", *args], timeout=timeout, check=check)


def systemctl_value(service: str, prop: str) -> str:
    result = systemctl("show", service, f"--property={prop}", "--value", check=False)
    return (result.stdout or "").strip()


def service_state(service: str) -> str:
    result = systemctl("is-active", service, check=False)
    return (result.stdout or "").strip() or "unknown"


def service_enabled(service: str) -> str:
    result = systemctl("is-enabled", service, check=False)
    return (result.stdout or "").strip() or "unknown"


def current_gateway_ip(iface: str) -> str:
    result = run(["ip", "-4", "-o", "addr", "show", "dev", iface], check=False, timeout=5)
    match = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)", result.stdout or "")
    return match.group(1) if match else ""


def copy_if_exists(src: Path, dst: Path) -> None:
    if src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def ensure_backup_snapshot() -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    target = BACKUP_ROOT / "backups" / stamp
    if target.exists():
        return target
    target.mkdir(parents=True, exist_ok=True)
    copy_if_exists(Path(f"/etc/systemd/system/{LEGACY_SERVICE}"), target / f"{LEGACY_SERVICE}.service")
    copy_if_exists(SERVICE_FILE, target / SERVICE_FILE.name)
    copy_if_exists(AGENT_CONFIG, target / AGENT_CONFIG.name)
    copy_if_exists(INIT_CFG, target / INIT_CFG.name)
    copy_if_exists(HELPER_PATH, target / "iot-cx-edge-router-control.previous")
    copy_if_exists(DATA_DIR / routercfg.ROUTER_CONFIG_FILE, target / routercfg.ROUTER_CONFIG_FILE)
    copy_if_exists(DATA_DIR / routercfg.ROUTER_LAST_GOOD_FILE, target / routercfg.ROUTER_LAST_GOOD_FILE)
    return target


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def legacy_config_snapshot() -> dict[str, Any]:
    config = routercfg.default_router_config()
    config["enabled"] = service_state(LEGACY_SERVICE) == "active"
    env_lines = (systemctl("cat", LEGACY_SERVICE, check=False).stdout or "").splitlines()
    env_map: dict[str, str] = {}
    for line in env_lines:
        if line.startswith("Environment="):
            key, _, value = line.removeprefix("Environment=").partition("=")
            env_map[key.strip()] = value.strip()
    iface = env_map.get("BACNET_IFACE", "")
    bind_address = current_gateway_ip(iface) if iface else ""
    trunk = config["mstp_trunks"][0]
    bip = config["bip_interfaces"][0]
    bip["display_name"] = "GW006 Primary B/IP"
    bip["linux_interface"] = iface
    bip["bind_address"] = bind_address
    bip["udp_port"] = int(env_map.get("BACNET_IP_PORT", "47809"))
    bip["network_number"] = int(env_map.get("BACNET_IP_NET", "1"))
    bip["mode"] = "bbmd"
    bip["bbmd_accept_foreign_registrations"] = True
    if env_map.get("BACNET_IP_NAT_ADDR") or env_map.get("BACNET_IP_NAT_PORT"):
        bip["nat_enabled"] = True
        bip["advertised_ip"] = env_map.get("BACNET_IP_NAT_ADDR", "")
        bip["advertised_port"] = int(env_map.get("BACNET_IP_NAT_PORT", str(bip["udp_port"])))
    trunk["display_name"] = "GW006 USB ISO-485"
    trunk["serial_device"] = env_map.get("BACNET_MSTP_IFACE", "")
    try:
        trunk["resolved_device"] = str(Path(trunk["serial_device"]).resolve()) if trunk["serial_device"] else ""
    except Exception:
        trunk["resolved_device"] = ""
    trunk["baud_rate"] = int(env_map.get("BACNET_MSTP_BAUD", "38400"))
    trunk["local_mac"] = int(env_map.get("BACNET_MSTP_MAC", "2"))
    trunk["max_info_frames"] = int(env_map.get("BACNET_MAX_INFO_FRAMES", "128"))
    trunk["max_master"] = int(env_map.get("BACNET_MAX_MASTER", "127"))
    trunk["network_number"] = int(env_map.get("BACNET_MSTP_NET", "202"))
    return config


def load_effective_config() -> dict[str, Any]:
    try:
        return routercfg.load_router_config(DATA_DIR, startup_ports=["47814"])
    except Exception:
        return routercfg.normalize_router_config(legacy_config_snapshot())


def router_service_unit() -> str:
    return f"""[Unit]
Description=IOT CX Edge BACnet Router
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory={BACNET_STACK_ROOT}
ExecStart={ROUTER_BINARY} -c {INIT_CFG}
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
"""


def simple_mstp_service_unit(config: dict[str, Any]) -> str:
    bip = next((item for item in config.get("bip_interfaces") or [] if item.get("enabled")), {})
    trunk = next((item for item in config.get("mstp_trunks") or [] if item.get("enabled")), {})
    return f"""[Unit]
Description=IOT CX BACnet IP to MS/TP Router
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory={BACNET_STACK_ROOT}
Environment=BACNET_IFACE={bip.get("linux_interface", "enp1s0")}
Environment=BACNET_IP_PORT={int(bip.get("udp_port") or 47809)}
Environment=BACNET_BBMD_PORT={int(bip.get("udp_port") or 47809)}
Environment=BACNET_IP_NAT_ADDR={bip.get("advertised_ip") or ""}
Environment=BACNET_IP_NAT_PORT={int(bip.get("advertised_port") or bip.get("udp_port") or 47809)}
Environment=BACNET_MSTP_IFACE={trunk.get("serial_device") or trunk.get("resolved_device") or "/dev/ttyUSB0"}
Environment=BACNET_MSTP_BAUD={int(trunk.get("baud_rate") or 38400)}
Environment=BACNET_MSTP_MAC={int(trunk.get("local_mac") or 2)}
Environment=BACNET_MAX_INFO_FRAMES={int(trunk.get("max_info_frames") or 1)}
Environment=BACNET_MAX_MASTER={int(trunk.get("max_master") or 127)}
Environment=BACNET_IP_NET={int(bip.get("network_number") or 1)}
Environment=BACNET_MSTP_NET={int(trunk.get("network_number") or 202)}
Environment=BACNET_ROUTER_DEBUG=1
ExecStart={ROUTER_MSTP_BINARY}
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
"""


def ensure_router_binary() -> None:
    if ROUTER_BINARY.exists():
        return
    result = run(["make", "router"], cwd=BACNET_STACK_ROOT, timeout=240, check=False)
    if result.returncode != 0 or not ROUTER_BINARY.exists():
        raise RuntimeError(f"Could not build bacnet-stack router binary: {(result.stderr or result.stdout).strip()}")


def write_runtime_files(config: dict[str, Any]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    routercfg.save_router_config(DATA_DIR, config)
    INIT_CFG.write_text(routercfg.render_bacnet_router_init_cfg(config), encoding="utf-8")
    INIT_CFG.chmod(0o644)
    SERVICE_FILE.write_text(router_service_unit(), encoding="utf-8")
    SERVICE_FILE.chmod(0o644)
    Path(f"/etc/systemd/system/{LEGACY_SERVICE}").write_text(simple_mstp_service_unit(config), encoding="utf-8")
    Path(f"/etc/systemd/system/{LEGACY_SERVICE}").chmod(0o644)
    systemctl("daemon-reload")


def parse_bacwi_line(line: str) -> dict[str, str] | None:
    parts = line.split()
    if len(parts) < 5 or not parts[0].isdigit():
        return None
    return {
        "device_instance": parts[0],
        "mac_hex": parts[1],
        "snet": parts[2],
        "sadr_hex": parts[3],
        "apdu": parts[4],
    }


def mstp_mac_from_sadr(raw: str) -> int | None:
    text = (raw or "").strip()
    if not text:
        return None
    parts = text.split(":")
    if len(parts) == 1 and re.fullmatch(r"[0-9A-Fa-f]{1,2}", parts[0]):
        return int(parts[0], 16)
    return None


def refresh_mstp_status(config: dict[str, Any]) -> dict[str, Any]:
    payload = routercfg.load_mstp_status(DATA_DIR)
    if service_state(ROUTER_SERVICE) != "active" and service_state(LEGACY_SERVICE) != "active":
        return payload
    bip = next((item for item in config.get("bip_interfaces") or [] if item.get("enabled")), None)
    if not bip:
        return payload
    env = os.environ.copy()
    env["BACNET_IP_PORT"] = DISCOVERY_PORT
    observed = payload.get("trunks") if isinstance(payload.get("trunks"), dict) else {}
    if not isinstance(observed, dict):
        observed = {}
    trunk_networks = {str(trunk.get("network_number")): str(trunk.get("id")) for trunk in config.get("mstp_trunks") or []}
    now = now_utc()
    route_table: list[str] = []
    router_mac = f"{bip.get('bind_address') or '127.0.0.1'}:{int(bip.get('udp_port') or 47809)}"
    for trunk in config.get("mstp_trunks") or []:
        if not trunk.get("enabled"):
            continue
        result = run(
            [
                str(BACNET_BIN / "bacwi"),
                "--mac",
                router_mac,
                "--dnet",
                str(int(trunk.get("network_number") or 0)),
                "--retry",
                "1",
                "--timeout",
                "3000",
                "--delay",
                "1000",
            ],
            cwd=BACNET_BIN,
            env=env,
            timeout=12,
            check=False,
        )
        for line in (result.stdout or "").splitlines():
            parsed = parse_bacwi_line(line)
            if not parsed:
                continue
            route_table.append(
                f"device {parsed['device_instance']} via network {parsed['snet']} address {parsed['sadr_hex']}"
            )
            trunk_id = trunk_networks.get(parsed["snet"])
            if not trunk_id:
                continue
            mac = mstp_mac_from_sadr(parsed["sadr_hex"])
            if mac is None:
                continue
            observed_trunk = observed.setdefault(trunk_id, {"macs": {}})
            macs = observed_trunk.setdefault("macs", {})
            entry = macs.setdefault(
                str(mac),
                {
                    "device_instance": parsed["device_instance"],
                    "device_name": "",
                    "vendor_name": "",
                    "first_seen": now,
                    "last_seen": now,
                    "response_count": 0,
                    "frame_count": 0,
                    "error_count": 0,
                    "online": True,
                },
            )
            entry["device_instance"] = parsed["device_instance"]
            entry["last_seen"] = now
            entry["online"] = True
            entry["response_count"] = int(entry.get("response_count", 0)) + 1
            entry["frame_count"] = int(entry.get("frame_count", 0)) + 1
    payload = {"updated_at": now, "trunks": observed, "route_table": route_table}
    routercfg.save_mstp_status(DATA_DIR, payload)
    return payload


def _active_bip_endpoint(config: dict[str, Any]) -> tuple[str, int] | None:
    bip = next((item for item in config.get("bip_interfaces") or [] if item.get("enabled")), None)
    if not bip:
        return None
    bind_address = str(bip.get("bind_address") or "127.0.0.1")
    return bind_address, int(bip.get("udp_port") or 47809)


def parse_bvlc_fdt_ack(data: bytes) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if len(data) < 4:
        raise ValueError(f"FDT response is too short: {len(data)} bytes.")
    if data[0] != 0x81:
        raise ValueError(f"FDT response has unexpected BVLC type 0x{data[0]:02x}.")
    if data[1] != 0x07:
        raise ValueError(f"FDT response has unexpected BVLC function 0x{data[1]:02x}; expected 0x07.")
    length = struct.unpack(">H", data[2:4])[0]
    if length > len(data):
        raise ValueError(f"FDT response length field {length} exceeds received length {len(data)}.")
    payload = data[4:length]
    if len(payload) % 10:
        raise ValueError(f"FDT response payload length {len(payload)} is not a multiple of 10 bytes.")
    entries: list[dict[str, Any]] = []
    for offset in range(0, len(payload), 10):
        chunk = payload[offset:offset + 10]
        port = int.from_bytes(chunk[4:6], "big")
        ttl = int.from_bytes(chunk[6:8], "big")
        remaining = int.from_bytes(chunk[8:10], "big")
        entries.append(
            {
                "address": ".".join(str(part) for part in chunk[:4]),
                "port": port,
                "ttl_seconds": ttl,
                "remaining_seconds": remaining,
            }
        )
    return entries, {
        "function": "Read-Foreign-Device-Table-Ack",
        "function_code": "0x07",
        "length": length,
        "payload_bytes": len(payload),
        "entry_count": len(entries),
    }


def _send_bvlc(sock: socket.socket, router: tuple[str, int], payload: bytes) -> tuple[bytes, tuple[str, int]]:
    sock.sendto(payload, router)
    return sock.recvfrom(4096)


def read_bvlc_fdt_diagnostic(config: dict[str, Any], *, source_port: int = 0, timeout: float = 2.0) -> dict[str, Any]:
    endpoint = _active_bip_endpoint(config)
    if endpoint is None:
        return {
            "status": "skipped",
            "entries": [],
            "error": "No enabled BACnet/IP interface is configured.",
        }
    bind_address, router_port = endpoint
    router = (bind_address, router_port)
    request = bytes([0x81, 0x06, 0x00, 0x04])
    diagnostic: dict[str, Any] = {
        "status": "failed",
        "entries": [],
        "error": "",
        "request": {
            "function": "Read-Foreign-Device-Table",
            "function_code": "0x06",
            "hex": request.hex(" "),
            "target": f"{router[0]}:{router[1]}",
            "source": "",
        },
        "response": {},
    }
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind((bind_address, source_port))
        sock.settimeout(timeout)
        diagnostic["request"]["source"] = f"{sock.getsockname()[0]}:{sock.getsockname()[1]}"
        data, peer = _send_bvlc(sock, router, request)
        entries, response = parse_bvlc_fdt_ack(data)
        response["from"] = f"{peer[0]}:{peer[1]}"
        response["hex"] = data[:min(len(data), 80)].hex(" ")
        diagnostic["entries"] = entries
        diagnostic["response"] = response
        diagnostic["status"] = "success" if entries else "empty"
        return diagnostic
    except socket.timeout:
        diagnostic["error"] = (
            "Timed out waiting for BVLC Read-Foreign-Device-Table-Ack from "
            f"{router[0]}:{router[1]}."
        )
        return diagnostic
    except Exception as exc:
        diagnostic["error"] = str(exc)
        return diagnostic
    finally:
        sock.close()


def read_bvlc_fdt(config: dict[str, Any]) -> list[dict[str, Any]]:
    return list(read_bvlc_fdt_diagnostic(config).get("entries") or [])


def run_fdt_runtime_test(config: dict[str, Any]) -> dict[str, Any]:
    endpoint = _active_bip_endpoint(config)
    if endpoint is None:
        raise RuntimeError("No enabled BACnet/IP interface is configured.")
    bind_address, router_port = endpoint
    router = (bind_address, router_port)
    ttl = 30
    register = bytes([0x81, 0x05, 0x00, 0x06]) + ttl.to_bytes(2, "big")
    result: dict[str, Any] = {
        "router": f"{router[0]}:{router[1]}",
        "registered_endpoint": "",
        "register_success": False,
        "first_read": {},
        "second_read": {},
        "refresh_read": {},
    }
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind((bind_address, 0))
        sock.settimeout(2)
        source = sock.getsockname()
        result["registered_endpoint"] = f"{source[0]}:{source[1]}"
        data, peer = _send_bvlc(sock, router, register)
        result["register_response"] = {"from": f"{peer[0]}:{peer[1]}", "hex": data.hex(" ")}
        if data != bytes([0x81, 0x00, 0x00, 0x06, 0x00, 0x00]):
            raise RuntimeError(f"Register-Foreign-Device returned unexpected BVLC result: {data.hex(' ')}")
        result["register_success"] = True

        first = read_bvlc_fdt_diagnostic(config, source_port=0, timeout=2)
        result["first_read"] = first
        expected = next(
            (
                item
                for item in first.get("entries") or []
                if item.get("address") == source[0] and int(item.get("port") or 0) == source[1]
            ),
            None,
        )
        if expected is None:
            raise RuntimeError(f"Registered endpoint {source[0]}:{source[1]} was not present in FDT read.")

        time.sleep(2)
        second = read_bvlc_fdt_diagnostic(config, source_port=0, timeout=2)
        result["second_read"] = second
        aged = next(
            (
                item
                for item in second.get("entries") or []
                if item.get("address") == source[0] and int(item.get("port") or 0) == source[1]
            ),
            None,
        )
        if aged is None:
            raise RuntimeError(f"Registered endpoint {source[0]}:{source[1]} disappeared from FDT read.")
        if int(aged.get("remaining_seconds") or 0) >= int(expected.get("remaining_seconds") or 0):
            raise RuntimeError("FDT remaining time did not decrease between reads.")

        data, peer = _send_bvlc(sock, router, register)
        result["refresh_response"] = {"from": f"{peer[0]}:{peer[1]}", "hex": data.hex(" ")}
        if data != bytes([0x81, 0x00, 0x00, 0x06, 0x00, 0x00]):
            raise RuntimeError(f"Re-registration returned unexpected BVLC result: {data.hex(' ')}")
        refresh = read_bvlc_fdt_diagnostic(config, source_port=0, timeout=2)
        result["refresh_read"] = refresh
        refreshed = next(
            (
                item
                for item in refresh.get("entries") or []
                if item.get("address") == source[0] and int(item.get("port") or 0) == source[1]
            ),
            None,
        )
        if refreshed is None:
            raise RuntimeError(f"Registered endpoint {source[0]}:{source[1]} disappeared after refresh.")
        if int(refreshed.get("remaining_seconds") or 0) < int(aged.get("remaining_seconds") or 0):
            raise RuntimeError("FDT remaining time did not refresh after re-registration.")
        result["status"] = "success"
        return result
    finally:
        sock.close()


def status_payload(message: str = "") -> dict[str, Any]:
    config = load_effective_config()
    mstp_status = refresh_mstp_status(config)
    active_service = LEGACY_SERVICE if service_state(LEGACY_SERVICE) == "active" else ROUTER_SERVICE
    active_state = service_state(active_service)
    fdt_diagnostic = read_bvlc_fdt_diagnostic(config) if active_state == "active" else {
        "status": "skipped",
        "entries": [],
        "error": "Router service is not active.",
    }
    runtime = {
        "service_name": active_service,
        "service_status": active_state,
        "legacy_service_status": service_state(LEGACY_SERVICE),
        "health": "ok" if active_state == "active" else "standby",
        "pid": systemctl_value(active_service, "MainPID"),
        "uptime": "",
        "active_networks": [
            str(item.get("network_number"))
            for item in (config.get("bip_interfaces") or []) + (config.get("mstp_trunks") or [])
            if item.get("enabled")
        ],
        "active_interfaces": [
            f"{item.get('linux_interface')}:{item.get('udp_port')}"
            for item in config.get("bip_interfaces") or []
            if item.get("enabled")
        ],
        "serial_mappings": [
            {
                "stable_path": trunk.get("serial_device"),
                "resolved_path": str(Path(str(trunk.get("serial_device") or "")).resolve()) if trunk.get("serial_device") else "",
            }
            for trunk in config.get("mstp_trunks") or []
        ],
        "route_table": mstp_status.get("route_table") or [],
        "fdt_entries": fdt_diagnostic.get("entries") or [],
        "fdt_diagnostic": fdt_diagnostic,
        "fdt_read_status": fdt_diagnostic.get("status") or "unknown",
        "fdt_read_error": fdt_diagnostic.get("error") or "",
        "recent_errors": [],
        "last_apply": config.get("last_apply") or {},
    }
    pid = runtime["pid"]
    if pid and pid.isdigit() and int(pid) > 0:
        ps = run(["ps", "-o", "etime=", "-p", pid], check=False, timeout=5)
        runtime["uptime"] = (ps.stdout or "").strip()
    if runtime["service_status"] != "active":
        runtime["health"] = "standby" if config.get("enabled") is False else "degraded"
        journal = run(["journalctl", "-u", active_service, "-n", "10", "--no-pager", "-o", "cat"], check=False, timeout=10)
        runtime["recent_errors"] = [line for line in (journal.stdout or "").splitlines() if line.strip()][-5:]
    return {
        "message": message,
        "config": config,
        "runtime": runtime,
        "mstp_status": mstp_status,
        "saved_standard_bacnet_route": "preserved" if service_enabled(LEGACY_SERVICE) != "not-found" else "unknown",
        "legacy_summary": {
            "service": LEGACY_SERVICE,
            "status": service_state(LEGACY_SERVICE),
            "enabled": service_enabled(LEGACY_SERVICE),
        },
    }


def rollback_to_legacy() -> None:
    systemctl("disable", "--now", ROUTER_SERVICE, timeout=120, check=False)
    systemctl("enable", "--now", LEGACY_SERVICE, timeout=180, check=False)
    systemctl("restart", AGENT_SERVICE, timeout=120, check=False)


def stop_router_services() -> None:
    systemctl("disable", "--now", ROUTER_SERVICE, timeout=120, check=False)
    systemctl("disable", "--now", LEGACY_SERVICE, timeout=180, check=False)


def apply_config(payload: dict[str, Any]) -> dict[str, Any]:
    config = payload.get("config") if isinstance(payload.get("config"), dict) else payload
    config = routercfg.normalize_router_config(config)
    routercfg.validate_router_config(config, routercfg.discover_serial_candidates())
    ensure_backup_snapshot()
    write_runtime_files(config)
    if not config.get("enabled"):
        stop_router_services()
        config["last_apply"] = {"at": now_utc(), "status": "disabled", "message": "Router runtime disabled; legacy service preserved but inactive."}
        routercfg.save_router_config(DATA_DIR, config, update_revision=False)
        return status_payload("Router runtime disabled; legacy service preserved but inactive.")

    start = systemctl("disable", "--now", ROUTER_SERVICE, timeout=120, check=False)
    start = systemctl("enable", "--now", LEGACY_SERVICE, timeout=120, check=False)
    if service_state(LEGACY_SERVICE) != "active":
        stop_router_services()
        detail = (start.stderr or start.stdout or "MS/TP router service failed to start.").strip()
        raise RuntimeError(detail)
    systemctl("restart", AGENT_SERVICE, timeout=120, check=False)
    config["last_apply"] = {"at": now_utc(), "status": "active", "message": "Router runtime started successfully."}
    routercfg.save_router_config(DATA_DIR, config, update_revision=False)
    routercfg.save_last_known_good(DATA_DIR, config)
    return status_payload("Router configuration applied.")


def restart_router() -> dict[str, Any]:
    config = load_effective_config()
    if not config.get("enabled"):
        stop_router_services()
        return status_payload("Router is disabled; legacy service preserved but inactive.")
    systemctl("disable", "--now", ROUTER_SERVICE, timeout=120, check=False)
    systemctl("restart", LEGACY_SERVICE, timeout=120, check=False)
    if service_state(LEGACY_SERVICE) != "active":
        stop_router_services()
        raise RuntimeError("Router service did not return to active state after restart.")
    return status_payload("Router restarted.")


def stop_router() -> dict[str, Any]:
    stop_router_services()
    config = load_effective_config()
    config["enabled"] = False
    config["last_apply"] = {"at": now_utc(), "status": "stopped", "message": "Router stopped; legacy service preserved but inactive."}
    routercfg.save_router_config(DATA_DIR, config, update_revision=False)
    return status_payload("Router stopped; legacy service preserved but inactive.")


def restore_last_good() -> dict[str, Any]:
    config = routercfg.restore_last_known_good(DATA_DIR)
    return apply_config({"config": config})


def main() -> int:
    commands = {"status", "apply", "restart", "stop", "restore-last-good", "fdt-test"}
    if len(sys.argv) != 2 or sys.argv[1] not in commands:
        print("usage: iot-cx-edge-router-control {status|apply|restart|stop|restore-last-good|fdt-test}", file=sys.stderr)
        return 2
    command = sys.argv[1]
    try:
        if command == "status":
            payload = status_payload()
        elif command == "apply":
            stdin = sys.stdin.read()
            payload = apply_config(json.loads(stdin) if stdin.strip() else {})
        elif command == "restart":
            payload = restart_router()
        elif command == "stop":
            payload = stop_router()
        elif command == "restore-last-good":
            payload = restore_last_good()
        else:
            payload = run_fdt_runtime_test(load_effective_config())
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({"message": str(exc)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
