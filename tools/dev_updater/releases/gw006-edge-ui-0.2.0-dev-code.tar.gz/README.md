# Edge BACnet Commissioning UI

Canonical Flask UI for BACnet discovery, template building, and commissioning
views using bacnet-stack tools. It was recovered read-only from GW006 on
2026-07-23; see [source provenance](docs/SOURCE_PROVENANCE.md).

Local development is intentionally isolated. GW006 is not required, must not
be contacted, and is outside the scope of this repository.

## Local Development

Use the safe local mode described in [docs/LOCAL_DEVELOPMENT.md](docs/LOCAL_DEVELOPMENT.md).
The validated local baseline uses:

- repo-local virtual environment at `.venv`
- loopback-only launch on `127.0.0.1:5001`
- `EDGE_UI_SAFE_MODE=1`
- fake local-only credentials
- repository-excluded runtime data under `data/`

Typical workflow:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/pip install -r requirements-dev.txt
. .venv/bin/activate
cp .env.example .env.local
python app.py
```

## Runtime Boundaries

- Do not put real gateway credentials, tokens, passwords, certificates, or
  machine-local startup scripts in this repository.
- Do not commit `.venv`, runtime databases, captures, exports, logs, caches,
  or local environment files.
- Do not deploy from this repository without a separate reviewed deployment
  procedure.
- Do not use GW006 secrets or connect the local test environment to BACnet,
  serial, service-management, or routing operations.

## Validation

The local-safe baseline is intended to be validated with:

```bash
.venv/bin/python -m compileall .
.venv/bin/pytest
```

See [docs/LOCAL_DEVELOPMENT.md](docs/LOCAL_DEVELOPMENT.md) for the full setup,
test, launch, and cleanup procedure.
