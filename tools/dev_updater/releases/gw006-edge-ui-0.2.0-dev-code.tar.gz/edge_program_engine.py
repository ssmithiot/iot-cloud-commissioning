"""Restricted, local Control Basic-style program engine.

This module intentionally contains no eval/exec and has no filesystem or shell
access beyond its SQLite store.  BACnet I/O is injected through an adapter.
"""
from __future__ import annotations

import json
import math
import re
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Protocol

MAX_SOURCE = 50_000
POINT_TYPES = {"AI": "analog-input", "BI": "binary-input", "AV": "analog-value", "BV": "binary-value", "AO": "analog-output", "BO": "binary-output", "MSV": "multi-state-value", "MSO": "multi-state-output"}
WRITABLE = {"AV", "BV", "AO", "BO", "MSV", "MSO"}
DEFAULT_PRIORITY = 9
WRITE_REFRESH_SECONDS = 15 * 60


class ProgramError(Exception):
    def __init__(self, message: str, line: int = 0, column: int = 0, excerpt: str = ""):
        self.message, self.line, self.column, self.excerpt = message, line, column, excerpt
        super().__init__(message)

    def as_dict(self) -> dict[str, Any]:
        return {"message": self.message, "line": self.line, "column": self.column, "excerpt": self.excerpt}


@dataclass(frozen=True)
class Point:
    device: int; kind: str; instance: int
    @property
    def key(self) -> str: return f"{self.device}.{self.kind}.{self.instance}.PV"


def parse_point(value: str, *, line: int = 0, write: bool = False) -> Point:
    value = value.upper().strip()
    match = re.fullmatch(r"(\d+)\.(AI|BI|AV|BV|AO|BO|MSV|MSO)\.(\d+)\.PV", value) or re.fullmatch(r"(\d+)\.(AI|BI|AV|BV|AO|BO|MSV|MSO)(\d+)", value)
    if not match:
        raise ProgramError(f"Invalid BACnet point reference `{value}`", line, 1, value)
    device, kind, instance = int(match.group(1)), match.group(2), int(match.group(3))
    if device < 1 or instance < 0: raise ProgramError("Device and object instances must be valid positive values", line, 1, value)
    if write and kind not in WRITABLE: raise ProgramError(f"Writes to {kind} are not supported", line, 1, value)
    return Point(device, kind, instance)


def _split_statements(text: str) -> list[str]:
    """Split only top-level comma statements; commas inside calls are retained."""
    result, current, depth = [], [], 0
    for char in text:
        if char == "(": depth += 1
        elif char == ")": depth -= 1
        if char == "," and depth == 0:
            if " THEN " in "".join(current).upper() or " ELSE " in "".join(current).upper():
                result.append("".join(current).strip()); current = []; continue
        current.append(char)
    if "".join(current).strip(): result.append("".join(current).strip())
    return result


def _translate_expr(expression: str, variables: set[str], line: int) -> tuple[str, list[Point]]:
    """Validate an expression and translate point references to P[index].

    The output is deliberately an inspected token stream interpreted below,
    never Python source.
    """
    points: list[Point] = []
    expr = expression.strip().upper()
    # Edge Programs extension: inclusive BETWEEN keeps CASE/IF expressions
    # concise while compiling to the existing Boolean operators.
    between = re.fullmatch(r"(.+?)\s+IS\s+BETWEEN\s*\(\s*(.+?)\s*,\s*(.+?)\s*\)", expr, re.I)
    if between:
        expr = f"({between.group(1)} >= {between.group(2)} AND {between.group(1)} <= {between.group(3)})"
    # A small recursive expression evaluator is represented as tokens.
    tokens = re.findall(r"\d{1,2}:\d{2}(?::\d{2})?|\d+\.\w+(?:\.\d+\.PV|\d+)|\d+(?:\.\d+)?|[A-Z_][A-Z0-9_]*|<>|<=|>=|[()+*/=<>,-]", expr)
    if "".join(tokens).replace(" ", "") != re.sub(r"\s+", "", expr): raise ProgramError("Invalid token in expression", line, 1, expression)
    for token in tokens:
        if re.fullmatch(r"\d+\.\w+(?:\.\d+\.PV|\d+)", token): points.append(parse_point(token, line=line))
        elif re.fullmatch(r"[A-Z_][A-Z0-9_]*", token) and token not in {"AVG", "MIN", "MAX", "ABS", "ISNAN", "TIMEON", "TIMEOFF", "AND", "OR", "XOR", "NOT"} and token not in variables:
            raise ProgramError(f"Undeclared variable `{token}`", line, 1, expression)
    return expr, points


def compile_program(source: str) -> dict[str, Any]:
    """Compile the deliberately small language to a data-only block tree."""
    if len(source) > MAX_SOURCE:
        raise ProgramError("Source exceeds 50,000 characters")
    variables: set[str] = set()
    reads: dict[str, Point] = {}
    # Control Basic uses REM for comments.  Strings are deliberately not in this
    # language yet, so REM may safely terminate a source line as either a full
    # line comment or an inline comment after a valid statement.
    lines: list[tuple[int, str, str]] = []
    for number, raw in enumerate(source.splitlines(), 1):
        line = re.split(r"\bREM\b", raw, maxsplit=1, flags=re.I)[0].strip()
        if line:
            lines.append((number, raw, line))

    def remember(points: list[Point]) -> None:
        for point in points:
            reads.setdefault(point.key, point)

    def condition(text: str, number: int) -> str:
        interval = re.fullmatch(r"INTERVAL\((\d+(?:\.\d+)?|\d{2}:\d{2}:\d{2})\)", text.strip(), re.I)
        if interval:
            raw_interval = interval.group(1)
            seconds = (int(raw_interval[:2]) * 3600 + int(raw_interval[3:5]) * 60 + int(raw_interval[6:])) if ":" in raw_interval else float(raw_interval)
            if seconds < 5:
                raise ProgramError("INTERVAL minimum is 5 seconds", number, 1, text)
            return f"INTERVAL({seconds})"
        expr, points = _translate_expr(text, variables, number)
        remember(points)
        return expr

    def simple(text: str, number: int) -> dict[str, Any]:
        text = text.strip()
        upper = text.upper()
        if upper.startswith("RLQ "):
            match = re.fullmatch(r"RLQ\s+(.+?)(?:@(\d+))?", text, re.I)
            if not match:
                raise ProgramError("RLQ requires a writable point and optional @priority", number, 1, text)
            point = parse_point(match.group(1), line=number, write=True)
            priority = int(match.group(2) or DEFAULT_PRIORITY)
            if not 1 <= priority <= 16:
                raise ProgramError("Priority must be 1 through 16", number, 1, text)
            return {"op": "rlq", "point": point.key, "priority": priority, "line": number}
        match = re.fullmatch(r"(.+?)(?:@(\d+))?\s*=\s*(.+)", text, re.I)
        if not match:
            raise ProgramError(f"Unknown statement `{text}`", number, 1, text)
        target, priority_text, expression = match.group(1).strip().upper(), match.group(2), match.group(3)
        expr, points = _translate_expr(expression, variables, number)
        remember(points)
        if re.fullmatch(r"[A-Z_][A-Z0-9_]*", target):
            if priority_text:
                raise ProgramError("Priorities apply only to BACnet point writes", number, 1, text)
            if target not in variables:
                raise ProgramError(f"Undeclared variable `{target}`", number, 1, text)
            return {"op": "assign", "target": target, "expr": expr, "line": number}
        point = parse_point(target, line=number, write=True)
        priority = int(priority_text or DEFAULT_PRIORITY)
        if not 1 <= priority <= 16:
            raise ProgramError("Priority must be 1 through 16", number, 1, text)
        return {"op": "write", "point": point.key, "priority": priority, "expr": expr, "line": number}

    def inline(text: str, number: int) -> list[dict[str, Any]]:
        pieces, current, depth = [], [], 0
        for char in text:
            if char == "(": depth += 1
            elif char == ")": depth -= 1
            if char == "," and depth == 0:
                if "".join(current).strip(): pieces.append("".join(current).strip())
                current = []
            else:
                current.append(char)
        if "".join(current).strip(): pieces.append("".join(current).strip())
        return [simple(piece, number) for piece in pieces]

    index = 0
    def block(stops: set[str]) -> list[dict[str, Any]]:
        nonlocal index
        result: list[dict[str, Any]] = []
        while index < len(lines):
            number, raw, line = lines[index]
            upper = line.upper()
            if upper in stops:
                return result
            if upper.startswith(("LOCALVARS ", "LOCALS ")):
                names = re.split(r"\s*,\s*", line.split(None, 1)[1].strip())
                for name in names:
                    name = name.upper()
                    if not re.fullmatch(r"[A-Z_][A-Z0-9_]*", name):
                        raise ProgramError(f"Invalid local variable `{name}`", number, 1, raw)
                    variables.add(name)
                if len(variables) > 100: raise ProgramError("Maximum 100 local variables", number, 1, raw)
                index += 1; continue
            if upper == "END": index += 1; continue
            if re.match(r"IF[+-]?\s", upper):
                match = re.fullmatch(r"IF([+-]?)\s+(.+?)\s+THEN(?:\s+(.*?))?(?:\s+ELSE\s+(.*))?", line, re.I)
                if not match: raise ProgramError("IF requires condition THEN statement", number, 1, raw)
                node = {"op": "if", "condition": condition(match.group(2), number), "line": number, "edge": match.group(1)}
                index += 1
                if match.group(3):
                    node["then"] = inline(match.group(3), number)
                    node["else"] = inline(match.group(4), number) if match.group(4) else []
                else:
                    node["then"] = block({"ELSE", "ENDIF"})
                    if index >= len(lines): raise ProgramError("Missing ENDIF", number, 1, raw)
                    if lines[index][2].upper() == "ELSE":
                        index += 1; node["else"] = block({"ENDIF"})
                    else: node["else"] = []
                    if index >= len(lines) or lines[index][2].upper() != "ENDIF": raise ProgramError("Missing ENDIF", number, 1, raw)
                    index += 1
                result.append(node); continue
            if upper == "SELECT_CASE":
                index += 1; cases: list[dict[str, Any]] = []
                while index < len(lines) and lines[index][2].upper() != "END_SELECT":
                    case_number, case_raw, case_line = lines[index]
                    match = re.fullmatch(r"CASE\s+(.+?)\s+THEN\s+(.+)", case_line, re.I)
                    if not match: raise ProgramError("SELECT_CASE accepts CASE condition THEN statement", case_number, 1, case_raw)
                    cases.append({"condition": condition(match.group(1), case_number), "then": inline(match.group(2), case_number), "line": case_number})
                    index += 1
                if index >= len(lines): raise ProgramError("Missing END_SELECT", number, 1, raw)
                index += 1; result.append({"op": "select", "cases": cases, "line": number}); continue
            if upper.startswith(("FOR", "NEXT", "WHILE", "DO", "FUNCTION", "PROCEDURE", "RETURN", "GOTO", "GOSUB", "ONERROR", "NETPOINT", "COV", "TIMEON", "TIMEOFF")):
                raise ProgramError("This language feature is reserved but not implemented yet", number, 1, raw)
            result.append(simple(line, number)); index += 1
        return result

    statements = block(set())
    if not variables:
        raise ProgramError("LOCALVARS or LOCALS declaration is required")
    return {"variables": sorted(variables), "statements": statements, "reads": [point.key for point in reads.values()]}


class BacnetAdapter(Protocol):
    """The only boundary the runtime may use for live BACnet operations."""
    def read_many(self, points: list[Point]) -> dict[str, float]: ...
    def write(self, point: Point, value: float, priority: int) -> None: ...
    def relinquish(self, point: Point, priority: int) -> None: ...


@dataclass
class WriteRecord:
    value: float | None
    priority: int
    succeeded_at: float


class WriteSuppressor:
    """Per-program target cache; failures are deliberately never suppressed."""
    def __init__(self, refresh_seconds: int = WRITE_REFRESH_SECONDS):
        self.refresh_seconds, self._records = refresh_seconds, {}
    def should_write(self, point: Point, value: float | None, priority: int, now: float | None = None) -> tuple[bool, str]:
        now = time.monotonic() if now is None else now
        previous = self._records.get(point.key)
        if previous is None: return True, "WRITE"
        if previous.value != value or previous.priority != priority: return True, "WRITE"
        if now - previous.succeeded_at >= self.refresh_seconds: return True, "WRITE"
        return False, "WRITE SKIPPED (UNCHANGED)"
    def record_success(self, point: Point, value: float | None, priority: int, now: float | None = None) -> None:
        self._records[point.key] = WriteRecord(value, priority, time.monotonic() if now is None else now)
    def record_failure(self, point: Point) -> None: self._records.pop(point.key, None)


@dataclass
class ExecutionSnapshot:
    state: str = "Compiled"
    last_scan: str = ""
    duration_ms: int = 0
    variables: dict[str, float] | None = None
    reads: dict[str, float] | None = None
    writes: list[str] | None = None
    suppressed_writes: int = 0
    trace: list[str] | None = None


class ExpressionParser:
    """Small, data-only recursive-descent evaluator; never evaluates Python."""
    def __init__(self, text: str, variables: dict[str, float], reads: dict[str, float], timers: dict[str, dict[str, Any]] | None = None):
        self.tokens = re.findall(r"\d{1,2}:\d{2}(?::\d{2})?|\d+\.\w+(?:\.\d+\.PV|\d+)|\d+(?:\.\d+)?|[A-Z_][A-Z0-9_]*|<>|<=|>=|[()+*/=<>,-]", text.upper()) + ["EOF"]
        self.i, self.variables, self.reads, self.timers = 0, variables, reads, timers if timers is not None else {}
    def take(self, token: str | None = None):
        value=self.tokens[self.i]
        if token and value != token: raise ProgramError(f"Expected `{token}`, got `{value}`")
        self.i += 1; return value
    def parse(self):
        value=self.or_expr()
        if self.tokens[self.i] != "EOF": raise ProgramError(f"Unexpected token `{self.tokens[self.i]}`")
        return value
    def or_expr(self):
        value=self.xor_expr()
        while self.tokens[self.i] == "OR":
            self.take()
            # Always parse the RHS even when the result is already known.
            # Python short-circuiting here would leave tokens unconsumed.
            other = self.xor_expr()
            value = bool(value) or bool(other)
        return value
    def xor_expr(self):
        value = self.and_expr()
        while self.tokens[self.i] == "XOR":
            self.take()
            value = bool(value) != bool(self.and_expr())
        return value
    def and_expr(self):
        value=self.compare()
        while self.tokens[self.i] == "AND":
            self.take()
            # See or_expr: consuming every token is required by this parser.
            other = self.compare()
            value = bool(value) and bool(other)
        return value
    def compare(self):
        value=self.sum_expr()
        if self.tokens[self.i] in {"=","<>","<",">","<=",">="}:
            op=self.take(); other=self.sum_expr()
            return {"=":value==other,"<>":value!=other,"<":value<other,">":value>other,"<=":value<=other,">=":value>=other}[op]
        return value
    def sum_expr(self):
        value=self.term()
        while self.tokens[self.i] in {"+","-"}:
            op=self.take(); other=self.term(); value=value+other if op=="+" else value-other
        return value
    def term(self):
        value=self.factor()
        while self.tokens[self.i] in {"*","/"}:
            op=self.take(); other=self.factor()
            if op=="/" and other == 0: raise ProgramError("Divide by zero")
            value=value*other if op=="*" else value/other
        return value
    def factor(self):
        token=self.take()
        if token == "-": return -self.factor()
        if token == "NOT": return not bool(self.factor())
        if token == "(": value=self.or_expr(); self.take(")"); return value
        if re.fullmatch(r"\d+(?:\.\d+)?",token): return float(token)
        if re.fullmatch(r"\d{1,2}:\d{2}(?::\d{2})?", token):
            parts=[int(v) for v in token.split(":")]
            return float(parts[-1] + parts[-2] * 60 + (parts[-3] * 3600 if len(parts) == 3 else 0))
        if re.fullmatch(r"\d+\.\w+(?:\.\d+\.PV|\d+)",token): return self.reads.get(parse_point(token).key, math.nan)
        if self.tokens[self.i] == "(":
            self.take("("); args=[]
            if token in {"TIMEON", "TIMEOFF"}:
                point_token=self.take()
                if not re.fullmatch(r"\d+\.\w+(?:\.\d+\.PV|\d+)", point_token): raise ProgramError(f"{token} requires a BACnet point")
                self.take(")")
                point=parse_point(point_token); active=bool(self.reads.get(point.key, math.nan)) and not math.isnan(self.reads.get(point.key, math.nan))
                now=time.monotonic(); state=self.timers.setdefault(point.key, {"active":active,"changed":now})
                if state["active"] != active: state.update(active=active, changed=now)
                return max(0.0, now-float(state["changed"])) if active == (token == "TIMEON") else 0.0
            if self.tokens[self.i] != ")":
                args.append(self.or_expr())
                while self.tokens[self.i] == ",": self.take(); args.append(self.or_expr())
            self.take(")")
            if token == "AVG": return sum(args)/len(args) if args else (_ for _ in ()).throw(ProgramError("AVG requires arguments"))
            if token == "MIN": return min(args) if args else (_ for _ in ()).throw(ProgramError("MIN requires arguments"))
            if token == "MAX": return max(args) if args else (_ for _ in ()).throw(ProgramError("MAX requires arguments"))
            if token == "ABS" and len(args)==1: return abs(args[0])
            if token == "ISNAN" and len(args)==1: return math.isnan(args[0])
            raise ProgramError(f"Invalid function `{token}`")
        if token in self.variables: return self.variables[token]
        raise ProgramError(f"Undeclared variable `{token}`")


def execute_program(
    compiled: dict[str, Any], adapter: BacnetAdapter, *, dry: bool,
    interval_state: dict[str, float] | None = None,
    suppressor: WriteSuppressor | None = None,
    variable_state: dict[str, float] | None = None,
    edge_state: dict[str, bool] | None = None,
    timer_state: dict[str, dict[str, Any]] | None = None,
) -> ExecutionSnapshot:
    """Execute a compiled tree.  In dry mode intervals are true and no I/O writes occur."""
    started = time.monotonic()
    points = [parse_point(value) for value in compiled["reads"]]
    reads = adapter.read_many(points)
    variables: dict[str, float] = {name: float((variable_state or {}).get(name, 0.0)) for name in compiled["variables"]}
    trace = ["INTERVAL = TRUE" if dry else "Scheduled scan"]
    for point in points:
        trace.append(f"Read: {point.key} = {reads.get(point.key, math.nan)}")
    writes: list[str] = []
    interval_state = interval_state if interval_state is not None else {}
    edge_state = edge_state if edge_state is not None else {}
    timer_state = timer_state if timer_state is not None else {}
    suppressor = suppressor or WriteSuppressor()

    def truth(condition: str, line: int) -> bool:
        interval = re.fullmatch(r"INTERVAL\((.+)\)", condition)
        if interval:
            seconds = float(interval.group(1)); key = str(line); now = time.monotonic()
            if dry or now - interval_state.get(key, -seconds) >= seconds:
                if not dry: interval_state[key] = now
                return True
            return False
        return bool(ExpressionParser(condition, variables, reads, timer_state).parse())

    def perform(statements: list[dict[str, Any]]) -> None:
        for statement in statements:
            operation = statement["op"]
            if operation == "assign":
                value = ExpressionParser(statement["expr"], variables, reads, timer_state).parse()
                variables[statement["target"]] = float(value)
                trace.append(f"{statement['target']} = {variables[statement['target']]}")
            elif operation == "if":
                current = truth(statement["condition"], statement["line"])
                edge = statement.get("edge", "")
                previous = edge_state.get(str(statement["line"]), False)
                edge_state[str(statement["line"])] = current
                hit = current if not edge else (current and not previous if edge == "+" else (not current and previous))
                selected = statement["then"] if hit else statement["else"]
                trace.append(f"IF line {statement['line']} = {'TRUE' if selected is statement['then'] else 'FALSE'}")
                perform(selected)
            elif operation == "select":
                for case in statement["cases"]:
                    if truth(case["condition"], case["line"]):
                        trace.append(f"CASE Selected: {case['condition']}")
                        perform(case["then"])
                        break
            elif operation in {"write", "rlq"}:
                point = parse_point(statement["point"], write=True)
                priority = int(statement["priority"])
                value = None if operation == "rlq" else float(ExpressionParser(statement["expr"], variables, reads, timer_state).parse())
                allowed, label = suppressor.should_write(point, value, priority)
                destination = f"{point.key}@{priority}"
                if not allowed:
                    writes.append(f"{label}: {destination}")
                    trace.append(writes[-1]); continue
                if dry:
                    writes.append(f"Would {'relinquish' if operation == 'rlq' else 'write'}: {destination}" + ("" if value is None else f" = {value}"))
                    trace.append(writes[-1]); continue
                try:
                    if operation == "rlq": adapter.relinquish(point, priority)
                    else: adapter.write(point, value, priority)
                    suppressor.record_success(point, value, priority)
                    writes.append(f"WRITE: {destination}" + ("" if value is None else f" = {value}"))
                except Exception as exc:
                    suppressor.record_failure(point)
                    writes.append(f"WRITE RETRY: {destination} failed: {exc}")
                    raise
                trace.append(writes[-1])

    perform(compiled["statements"])
    if variable_state is not None:
        variable_state.clear()
        variable_state.update(variables)
    if dry: trace.append("No BACnet writes performed.")
    return ExecutionSnapshot(
        state="Compiled" if dry else "Running", last_scan=datetime.now(timezone.utc).isoformat(),
        duration_ms=int((time.monotonic() - started) * 1000), variables=variables, reads=reads,
        writes=writes, suppressed_writes=sum(1 for item in writes if item.startswith("WRITE SKIPPED")), trace=trace,
    )


def dry_run(compiled: dict[str, Any], adapter: BacnetAdapter) -> ExecutionSnapshot:
    return execute_program(compiled, adapter, dry=True)


class ProgramStore:
    def __init__(self, path: Path):
        self.path=path; path.parent.mkdir(parents=True, exist_ok=True); self._init()
    def _connect(self): return sqlite3.connect(self.path)
    def _init(self):
        with self._connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS programs (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, description TEXT NOT NULL DEFAULT '', source_code TEXT NOT NULL, compiled_json TEXT, compile_status TEXT NOT NULL DEFAULT 'Draft', compile_error TEXT, enabled INTEGER NOT NULL DEFAULT 0, runtime_state TEXT NOT NULL DEFAULT 'Draft', last_error TEXT, last_compiled_at TEXT, last_executed_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS executions (id INTEGER PRIMARY KEY, program_id INTEGER NOT NULL, started_at TEXT NOT NULL, completed_at TEXT, status TEXT NOT NULL, reads_json TEXT, variables_json TEXT, writes_json TEXT, error_text TEXT, duration_ms INTEGER)")
    def list(self):
        with self._connect() as db:
            db.row_factory = sqlite3.Row
            return [dict(row) for row in db.execute("SELECT * FROM programs ORDER BY name")]
    def get(self, program_id: int):
        with self._connect() as db:
            db.row_factory = sqlite3.Row
            row = db.execute("SELECT * FROM programs WHERE id=?", (program_id,)).fetchone()
            return dict(row) if row else None
    def save(self, name: str, description: str, source: str, program_id: int | None = None) -> int:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as db:
            if program_id:
                db.execute("UPDATE programs SET name=?,description=?,source_code=?,compile_status='Draft',compiled_json=NULL,compile_error=NULL,runtime_state='Draft',updated_at=? WHERE id=?", (name,description,source,now,program_id)); return program_id
            return int(db.execute("INSERT INTO programs (name,description,source_code,created_at,updated_at) VALUES (?,?,?,?,?)", (name,description,source,now,now)).lastrowid)
    def compile(self, program_id: int) -> tuple[bool, dict[str, Any]]:
        program = self.get(program_id)
        if not program: raise KeyError(program_id)
        now = datetime.now(timezone.utc).isoformat()
        try:
            compiled=compile_program(program["source_code"])
        except ProgramError as exc:
            payload=exc.as_dict()
            with self._connect() as db: db.execute("UPDATE programs SET compile_status='Error',compile_error=?,runtime_state='Error',last_error=?,last_compiled_at=?,updated_at=? WHERE id=?", (json.dumps(payload),exc.message,now,now,program_id))
            return False,payload
        with self._connect() as db: db.execute("UPDATE programs SET compile_status='Compiled',compiled_json=?,compile_error=NULL,runtime_state='Compiled',last_compiled_at=?,updated_at=? WHERE id=?", (json.dumps(compiled),now,now,program_id))
        return True,compiled
    def set_runtime(self, program_id: int, state: str, *, enabled: bool | None = None, error: str = "") -> None:
        now = datetime.now(timezone.utc).isoformat()
        fields, values = ["runtime_state=?", "last_error=?", "updated_at=?"], [state, error, now]
        if enabled is not None: fields.append("enabled=?"); values.append(int(enabled))
        values.append(program_id)
        with self._connect() as db: db.execute(f"UPDATE programs SET {', '.join(fields)} WHERE id=?", values)
    def enabled_compiled(self) -> list[dict[str, Any]]:
        with self._connect() as db:
            db.row_factory=sqlite3.Row
            return [dict(row) for row in db.execute("SELECT * FROM programs WHERE enabled=1 AND compile_status='Compiled'")]
    def record_execution(self, program_id: int, snapshot: ExecutionSnapshot, status: str, error: str = "") -> None:
        now=datetime.now(timezone.utc).isoformat()
        with self._connect() as db:
            db.execute("INSERT INTO executions (program_id,started_at,completed_at,status,reads_json,variables_json,writes_json,error_text,duration_ms) VALUES (?,?,?,?,?,?,?,?,?)", (program_id,now,now,status,json.dumps(snapshot.reads or {}, allow_nan=True),json.dumps(snapshot.variables or {}, allow_nan=True),json.dumps(snapshot.writes or []),error,snapshot.duration_ms))
            db.execute("DELETE FROM executions WHERE id NOT IN (SELECT id FROM executions WHERE program_id=? ORDER BY id DESC LIMIT 100) AND program_id=?", (program_id,program_id))
            db.execute("UPDATE programs SET runtime_state=?,last_executed_at=?,last_error=?,updated_at=? WHERE id=?", ("Running" if status=="ok" else "Error",now,error,now,program_id))
    def latest_execution(self, program_id: int) -> dict[str, Any] | None:
        with self._connect() as db:
            db.row_factory=sqlite3.Row
            row=db.execute("SELECT * FROM executions WHERE program_id=? ORDER BY id DESC LIMIT 1",(program_id,)).fetchone()
            return dict(row) if row else None
