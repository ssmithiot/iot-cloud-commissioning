from __future__ import annotations

import csv
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterator


ACTIVE_STATUSES = ("active", "retry_pending", "expiring", "failed")
ACTIONABLE_STATUSES = ("active", "retry_pending", "expiring")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class TimedOverrideStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA foreign_keys=ON")
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init(self) -> None:
        with sqlite3.connect(self.path, timeout=10) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS timed_overrides (
                  id TEXT PRIMARY KEY,
                  gateway_id TEXT NOT NULL,
                  gateway_ip TEXT,
                  device_id TEXT NOT NULL,
                  object_type TEXT NOT NULL,
                  object_instance TEXT NOT NULL,
                  description TEXT,
                  property_identifier TEXT NOT NULL DEFAULT 'present-value',
                  priority INTEGER NOT NULL,
                  bacnet_tag TEXT NOT NULL,
                  requested_value TEXT NOT NULL,
                  requested_value_normalized TEXT NOT NULL,
                  confirmed_value TEXT NOT NULL,
                  confirmed_value_normalized TEXT NOT NULL,
                  display_value TEXT,
                  route_classification TEXT,
                  route_snapshot_json TEXT NOT NULL DEFAULT '{}',
                  source_page TEXT,
                  created_by TEXT,
                  created_at TEXT NOT NULL,
                  expires_at TEXT NOT NULL,
                  status TEXT NOT NULL,
                  attempt_count INTEGER NOT NULL DEFAULT 0,
                  next_attempt_at TEXT,
                  last_attempt_at TEXT,
                  last_error TEXT,
                  completed_at TEXT,
                  completion_reason TEXT,
                  locked_by TEXT,
                  locked_until TEXT,
                  updated_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_timed_overrides_status_expires
                ON timed_overrides(status, expires_at)
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS timed_override_audit (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  override_id TEXT NOT NULL,
                  event_type TEXT NOT NULL,
                  event_at TEXT NOT NULL,
                  operator TEXT,
                  detail_json TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_timed_override_audit_override
                ON timed_override_audit(override_id, id)
                """
            )

    def create_override(self, payload: dict[str, Any]) -> dict[str, Any]:
        now = utc_now_iso()
        row = dict(payload)
        row.setdefault("created_at", now)
        row.setdefault("updated_at", now)
        row.setdefault("status", "active")
        row.setdefault("attempt_count", 0)
        keys = [
            "id", "gateway_id", "gateway_ip", "device_id", "object_type", "object_instance",
            "description", "property_identifier", "priority", "bacnet_tag", "requested_value",
            "requested_value_normalized", "confirmed_value", "confirmed_value_normalized",
            "display_value", "route_classification", "route_snapshot_json", "source_page",
            "created_by", "created_at", "expires_at", "status", "attempt_count",
            "next_attempt_at", "last_attempt_at", "last_error", "completed_at",
            "completion_reason", "locked_by", "locked_until", "updated_at",
        ]
        with self.connect() as conn:
            conn.execute(
                f"INSERT INTO timed_overrides ({','.join(keys)}) VALUES ({','.join(['?'] * len(keys))})",
                [row.get(key) for key in keys],
            )
        return self.get(str(row["id"])) or row

    def add_audit(self, override_id: str, event_type: str, detail: dict[str, Any] | None = None, *, operator: str = "") -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO timed_override_audit (override_id,event_type,event_at,operator,detail_json) VALUES (?,?,?,?,?)",
                (override_id, event_type, utc_now_iso(), operator, json.dumps(detail or {}, sort_keys=True)),
            )

    def get(self, override_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM timed_overrides WHERE id=?", (override_id,)).fetchone()
        return dict(row) if row else None

    def audit_for(self, override_id: str) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM timed_override_audit WHERE override_id=? ORDER BY id",
                (override_id,),
            ).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            try:
                item["detail"] = json.loads(item.get("detail_json") or "{}")
            except Exception:
                item["detail"] = {}
            out.append(item)
        return out

    def query(self, filters: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        filters = filters or {}
        where: list[str] = []
        params: list[Any] = []
        statuses = filters.get("statuses")
        if statuses:
            placeholders = ",".join(["?"] * len(statuses))
            where.append(f"status IN ({placeholders})")
            params.extend(statuses)
        for field, column in [
            ("gateway", "gateway_id"),
            ("device_id", "device_id"),
            ("object_type", "object_type"),
            ("object_instance", "object_instance"),
            ("priority", "priority"),
            ("creator", "created_by"),
        ]:
            value = str(filters.get(field) or "").strip()
            if value:
                where.append(f"{column}=?")
                params.append(value)
        desc = str(filters.get("description") or "").strip()
        if desc:
            where.append("description LIKE ?")
            params.append(f"%{desc}%")
        for key, column, op in [
            ("created_from", "created_at", ">="),
            ("created_to", "created_at", "<="),
            ("expires_from", "expires_at", ">="),
            ("expires_to", "expires_at", "<="),
        ]:
            value = str(filters.get(key) or "").strip()
            if value:
                where.append(f"{column}{op}?")
                params.append(value)
        if filters.get("overdue"):
            where.append("expires_at<=?")
            params.append(utc_now_iso())
            where.append("status IN ('active','retry_pending','expiring')")
        sql = "SELECT * FROM timed_overrides"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY CASE WHEN status IN ('active','retry_pending','expiring') THEN 0 ELSE 1 END, expires_at ASC, created_at DESC"
        with self.connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    def update(self, override_id: str, **fields: Any) -> dict[str, Any] | None:
        if not fields:
            return self.get(override_id)
        fields["updated_at"] = utc_now_iso()
        assignments = ", ".join([f"{key}=?" for key in fields])
        values = list(fields.values()) + [override_id]
        with self.connect() as conn:
            conn.execute(f"UPDATE timed_overrides SET {assignments} WHERE id=?", values)
        return self.get(override_id)

    def cancel_timer_only(self, override_id: str, *, operator: str = "", reason: str = "canceled by operator") -> dict[str, Any] | None:
        row = self.update(
            override_id,
            status="canceled",
            completed_at=utc_now_iso(),
            completion_reason=reason,
            locked_by=None,
            locked_until=None,
        )
        self.add_audit(override_id, "canceled", {"reason": reason}, operator=operator)
        return row

    def extend(self, override_id: str, expires_at: str, *, operator: str = "") -> dict[str, Any] | None:
        row = self.update(override_id, expires_at=expires_at, status="active", next_attempt_at=None, last_error=None)
        self.add_audit(override_id, "extended", {"expires_at": expires_at}, operator=operator)
        return row

    def due_rows(self, now_iso: str | None = None, limit: int = 10) -> list[dict[str, Any]]:
        now_iso = now_iso or utc_now_iso()
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM timed_overrides
                WHERE (
                  (status='active' AND expires_at<=?)
                  OR (status='retry_pending' AND COALESCE(next_attempt_at, expires_at)<=?)
                  OR (status='expiring' AND COALESCE(locked_until, '')<=?)
                )
                ORDER BY expires_at ASC LIMIT ?
                """,
                (now_iso, now_iso, now_iso, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def claim(self, override_id: str, worker_id: str, lock_until: str) -> dict[str, Any] | None:
        now = utc_now_iso()
        with self.connect() as conn:
            conn.execute(
                """
                UPDATE timed_overrides
                SET status='expiring', locked_by=?, locked_until=?, updated_at=?
                WHERE id=?
                  AND status IN ('active','retry_pending','expiring')
                  AND (locked_until IS NULL OR locked_until='' OR locked_until<=?)
                """,
                (worker_id, lock_until, now, override_id, now),
            )
            row = conn.execute("SELECT * FROM timed_overrides WHERE id=? AND locked_by=?", (override_id, worker_id)).fetchone()
        return dict(row) if row else None

    def retry_later(self, override_id: str, error: str, *, delay_seconds: int, operator: str = "") -> dict[str, Any] | None:
        now_dt = datetime.now(timezone.utc).replace(microsecond=0)
        next_iso = (now_dt + timedelta(seconds=delay_seconds)).replace(microsecond=0).isoformat()
        row = self.get(override_id) or {}
        attempt_count = int(row.get("attempt_count") or 0) + 1
        updated = self.update(
            override_id,
            status="retry_pending",
            attempt_count=attempt_count,
            next_attempt_at=next_iso,
            last_attempt_at=now_dt.isoformat(),
            last_error=error,
            locked_by=None,
            locked_until=None,
        )
        self.add_audit(override_id, "retry_pending", {"error": error, "next_attempt_at": next_iso, "attempt_count": attempt_count}, operator=operator)
        return updated

    def finish(self, override_id: str, status: str, reason: str, detail: dict[str, Any] | None = None, *, operator: str = "") -> dict[str, Any] | None:
        now = utc_now_iso()
        row = self.get(override_id) or {}
        attempt_count = int(row.get("attempt_count") or 0) + 1
        updated = self.update(
            override_id,
            status=status,
            attempt_count=attempt_count,
            last_attempt_at=now,
            last_error="" if status in {"completed", "superseded", "already_relinquished", "canceled"} else reason,
            completed_at=now,
            completion_reason=reason,
            locked_by=None,
            locked_until=None,
        )
        self.add_audit(override_id, status, detail or {"reason": reason}, operator=operator)
        return updated

    def export_csv(self, rows: list[dict[str, Any]], fileobj: Any) -> None:
        fieldnames = [
            "id", "gateway_id", "device_id", "object_type", "object_instance", "property_identifier",
            "display_value", "priority", "created_at", "expires_at", "completed_at", "status",
            "created_by", "completion_reason", "last_error",
        ]
        writer = csv.DictWriter(fileobj, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})
