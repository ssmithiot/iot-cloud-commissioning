"""Shared SQLite store for gateway-local BACnet trend configuration.

The Edge UI owns configuration.  The agent is the only BACnet reader and
appends runtime/sample information to the same database.  Keeping this store
separate from saved devices and Edge Programs makes the pilot removable and
prevents a trend change from changing either feature's data.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
from typing import Iterator
from uuid import uuid4


SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS trend_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    interval_sec INTEGER NOT NULL CHECK(interval_sec >= 30),
    enabled INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS trend_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    device_profile_id TEXT NOT NULL,
    device_instance INTEGER NOT NULL,
    object_type TEXT NOT NULL,
    object_instance INTEGER NOT NULL,
    object_name TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(group_id, device_instance, object_type, object_instance),
    FOREIGN KEY(group_id) REFERENCES trend_groups(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS trend_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    requested_count INTEGER NOT NULL DEFAULT 0,
    returned_count INTEGER NOT NULL DEFAULT 0,
    deferred_count INTEGER NOT NULL DEFAULT 0,
    duration_ms INTEGER,
    cpu_load_pct REAL,
    memory_used_pct REAL,
    network_rx_bytes INTEGER,
    network_tx_bytes INTEGER,
    error_text TEXT,
    FOREIGN KEY(group_id) REFERENCES trend_groups(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS trend_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trend_point_id INTEGER NOT NULL,
    sampled_at TEXT NOT NULL,
    value_text TEXT,
    status TEXT NOT NULL,
    read_source TEXT,
    error_text TEXT,
    FOREIGN KEY(trend_point_id) REFERENCES trend_points(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS trend_upload_outbox (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL UNIQUE,
    trend_sample_id INTEGER NOT NULL UNIQUE,
    state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending', 'uploaded')),
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TEXT,
    last_error TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    uploaded_at TEXT,
    FOREIGN KEY(trend_sample_id) REFERENCES trend_samples(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS trend_sync_state (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS trend_views (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    settings_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(group_id, name),
    FOREIGN KEY(group_id) REFERENCES trend_groups(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_trend_points_group ON trend_points(group_id);
CREATE INDEX IF NOT EXISTS idx_trend_samples_point_time ON trend_samples(trend_point_id, sampled_at DESC);
CREATE INDEX IF NOT EXISTS idx_trend_runs_group_time ON trend_runs(group_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_trend_upload_outbox_pending ON trend_upload_outbox(state, next_attempt_at, id);
"""


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class EdgeTrendStore:
    def __init__(self, path: Path):
        self.path = path
        self.initialize()

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.path) as conn:
            conn.executescript(SCHEMA)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA foreign_keys=ON")
            yield conn
            conn.commit()
        finally:
            conn.close()

    def groups(self) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT g.*, COUNT(p.id) AS point_count,
                  (SELECT MAX(started_at) FROM trend_runs r WHERE r.group_id = g.id) AS last_started_at,
                  (SELECT error_text FROM trend_runs r WHERE r.group_id = g.id ORDER BY r.id DESC LIMIT 1) AS last_error
                FROM trend_groups g LEFT JOIN trend_points p ON p.group_id = g.id
                GROUP BY g.id ORDER BY g.name COLLATE NOCASE
                """
            ).fetchall()
        return [dict(row) for row in rows]

    def group(self, group_id: int) -> dict | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM trend_groups WHERE id = ?", (group_id,)).fetchone()
        return None if row is None else dict(row)

    def points(self, group_id: int) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM trend_points WHERE group_id = ? ORDER BY device_instance, object_type, object_instance",
                (group_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def save_group(self, *, group_id: int | None, name: str, interval_sec: int, enabled: bool, points: list[dict]) -> int:
        clean_name = name.strip()
        if not clean_name:
            raise ValueError("Trend name is required.")
        if not 30 <= interval_sec <= 86400:
            raise ValueError("Trend interval must be between 30 seconds and 24 hours.")
        if not points:
            raise ValueError("Select at least one saved Live Device point.")
        timestamp = now_utc()
        with self.connect() as conn:
            if group_id:
                exists = conn.execute("SELECT id FROM trend_groups WHERE id = ?", (group_id,)).fetchone()
                if not exists:
                    raise ValueError("Trend group not found.")
                conn.execute("UPDATE trend_groups SET name=?, interval_sec=?, enabled=?, updated_at=? WHERE id=?", (clean_name, interval_sec, int(enabled), timestamp, group_id))
                conn.execute("DELETE FROM trend_points WHERE group_id = ?", (group_id,))
            else:
                cursor = conn.execute("INSERT INTO trend_groups (name, interval_sec, enabled, created_at, updated_at) VALUES (?, ?, ?, ?, ?)", (clean_name, interval_sec, int(enabled), timestamp, timestamp))
                group_id = int(cursor.lastrowid)
            conn.executemany(
                """INSERT INTO trend_points (group_id, device_profile_id, device_instance, object_type, object_instance, object_name, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                [(group_id, point["device_profile_id"], point["device_instance"], point["object_type"], point["object_instance"], point.get("object_name", ""), timestamp) for point in points],
            )
        return int(group_id)

    def set_enabled(self, group_id: int, enabled: bool) -> None:
        with self.connect() as conn:
            conn.execute("UPDATE trend_groups SET enabled=?, updated_at=? WHERE id=?", (int(enabled), now_utc(), group_id))

    def delete_group(self, group_id: int) -> None:
        with self.connect() as conn:
            conn.execute("DELETE FROM trend_groups WHERE id = ?", (group_id,))

    def dashboard(self) -> dict:
        with self.connect() as conn:
            latest_run = conn.execute("SELECT * FROM trend_runs ORDER BY id DESC LIMIT 1").fetchone()
            sample_count = conn.execute("SELECT COUNT(*) FROM trend_samples").fetchone()[0]
            outbox = conn.execute(
                "SELECT COUNT(*) AS pending_count, MIN(created_at) AS oldest_pending_at, MAX(attempt_count) AS max_attempt_count FROM trend_upload_outbox WHERE state='pending'"
            ).fetchone()
        return {
            "latest_run": None if latest_run is None else dict(latest_run),
            "sample_count": int(sample_count),
            "pending_upload_count": int(outbox["pending_count"]),
            "oldest_pending_upload_at": outbox["oldest_pending_at"],
            "max_upload_attempt_count": int(outbox["max_attempt_count"] or 0),
        }

    def queue_sample_upload(self, conn: sqlite3.Connection, trend_sample_id: int, *, timestamp: str | None = None) -> str:
        """Add one immutable local sample to the dedicated cloud-upload outbox.

        Callers use the same transaction that inserted the sample, so a local
        sample can never exist in a state where it was silently omitted from
        replication.
        """
        event_id = str(uuid4())
        now = timestamp or now_utc()
        conn.execute(
            "INSERT INTO trend_upload_outbox (event_id, trend_sample_id, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (event_id, trend_sample_id, now, now),
        )
        return event_id

    def samples(self, group_id: int, point_id: int | None = None, *, since: str | None = None, limit: int = 500) -> list[dict]:
        """Recent local samples, newest first, with point display metadata."""
        query = """
            SELECT s.*, p.group_id, p.device_instance, p.object_type, p.object_instance, p.object_name
            FROM trend_samples s JOIN trend_points p ON p.id = s.trend_point_id
            WHERE p.group_id = ?
        """
        params: list[object] = [group_id]
        if point_id is not None:
            query += " AND p.id = ?"
            params.append(point_id)
        if since:
            query += " AND s.sampled_at >= ?"
            params.append(since)
        query += " ORDER BY s.sampled_at DESC, s.id DESC LIMIT ?"
        params.append(max(1, min(int(limit), 2000)))
        with self.connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def views(self, group_id: int) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute("SELECT * FROM trend_views WHERE group_id=? ORDER BY name COLLATE NOCASE", (group_id,)).fetchall()
        return [dict(row) for row in rows]

    def save_view(self, group_id: int, name: str, settings_json: str) -> int:
        name = name.strip()
        if not name:
            raise ValueError("Template name is required.")
        timestamp = now_utc()
        with self.connect() as conn:
            conn.execute("INSERT INTO trend_views (group_id,name,settings_json,created_at,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(group_id,name) DO UPDATE SET settings_json=excluded.settings_json, updated_at=excluded.updated_at", (group_id, name, settings_json, timestamp, timestamp))
            row = conn.execute("SELECT id FROM trend_views WHERE group_id=? AND name=?", (group_id, name)).fetchone()
        return int(row["id"])
