"""Shared SQLite store for gateway-local BACnet trend configuration.

The Edge UI owns configuration.  The agent is the only BACnet reader and
appends runtime/sample information to the same database.  Keeping this store
separate from saved devices and Edge Programs makes the pilot removable and
prevents a trend change from changing either feature's data.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import logging
from pathlib import Path
import re
import shutil
import sqlite3
from typing import Iterator
from uuid import uuid4


logger = logging.getLogger("edge-trend-store")


# How many raw rows the "Recent samples" table under the graph may render.  This
# is a display bound only; every raw sample stays in SQLite.
RECENT_SAMPLE_ROWS = 500
# Roughly how many values the graph should plot per trend point.  Each time
# bucket contributes at most four values (first, minimum, maximum, last), so the
# bucket count is a quarter of the target.
GRAPH_TARGET_VALUES = 2000
GRAPH_VALUES_PER_BUCKET = 4

BINARY_TRUE_TEXT = {"active", "on", "true", "yes"}
BINARY_FALSE_TEXT = {"inactive", "off", "false", "no"}
_NUMBER_PATTERN = re.compile(r"\(([-+]?\d+(?:\.\d+)?)\)|\b([-+]?\d+(?:\.\d+)?)\b")


def numeric_sample_value(value: object) -> float | None:
    """Best-effort numeric reading of a stored BACnet sample.

    Analog values arrive as plain numbers, binary values as active/inactive and
    multistate values as ``Occupied (2)``.  Downsampling needs the same
    interpretation the chart uses, so both go through this one function.
    """
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        pass
    lowered = text.lower()
    if lowered in BINARY_TRUE_TEXT:
        return 1.0
    if lowered in BINARY_FALSE_TEXT:
        return 0.0
    match = _NUMBER_PATTERN.search(text)
    if match:
        return float(match.group(1) or match.group(2))
    return None


def _epoch_seconds(value: object) -> float | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp()


SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS trend_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    interval_sec INTEGER NOT NULL CHECK(interval_sec >= 30),
    enabled INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS trend_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    device_profile_id TEXT NOT NULL,
    device_instance INTEGER NOT NULL,
    object_type TEXT NOT NULL,
    object_instance INTEGER NOT NULL,
    object_name TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(group_id, device_instance, object_type, object_instance),
    FOREIGN KEY(group_id) REFERENCES trend_groups(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS trend_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    requested_count INTEGER NOT NULL DEFAULT 0,
    returned_count INTEGER NOT NULL DEFAULT 0,
    deferred_count INTEGER NOT NULL DEFAULT 0,
    duration_ms INTEGER,
    cpu_load_pct REAL,
    memory_used_pct REAL,
    network_rx_bytes INTEGER,
    network_tx_bytes INTEGER,
    error_text TEXT,
    FOREIGN KEY(group_id) REFERENCES trend_groups(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS trend_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trend_point_id INTEGER NOT NULL,
    sampled_at TEXT NOT NULL,
    value_text TEXT,
    status TEXT NOT NULL,
    read_source TEXT,
    error_text TEXT,
    FOREIGN KEY(trend_point_id) REFERENCES trend_points(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS trend_upload_outbox (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL UNIQUE,
    trend_sample_id INTEGER NOT NULL UNIQUE,
    state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending', 'uploaded')),
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TEXT,
    last_error TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    uploaded_at TEXT,
    FOREIGN KEY(trend_sample_id) REFERENCES trend_samples(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS trend_sync_state (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS trend_views (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    settings_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(group_id, name),
    FOREIGN KEY(group_id) REFERENCES trend_groups(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_trend_points_group ON trend_points(group_id);
CREATE INDEX IF NOT EXISTS idx_trend_samples_point_time ON trend_samples(trend_point_id, sampled_at DESC);
CREATE INDEX IF NOT EXISTS idx_trend_runs_group_time ON trend_runs(group_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_trend_upload_outbox_pending ON trend_upload_outbox(state, next_attempt_at, id);
"""


# Columns added to tables that already shipped in an earlier release.  Every
# entry must be additive and nullable-or-defaulted so that applying it to a
# populated gateway database cannot fail and cannot lose a row.
ADDITIVE_COLUMNS: dict[str, dict[str, str]] = {
    "trend_runs": {
        "cpu_load_pct": "REAL",
        "memory_used_pct": "REAL",
        "network_rx_bytes": "INTEGER",
        "network_tx_bytes": "INTEGER",
    },
    "trend_points": {
        "object_name": "TEXT NOT NULL DEFAULT ''",
    },
    "trend_upload_outbox": {
        "attempt_count": "INTEGER NOT NULL DEFAULT 0",
        "next_attempt_at": "TEXT",
        "last_error": "TEXT",
        "uploaded_at": "TEXT",
    },
}
SCHEMA_VERSION = 2


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class EdgeTrendStore:
    def __init__(self, path: Path):
        self.path = path
        self.initialize()

    def initialize(self) -> None:
        """Create or upgrade the local trend database without losing history.

        The 0.2.0 upgrade runs against gateways that already hold real trend
        history, so this is deliberately additive only: it creates missing
        tables, adds missing columns, and never drops, rewrites or migrates a
        row.  A backup copy is taken before the first statement that would
        change an existing database, and the whole method is safe to rerun.
        """
        self.path.parent.mkdir(parents=True, exist_ok=True)
        pending = self._pending_changes()
        if pending and self.path.exists() and self.path.stat().st_size > 0:
            self._backup_before_migration(pending)
        with sqlite3.connect(self.path) as conn:
            conn.executescript(SCHEMA)
            self._apply_additive_columns(conn)
            conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")

    def _existing_tables(self, conn: sqlite3.Connection) -> set[str]:
        rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        return {str(row[0]) for row in rows}

    def _existing_columns(self, conn: sqlite3.Connection, table: str) -> set[str]:
        return {str(row[1]) for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}

    def _pending_changes(self) -> list[str]:
        """Describe what initialize() would change, without changing anything."""
        if not self.path.exists() or self.path.stat().st_size == 0:
            return ["create new trend database"]
        changes: list[str] = []
        conn = sqlite3.connect(self.path)
        try:
            tables = self._existing_tables(conn)
            for statement in SCHEMA.split(";"):
                stripped = statement.strip()
                if not stripped.upper().startswith("CREATE TABLE IF NOT EXISTS"):
                    continue
                table = stripped.split()[5].split("(")[0]
                if table not in tables:
                    changes.append(f"create table {table}")
            for table, columns in ADDITIVE_COLUMNS.items():
                if table not in tables:
                    continue
                existing = self._existing_columns(conn, table)
                changes.extend(f"add column {table}.{column}" for column in columns if column not in existing)
            if int(conn.execute("PRAGMA user_version").fetchone()[0]) != SCHEMA_VERSION:
                changes.append(f"set schema version {SCHEMA_VERSION}")
        finally:
            conn.close()
        return changes

    def _backup_before_migration(self, pending: list[str]) -> Path:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        backup_path = self.path.with_name(f"{self.path.name}.pre-{SCHEMA_VERSION}-{stamp}.bak")
        # Copy through SQLite so an in-flight WAL checkpoint cannot produce a
        # torn backup file.
        source = sqlite3.connect(self.path)
        try:
            destination = sqlite3.connect(backup_path)
            try:
                source.backup(destination)
            finally:
                destination.close()
        except (sqlite3.Error, OSError):
            shutil.copy2(self.path, backup_path)
        finally:
            source.close()
        logger.info("Backed up %s to %s before trend schema changes: %s", self.path, backup_path, "; ".join(pending))
        return backup_path

    def _apply_additive_columns(self, conn: sqlite3.Connection) -> None:
        tables = self._existing_tables(conn)
        for table, columns in ADDITIVE_COLUMNS.items():
            if table not in tables:
                continue
            existing = self._existing_columns(conn, table)
            for column, definition in columns.items():
                if column in existing:
                    continue
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
                logger.info("Added trend column %s.%s", table, column)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA foreign_keys=ON")
            yield conn
            conn.commit()
        finally:
            conn.close()

    def groups(self) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT g.*, COUNT(p.id) AS point_count,
                  (SELECT MAX(started_at) FROM trend_runs r WHERE r.group_id = g.id) AS last_started_at,
                  (SELECT error_text FROM trend_runs r WHERE r.group_id = g.id ORDER BY r.id DESC LIMIT 1) AS last_error
                FROM trend_groups g LEFT JOIN trend_points p ON p.group_id = g.id
                GROUP BY g.id ORDER BY g.name COLLATE NOCASE
                """
            ).fetchall()
        return [dict(row) for row in rows]

    def group(self, group_id: int) -> dict | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM trend_groups WHERE id = ?", (group_id,)).fetchone()
        return None if row is None else dict(row)

    def points(self, group_id: int) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM trend_points WHERE group_id = ? ORDER BY device_instance, object_type, object_instance",
                (group_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def save_group(self, *, group_id: int | None, name: str, interval_sec: int, enabled: bool, points: list[dict]) -> int:
        clean_name = name.strip()
        if not clean_name:
            raise ValueError("Trend name is required.")
        if not 30 <= interval_sec <= 86400:
            raise ValueError("Trend interval must be between 30 seconds and 24 hours.")
        if not points:
            raise ValueError("Select at least one saved Live Device point.")
        timestamp = now_utc()
        with self.connect() as conn:
            if group_id:
                exists = conn.execute("SELECT id FROM trend_groups WHERE id = ?", (group_id,)).fetchone()
                if not exists:
                    raise ValueError("Trend group not found.")
                conn.execute("UPDATE trend_groups SET name=?, interval_sec=?, enabled=?, updated_at=? WHERE id=?", (clean_name, interval_sec, int(enabled), timestamp, group_id))
                conn.execute("DELETE FROM trend_points WHERE group_id = ?", (group_id,))
            else:
                cursor = conn.execute("INSERT INTO trend_groups (name, interval_sec, enabled, created_at, updated_at) VALUES (?, ?, ?, ?, ?)", (clean_name, interval_sec, int(enabled), timestamp, timestamp))
                group_id = int(cursor.lastrowid)
            conn.executemany(
                """INSERT INTO trend_points (group_id, device_profile_id, device_instance, object_type, object_instance, object_name, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                [(group_id, point["device_profile_id"], point["device_instance"], point["object_type"], point["object_instance"], point.get("object_name", ""), timestamp) for point in points],
            )
        return int(group_id)

    def set_enabled(self, group_id: int, enabled: bool) -> None:
        with self.connect() as conn:
            conn.execute("UPDATE trend_groups SET enabled=?, updated_at=? WHERE id=?", (int(enabled), now_utc(), group_id))

    def delete_group(self, group_id: int) -> None:
        with self.connect() as conn:
            conn.execute("DELETE FROM trend_groups WHERE id = ?", (group_id,))

    def dashboard(self) -> dict:
        with self.connect() as conn:
            latest_run = conn.execute("SELECT * FROM trend_runs ORDER BY id DESC LIMIT 1").fetchone()
            sample_count = conn.execute("SELECT COUNT(*) FROM trend_samples").fetchone()[0]
            outbox = conn.execute(
                "SELECT COUNT(*) AS pending_count, MIN(created_at) AS oldest_pending_at, MAX(attempt_count) AS max_attempt_count FROM trend_upload_outbox WHERE state='pending'"
            ).fetchone()
        return {
            "latest_run": None if latest_run is None else dict(latest_run),
            "sample_count": int(sample_count),
            "pending_upload_count": int(outbox["pending_count"]),
            "oldest_pending_upload_at": outbox["oldest_pending_at"],
            "max_upload_attempt_count": int(outbox["max_attempt_count"] or 0),
        }

    def queue_sample_upload(self, conn: sqlite3.Connection, trend_sample_id: int, *, timestamp: str | None = None) -> str:
        """Add one immutable local sample to the dedicated cloud-upload outbox.

        Callers use the same transaction that inserted the sample, so a local
        sample can never exist in a state where it was silently omitted from
        replication.
        """
        event_id = str(uuid4())
        now = timestamp or now_utc()
        conn.execute(
            "INSERT INTO trend_upload_outbox (event_id, trend_sample_id, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (event_id, trend_sample_id, now, now),
        )
        return event_id

    def samples(self, group_id: int, point_id: int | None = None, *, since: str | None = None, limit: int = 500) -> list[dict]:
        """Recent local samples, newest first, with point display metadata."""
        query = """
            SELECT s.*, p.group_id, p.device_instance, p.object_type, p.object_instance, p.object_name
            FROM trend_samples s JOIN trend_points p ON p.id = s.trend_point_id
            WHERE p.group_id = ?
        """
        params: list[object] = [group_id]
        if point_id is not None:
            query += " AND p.id = ?"
            params.append(point_id)
        if since:
            query += " AND s.sampled_at >= ?"
            params.append(since)
        query += " ORDER BY s.sampled_at DESC, s.id DESC LIMIT ?"
        params.append(max(1, min(int(limit), 2000)))
        with self.connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def graph_samples(
        self,
        group_id: int,
        *,
        since: str | None = None,
        until: str | None = None,
        target_values: int = GRAPH_TARGET_VALUES,
    ) -> list[dict]:
        """Samples for the chart, covering the whole requested window.

        ``samples()`` answers "the newest N rows", which is the right shape for
        the table under the graph and the wrong shape for the graph itself: a
        single fast-sampling point can fill the whole budget, hide every other
        point, and leave a 7-day request showing a few hours.

        This method instead walks each trend point independently and gives each
        one its own budget, so no point can crowd another out.  A point whose
        window holds more rows than ``target_values`` is reduced by time bucket,
        keeping the first, minimum, maximum and last sample of every bucket, so
        the plotted line still spans the full period and still shows short
        spikes and excursions.  Rows are returned in chronological order and no
        stored row is modified or removed.
        """
        target = max(GRAPH_VALUES_PER_BUCKET, int(target_values))
        bucket_count = max(1, target // GRAPH_VALUES_PER_BUCKET)
        collected: list[dict] = []
        with self.connect() as conn:
            point_ids = [
                int(row["id"])
                for row in conn.execute(
                    "SELECT id FROM trend_points WHERE group_id = ? ORDER BY device_instance, object_type, object_instance",
                    (group_id,),
                ).fetchall()
            ]
            for point_id in point_ids:
                collected.extend(self._graph_samples_for_point(conn, point_id, since, until, target, bucket_count))
        collected.sort(key=lambda row: (str(row["sampled_at"]), int(row["id"])))
        return collected

    def _graph_samples_for_point(
        self,
        conn: sqlite3.Connection,
        point_id: int,
        since: str | None,
        until: str | None,
        target: int,
        bucket_count: int,
    ) -> list[dict]:
        where = "WHERE s.trend_point_id = ?"
        params: list[object] = [point_id]
        if since:
            where += " AND s.sampled_at >= ?"
            params.append(since)
        if until:
            where += " AND s.sampled_at <= ?"
            params.append(until)
        total = int(conn.execute(f"SELECT COUNT(*) FROM trend_samples s {where}", params).fetchone()[0])
        if not total:
            return []
        query = f"""
            SELECT s.*, p.group_id, p.device_instance, p.object_type, p.object_instance, p.object_name
            FROM trend_samples s JOIN trend_points p ON p.id = s.trend_point_id
            {where}
            ORDER BY s.sampled_at, s.id
        """
        cursor = conn.execute(query, params)
        if total <= target:
            return [dict(row) for row in cursor]

        start_epoch = _epoch_seconds(since)
        end_epoch = _epoch_seconds(until)
        if start_epoch is None or end_epoch is None:
            bounds = conn.execute(f"SELECT MIN(s.sampled_at), MAX(s.sampled_at) FROM trend_samples s {where}", params).fetchone()
            start_epoch = start_epoch if start_epoch is not None else _epoch_seconds(bounds[0])
            end_epoch = end_epoch if end_epoch is not None else _epoch_seconds(bounds[1])
        if start_epoch is None or end_epoch is None or end_epoch <= start_epoch:
            # Unparsable or zero-width window: fall back to an even row stride so
            # the caller still gets a bounded, chronological series.
            stride = max(1, total // target)
            return [dict(row) for index, row in enumerate(cursor) if index % stride == 0][:target]

        span = end_epoch - start_epoch
        # Streaming the cursor keeps memory proportional to the bucket count
        # rather than to the number of raw rows in the window.
        buckets: dict[int, dict[str, dict]] = {}
        unbucketed: list[dict] = []
        for raw in cursor:
            row = dict(raw)
            stamp = _epoch_seconds(row["sampled_at"])
            if stamp is None:
                unbucketed.append(row)
                continue
            index = int((stamp - start_epoch) / span * bucket_count)
            index = min(bucket_count - 1, max(0, index))
            bucket = buckets.get(index)
            if bucket is None:
                buckets[index] = {"first": row, "last": row, "min": row, "max": row}
                continue
            bucket["last"] = row
            value = numeric_sample_value(row["value_text"])
            if value is None:
                continue
            low = numeric_sample_value(bucket["min"]["value_text"])
            high = numeric_sample_value(bucket["max"]["value_text"])
            if low is None or value < low:
                bucket["min"] = row
            if high is None or value > high:
                bucket["max"] = row

        reduced: dict[int, dict] = {}
        for index in sorted(buckets):
            for role in ("first", "min", "max", "last"):
                row = buckets[index][role]
                reduced[int(row["id"])] = row
        for row in unbucketed:
            reduced[int(row["id"])] = row
        return sorted(reduced.values(), key=lambda row: (str(row["sampled_at"]), int(row["id"])))

    def views(self, group_id: int) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute("SELECT * FROM trend_views WHERE group_id=? ORDER BY name COLLATE NOCASE", (group_id,)).fetchall()
        return [dict(row) for row in rows]

    def view(self, group_id: int, view_id: int) -> dict | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM trend_views WHERE group_id=? AND id=?", (group_id, view_id)).fetchone()
        return None if row is None else dict(row)

    def save_view(self, group_id: int, name: str, settings_json: str) -> int:
        name = name.strip()
        if not name:
            raise ValueError("Template name is required.")
        timestamp = now_utc()
        with self.connect() as conn:
            conn.execute("INSERT INTO trend_views (group_id,name,settings_json,created_at,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(group_id,name) DO UPDATE SET settings_json=excluded.settings_json, updated_at=excluded.updated_at", (group_id, name, settings_json, timestamp, timestamp))
            row = conn.execute("SELECT id FROM trend_views WHERE group_id=? AND name=?", (group_id, name)).fetchone()
        return int(row["id"])
